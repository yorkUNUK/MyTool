package york.BaseService.convertService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConvertServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
