package york.BaseService.convertService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConvertServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConvertServiceApplication.class, args);
	}

}
