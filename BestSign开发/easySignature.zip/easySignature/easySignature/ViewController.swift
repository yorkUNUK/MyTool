//
//  ViewController.swift
//  easySignature
//
//  Created by York on 2022/7/14.
//

import Cocoa
import SwiftyJSON
import Alamofire
import SwCrypt
import CommonCrypto
import SwiftHTTP

public extension String {
    /* ################################################################## */
    /**
     - returns: the String, as an MD5 hash.
     */
    var md5: String {
        let str = self.cString(using: String.Encoding.utf8)
        let strLen = CUnsignedInt(self.lengthOfBytes(using: String.Encoding.utf8))
        let digestLen = Int(CC_MD5_DIGEST_LENGTH)
        let result = UnsafeMutablePointer<CUnsignedChar>.allocate(capacity: digestLen)
        CC_MD5(str!, strLen, result)

        let hash = NSMutableString()

        for i in 0..<digestLen {
            hash.appendFormat("%02x", result[i])
        }

        result.deallocate()
        return hash as String
    }
}

public extension Date {
    
    /// 获取当前 秒级 时间戳 - 10位
    var timeStamp : String {
        let timeInterval: TimeInterval = self.timeIntervalSince1970
        let timeStamp = Int(timeInterval)
        return "\(timeStamp)"
    }
    
    /// 获取当前 毫秒级 时间戳 - 13位
    var milliStamp : String {
        let timeInterval: TimeInterval = self.timeIntervalSince1970
        let millisecond = CLongLong(round(timeInterval*1000))
        return "\(millisecond)"
    }
}

class ViewController: NSViewController {

    @IBOutlet weak var signButton: NSButton!
    @IBOutlet weak var clientId: NSTextField!
    @IBOutlet weak var clientSecret: NSTextField!
    @IBOutlet weak var apiName: NSTextField!
    @IBOutlet weak var timeStamp: NSTextField!
    @IBOutlet weak var getTimeStamp: NSButton!
    @IBOutlet var privateKeyInit: NSTextView!
    @IBOutlet var requestBody: NSTextView!
    @IBOutlet weak var errMsg: NSTextField!
    @IBOutlet weak var chooseHost: NSComboBox!
    @IBOutlet weak var method: NSSegmentedControl!
    @IBOutlet weak var tokenField: NSTextField!
    @IBOutlet weak var md5Field: NSTextField!
    @IBOutlet weak var signStringField: NSTextField!
    @IBOutlet weak var signatureField: NSTextField!
    @IBOutlet weak var response: NSScrollView!
    
    var tokenCache:String! = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func addRSAHeader(_ base64: String) -> String {
        let rsaPrefix = "-----BEGIN RSA PRIVATE KEY-----\n"
        let rsaSuffix = "\n-----END RSA PRIVATE KEY-----"
        return rsaPrefix + base64 + rsaSuffix
    }
    
    func URLEncode(_ url: String) -> String {
        var encodedUrl = url.replacingOccurrences(of: "/", with: "%2F")
        encodedUrl = encodedUrl.replacingOccurrences(of: "+", with: "%2B")
        encodedUrl = encodedUrl.replacingOccurrences(of: "=", with: "%3D")
        return encodedUrl
    }
    
    // JSONString转换为字典
    func getDictionaryFromJSONString(jsonString:String) ->(JSON){
        
        let jsonData:Data = jsonString.data(using: .utf8)!
        /*
        do {
            let dict = try JSONSerialization.jsonObject(with: jsonData, options: .mutableContainers)
            print("json对象转换成功")
            return dict as! NSDictionary
        }catch{
            print("json对象转换失败")
            print(error)
            return NSDictionary()
        }
         */
        let dict = JSON(jsonData)
        print(dict)
        return dict
    }
    
    func convertToDictionary(text: String) -> [String: Any]? {
        if let data = text.data(using: .utf8) {
            do {
                return try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
            } catch {
                print(error.localizedDescription)
            }
        }
        return nil
    }

    func queryToken(completion: @escaping (_ token: String, _ errMessage: String) -> ()){
        self.tokenCache = ""
        let parms = ["clientId":clientId.stringValue,"clientSecret":clientSecret.stringValue]
        AF.request(chooseHost.stringValue + "/api/oa2/client-credentials/token", method: .post,
                   parameters:parms, encoding: JSONEncoding.default,
                   headers:["Content-Type":"application/json"])
            .validate().responseJSON { (response) in
                switch response.result {
                case .success(let value):
                    let result = JSON(value)
                    if let token = result["data"]["accessToken"].string {
                        completion(token, "")
                        break
                    }else if let errMessage = result["message"].string{
                        completion("", errMessage)
                        break
                    }
                case .failure(let error):
                    print(error)
                    completion("", "")
                    break
                }
            }

    }
    
    func testFunc(_ clientId:String, _ urlWithParams:String, _ timeStamp:String, _ signature:String, _ token:String, _ requestBody:String) -> () {
        let body = convertToDictionary(text: requestBody)
        print("body: ")
        print(body!)
        HTTP.POST("https://api.bestsign.info/api/contract-center/search", parameters: body! , headers:["Content-Type":"application/json", "bestsign-client-id": clientId,"bestsign-sign-timestamp": timeStamp,"bestsign-signature-type": "RSA256","bestsign-signature": signature,"Authorization":"bearer "+token], requestSerializer: JSONParameterSerializer()){ response in
            print(response.text!)
        }
    }
    
    func sendRequest(_ clientId:String, _ urlWithParams:String, _ timeStamp:String, _ signature:String, _ token:String, _ requestBody:String, _ method:String, completion: @escaping (_ token: String, _ errMessage: String) -> ()){
        let body = getDictionaryFromJSONString(jsonString: requestBody)
        AF.request(urlWithParams, method: HTTPMethod.init(rawValue: method),
                   parameters: body as! Parameters, encoding: JSONEncoding.default,
                   headers:["Content-Type":"application/json",
                            "bestsign-client-id": clientId,
                            "bestsign-sign-timestamp": timeStamp,
                            "bestsign-signature-type": "RSA256",
                            "bestsign-signature": signature,
                            "Authorization":"application/json"])
            .validate().responseJSON { (response) in
                switch response.result {
                case .success(let value):
                    let result = JSON(value)
                    if let token = result["data"]["accessToken"].string {
                        completion(token, "")
                        break
                    }else if let errMessage = result["message"].string{
                        completion("", errMessage)
                        break
                    }
                case .failure(let error):
                    print(error)
                    completion("", "")
                    break
                }
            }
    }
    
    @IBAction func signButtonAction(_ sender: Any) {
        let clientId_t = clientId.stringValue.trimmingCharacters(in: .whitespaces)
        let timeStamp_t = timeStamp.stringValue.trimmingCharacters(in: .whitespaces)
        let privateKey = addRSAHeader(privateKeyInit.string.trimmingCharacters(in: .whitespaces))
        let newRequestBody = requestBody.string.trimmingCharacters( in : .whitespacesAndNewlines)
        let requestBody_temp = try? JSONSerialization.data(withJSONObject: convertToDictionary(text: newRequestBody) as AnyObject, options: JSONSerialization.WritingOptions())
        let requestBody_t = String(data: requestBody_temp!, encoding: .utf8)!
        let encodedApi = apiName.stringValue.trimmingCharacters(in: .whitespacesAndNewlines).addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
        let urlWithParams_t = chooseHost.stringValue + encodedApi
        let signData = String(format: "bestsign-client-id=%@bestsign-sign-timestamp=%@bestsign-signature-type=%@request-body=%@uri=%@", arguments: [clientId_t, timeStamp_t, "RSA256", requestBody_t.md5, encodedApi])
        print("最开始的body: " + newRequestBody)
        print("算签的body: " + requestBody_t)
        print("sign String: \(signData)")
    
        let request: Data = signData.data(using: .utf8)!
        let data = try? CC.RSA.sign(request, derKey: SwKeyConvert.PrivateKey.pemToPKCS1DER(privateKey), padding: .pkcs15, digest: .sha256, saltLen: 16)
        if data == nil {
            errMsg.stringValue = "私钥格式或者位数有误"
            return
        }else{
            let sign:String! = data?.base64EncodedString()
            let signature_t = URLEncode(sign)
            signatureField.stringValue = signature_t
            
            testFunc(clientId_t, urlWithParams_t, timeStamp_t, signature_t, "7b53ced2-4900-42c4-871f-ac53241b3511", requestBody_t)
        }
        /*
        signatureField.stringValue = ""
        errMsg.stringValue = ""
        /*
         获取token
         */
        let group = DispatchGroup()
        group.enter()
        queryToken(completion:{(token, errMessage) in
            if errMessage != "" {
                self.errMsg.stringValue = errMessage
            }else{
                self.tokenCache = token
            }
            group.leave()
        })
        
        group.notify(queue: DispatchQueue.main) {
            print("all info data has been received")
            print("token是: " + self.tokenCache)
        }
        print("现在选择的是： " + chooseHost.stringValue)
        
        
        
        let newRequestBody = requestBody.string.trimmingCharacters( in : .whitespacesAndNewlines)
        let body = getDictionaryFromJSONString(jsonString: newRequestBody) as! Parameters
        print(body)
        /*
         判空
         */
        switch "" {
        case clientId.stringValue:
            errMsg.stringValue = "clientId不可为空"
            return
        case timeStamp.stringValue:
            errMsg.stringValue = "timeStamp不可为空"
            return
        case chooseHost.stringValue:
            errMsg.stringValue = "host不可为空"
            return
        case privateKeyInit.string:
            errMsg.stringValue = "privateKey不可为空"
            return
        case apiName.stringValue:
            errMsg.stringValue = "api名不可为空"
            return
        default:
            break
        }
        /*
         获取请求头信息
         */
        let privateKey = addRSAHeader(privateKeyInit.string.trimmingCharacters(in: .whitespaces))
        let newRequestBody = requestBody.string.trimmingCharacters( in : .whitespacesAndNewlines)
        let encodedApi = apiName.stringValue.trimmingCharacters(in: .whitespacesAndNewlines).addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
        let signData = String(format: "bestsign-client-id=%@bestsign-sign-timestamp=%@bestsign-signature-type=%@request-body=%@uri=%@", arguments: [clientId.stringValue.trimmingCharacters(in: .whitespaces), timeStamp.stringValue.trimmingCharacters(in: .whitespaces), "RSA256", newRequestBody.md5, encodedApi])
        print(newRequestBody)
        print("sign String: \(signData)")
    
        let request: Data = signData.data(using: .utf8)!
        let data = try? CC.RSA.sign(request, derKey: SwKeyConvert.PrivateKey.pemToPKCS1DER(privateKey), padding: .pkcs15, digest: .sha256, saltLen: 16)
        if data == nil {
            errMsg.stringValue = "私钥格式或者位数有误"
            return
        }else{
            let sign:String! = data?.base64EncodedString()
            signatureField.stringValue = URLEncode(sign)
        }
        
        /*
         填充信息
         */
        tokenField.stringValue = self.tokenCache
        */
    }
    
    @IBAction func getTimeStamp(_ sender: Any) {
        timeStamp.stringValue = ""
        let millisecond = Date().milliStamp
        timeStamp.stringValue = millisecond
    }
    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }

}

