 #import <Foundation/Foundation.h>

//! Project version number for SwCrypt.
FOUNDATION_EXPORT double SwCryptVersionNumber;

//! Project version string for SwCrypt.
FOUNDATION_EXPORT const unsigned char SwCryptVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwCrypt/PublicHeader.h>


