package com.example.callback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CallbackApplicationTests {

	@Test
	void contextLoads() {
	}

}
