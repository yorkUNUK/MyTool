异步通知服务使用说明：

服务端口默认为8888  可在application.properties中修改端口  服务地址：http://你的host:你的端口/callback   可访问 http://你的host:你的端口/healthcheck 来查看服务的健康检查

注意事项：

1. 异步通知本身为jar包服务，可打包成系统service运行。

2. 可同时接收旗舰版与工具版的异步通知。

3. 旗舰版的异步通知支持后台的aes加密。

4. jar包需要和相应的 application.properties 文件放在同一个目录下。

5. 有三种log文件，服务启动后会自动创建logs目录，目录的结构为，logs->openapi->工具版的异步通知，logs->ultimate->旗舰版的异步通知，logs->全局日志。

6. 整体配置方法和混3类似，系统服务的.service文件需要放在 /etc/systemd/system/目录下
