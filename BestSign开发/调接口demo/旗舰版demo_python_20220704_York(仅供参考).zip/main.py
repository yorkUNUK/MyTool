# -*- coding: utf-8 -*-
"""
@Time ： 2022/7/1 2:29 PM
@Auth ： York
@File ：BestSignClient.py
@IDE ：PyCharm
"""
import base64
import configparser

from BestSignClient import BestSignClient

if __name__ == '__main__':
    # 读取开发者配置
    config = configparser.ConfigParser()
    config.read("developerInfo.ini", encoding="utf-8")
    my_BestSignClient = BestSignClient(
        config["developer"]["clientId"],
        config["developer"]["clientSecret"],
        config["developer"]["privateKey"],
        config["developer"]["host_test"]
    )

    # 发送合同
    requestData = {
        "templateId": "2902275519070340097",
        "roles": [
            {
                "roleId": "3062952243905954823",
                "userInfo": {
                    "userAccount": "18236922636",
                    "enterpriseName": "上上签签签公司"
                }
            }
        ]
    }
    result = my_BestSignClient.executeRequest("/api/templates/send-contracts-sync-v2", "POST", requestData)
    print(result)

    # 查询模板列表

    result = my_BestSignClient.executeRequest("/api/templates/v2?currentPage=1&pageSize=20&account=15867397177&enterpriseName=徐宇超市场经营管理有限公司", "GET", "")
    print(result)

    # 下载合同

    requestData = {
        "contractIds": [
            "3088326535149873161"
        ],
        "fileType": "pdf"
    }
    result = my_BestSignClient.executeRequest("/api/contracts/download-file", "POST", requestData)
    with open("/Users/edianyun/Downloads/python下载demo.pdf", "wb") as f:
        if "encodeByBase64" in requestData and requestData["encodeByBase64"]:
            f.write(base64.b64decode(result))
        else:
            f.write(result)
    f.close()

