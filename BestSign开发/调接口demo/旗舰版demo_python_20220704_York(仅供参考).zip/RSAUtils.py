# -*- coding: utf-8 -*-
"""
@Time ： 2022/7/1 3:22 PM
@Auth ： York
@File ：RSAUtils.py
@IDE ：PyCharm
"""

import base64
import urllib.parse
from Crypto.Hash import SHA256
from Crypto.PublicKey import RSA
from Crypto.Signature import PKCS1_v1_5


def RSA_sign(content, privateKey):
    private_keyBytes = base64.b64decode(privateKey)
    priKey = RSA.importKey(private_keyBytes)
    signer = PKCS1_v1_5.new(priKey,)
    # SIGNATURE_ALGORITHM = "SHA256withRSA"
    hash_obj = SHA256.new(content.encode('utf-8'))
    signature = urllib.parse.quote(base64.b64encode(signer.sign(hash_obj)).decode('utf-8'), safe='')
    return signature
