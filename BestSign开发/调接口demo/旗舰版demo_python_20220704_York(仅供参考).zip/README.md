##注意事项

 1. 确保您的机器上已有python3, pip3
 2. 您已有上上签的开发者

developerInfo.ini 文件里为开发商者配置，请提前配置好您的开发者信息
main.py中包含了三个接口的请求示例，请自行调整参数

终端中输入

    pip3 install -r requirements

然后运行

    python3 main.py

如遇报错 

    ModuleNotFoundError: No module named 'Crypto'

则需要调整python的site-packages中的crypto的包的命名，具体操作步骤如下：  

###pycharm
如果是pycharm，那么会有一个project自带的venv虚拟环境，在  
venv -> lib -> python3.7 -> site-package 路径下  
找到 crypto 的包并重命名为 Crypto 即可。

###本机terminal
如果是本机直接跑的python，可以这样调整： 

打开终端 并进入python3  
```shell
>> import crypto
>> crypto.__file__
```
于此会显示在本机的 crypto 包的安装路径，在此路径下找到此包重命名为 Crypto 即可

    