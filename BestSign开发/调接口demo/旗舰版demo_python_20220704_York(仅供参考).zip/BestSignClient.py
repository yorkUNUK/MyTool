# -*- coding: utf-8 -*-
"""
@Time ： 2022/7/1 2:29 PM
@Auth ： York
@File ：BestSignClient.py
@IDE ：PyCharm
"""
import base64
import urllib

import requests
import json
import hashlib
import RSAUtils
import time


def getRequestMD5(requestData):
    md5 = hashlib.md5()
    md5.update(requestData.encode(encoding="utf-8"))
    return md5.hexdigest()


class BestSignClient:

    def __init__(self, clientId, clientSecret, privateKey, host):
        self.clientId = clientId
        self.clientSecret = clientSecret
        self.privateKey = privateKey
        self.host = host
        self.tokenCache = None
        self.retryTime = 3

    def queryToken(self):
        if self.tokenCache is None:
            url = "/api/oa2/client-credentials/token"
            jsonBody = {"clientId": self.clientId, "clientSecret": self.clientSecret}
            headers = {"Content-Type": "application/json"}
            response = requests.post(self.host + url, data=json.dumps(jsonBody), headers=headers)
            resJson = json.loads(response.text)
            if response.status_code == 200:
                if resJson["code"] == "0":
                    token = resJson["data"]["accessToken"]
                    self.tokenCache = token
                    return token
                else:
                    print(resJson)
                    print("请检查开发者信息")
                    exit(0)
            else:
                print("请检查网络")
                exit(0)
        else:
            return self.tokenCache

    def executeRequest(self, uriWithParam, method, requestData):
        while self.retryTime > 0:
            token = self.queryToken()
            timeStamp = str(round(time.time() * 1000))  # 毫秒级时间戳
            uriWithParam = urllib.parse.quote(uriWithParam, safe=':/=?#&')  # 对请求中的中文进行encode
            signature = self.signRequest(uriWithParam, timeStamp, requestData)
            urlWithQueryParam = "{}{}".format(self.host, uriWithParam)
            headers = {
                "Content-Type": "application/json",
                "bestsign-client-id": self.clientId,
                "bestsign-sign-timestamp": timeStamp,
                "bestsign-signature-type": "RSA256",
                "bestsign-signature": signature,
                "Authorization": "bearer " + token}
            if method == "POST":
                response = requests.post(urlWithQueryParam, data=json.dumps(requestData, separators=(',', ':')),
                                         headers=headers)
                if response.status_code == 200:
                    if response.headers.get("Content-Type") == "application/zip" or response.headers.get(
                            "Content-Type") == "application/pdf":
                        return response.content
                    else:
                        return response.text
                elif response.status_code == 401:
                    self.invalidToken(token)
                else:
                    print("response code: " + response.status_code)
                    print("response: " + response.text)

            elif method == "GET":
                response = requests.get(urlWithQueryParam, data=json.dumps(requestData, separators=(',', ':')),
                                        headers=headers)
                if response.status_code == 200:
                    return response.text
                elif response.status_code == 401:
                    self.invalidToken(token)
                else:
                    print("response code: " + response.status_code)
                    print("response: " + response.text)
            else:
                print("非POST或GET请求")
                exit(0)
            self.retryTime = self.retryTime - 1

    def signRequest(self, uriWithParam, timeStamp, requestData):
        content = "bestsign-client-id={}bestsign-sign-timestamp={}bestsign-signature-type={}request-body={}uri={}".format(
            self.clientId,
            timeStamp,
            "RSA256",
            getRequestMD5(json.dumps(requestData, separators=(',', ':'))),
            uriWithParam
        )
        sign = RSAUtils.RSA_sign(content, self.privateKey)
        return sign

    def invalidToken(self, oldToken):
        if oldToken == self.tokenCache:
            self.tokenCache = None
