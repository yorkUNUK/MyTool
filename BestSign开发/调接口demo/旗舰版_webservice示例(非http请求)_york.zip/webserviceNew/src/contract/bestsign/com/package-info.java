@javax.xml.bind.annotation.XmlSchema(namespace = "com.bestsign.contract", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package contract.bestsign.com;
