
package contract.bestsign.com;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the contract.bestsign.com package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _CreateContract_QNAME = new QName("com.bestsign.contract", "createContract");
    private final static QName _CreateContractResponse_QNAME = new QName("com.bestsign.contract", "createContractResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: contract.bestsign.com
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CreateContract }
     * 
     */
    public CreateContract createCreateContract() {
        return new CreateContract();
    }

    /**
     * Create an instance of {@link CreateContractResponse }
     * 
     */
    public CreateContractResponse createCreateContractResponse() {
        return new CreateContractResponse();
    }

    /**
     * Create an instance of {@link FillLabelPO }
     * 
     */
    public FillLabelPO createFillLabelPO() {
        return new FillLabelPO();
    }

    /**
     * Create an instance of {@link UserInfo }
     * 
     */
    public UserInfo createUserInfo() {
        return new UserInfo();
    }

    /**
     * Create an instance of {@link CreateSignLabelPO }
     * 
     */
    public CreateSignLabelPO createCreateSignLabelPO() {
        return new CreateSignLabelPO();
    }

    /**
     * Create an instance of {@link ConfirmationLetterItemPO }
     * 
     */
    public ConfirmationLetterItemPO createConfirmationLetterItemPO() {
        return new ConfirmationLetterItemPO();
    }

    /**
     * Create an instance of {@link CreateContractConfigPO }
     * 
     */
    public CreateContractConfigPO createCreateContractConfigPO() {
        return new CreateContractConfigPO();
    }

    /**
     * Create an instance of {@link RealNameAuthentication }
     * 
     */
    public RealNameAuthentication createRealNameAuthentication() {
        return new RealNameAuthentication();
    }

    /**
     * Create an instance of {@link CreateDescribeField }
     * 
     */
    public CreateDescribeField createCreateDescribeField() {
        return new CreateDescribeField();
    }

    /**
     * Create an instance of {@link ReceiverInfo }
     * 
     */
    public ReceiverInfo createReceiverInfo() {
        return new ReceiverInfo();
    }

    /**
     * Create an instance of {@link CreateDocumentPO }
     * 
     */
    public CreateDocumentPO createCreateDocumentPO() {
        return new CreateDocumentPO();
    }

    /**
     * Create an instance of {@link AttachRequired }
     * 
     */
    public AttachRequired createAttachRequired() {
        return new AttachRequired();
    }

    /**
     * Create an instance of {@link CommunicateInfoVO }
     * 
     */
    public CommunicateInfoVO createCommunicateInfoVO() {
        return new CommunicateInfoVO();
    }

    /**
     * Create an instance of {@link PrivateLetterFileInfo }
     * 
     */
    public PrivateLetterFileInfo createPrivateLetterFileInfo() {
        return new PrivateLetterFileInfo();
    }

    /**
     * Create an instance of {@link DefaultValuePO }
     * 
     */
    public DefaultValuePO createDefaultValuePO() {
        return new DefaultValuePO();
    }

    /**
     * Create an instance of {@link DynamicPlaceHolderPO }
     * 
     */
    public DynamicPlaceHolderPO createDynamicPlaceHolderPO() {
        return new DynamicPlaceHolderPO();
    }

    /**
     * Create an instance of {@link ApprovalWorkFlowStepPO }
     * 
     */
    public ApprovalWorkFlowStepPO createApprovalWorkFlowStepPO() {
        return new ApprovalWorkFlowStepPO();
    }

    /**
     * Create an instance of {@link ApprovalWorkFlowPO }
     * 
     */
    public ApprovalWorkFlowPO createApprovalWorkFlowPO() {
        return new ApprovalWorkFlowPO();
    }

    /**
     * Create an instance of {@link SignerProxyClaimer }
     * 
     */
    public SignerProxyClaimer createSignerProxyClaimer() {
        return new SignerProxyClaimer();
    }

    /**
     * Create an instance of {@link SignerConfig }
     * 
     */
    public SignerConfig createSignerConfig() {
        return new SignerConfig();
    }

    /**
     * Create an instance of {@link CreateAttachmentPO }
     * 
     */
    public CreateAttachmentPO createCreateAttachmentPO() {
        return new CreateAttachmentPO();
    }

    /**
     * Create an instance of {@link NoticeConfig }
     * 
     */
    public NoticeConfig createNoticeConfig() {
        return new NoticeConfig();
    }

    /**
     * Create an instance of {@link OperatorVO }
     * 
     */
    public OperatorVO createOperatorVO() {
        return new OperatorVO();
    }

    /**
     * Create an instance of {@link CreateContract.SendReq }
     * 
     */
    public CreateContract.SendReq createCreateContractSendReq() {
        return new CreateContract.SendReq();
    }

    /**
     * Create an instance of {@link CreateContractResponse.SendResp }
     * 
     */
    public CreateContractResponse.SendResp createCreateContractResponseSendResp() {
        return new CreateContractResponse.SendResp();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateContract }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "com.bestsign.contract", name = "createContract")
    public JAXBElement<CreateContract> createCreateContract(CreateContract value) {
        return new JAXBElement<CreateContract>(_CreateContract_QNAME, CreateContract.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateContractResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "com.bestsign.contract", name = "createContractResponse")
    public JAXBElement<CreateContractResponse> createCreateContractResponse(CreateContractResponse value) {
        return new JAXBElement<CreateContractResponse>(_CreateContractResponse_QNAME, CreateContractResponse.class, null, value);
    }

}
