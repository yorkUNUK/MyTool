
package contract.bestsign.com;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>saveLocation的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * <p>
 * <pre>
 * &lt;simpleType name="saveLocation">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="REMOTE"/>
 *     &lt;enumeration value="LOCAL"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "saveLocation")
@XmlEnum
public enum SaveLocation {

    REMOTE,
    LOCAL;

    public String value() {
        return name();
    }

    public static SaveLocation fromValue(String v) {
        return valueOf(v);
    }

}
