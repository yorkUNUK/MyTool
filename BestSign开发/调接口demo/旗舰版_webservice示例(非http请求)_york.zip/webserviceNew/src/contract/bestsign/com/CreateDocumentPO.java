
package contract.bestsign.com;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>createDocumentPO complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="createDocumentPO">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="appendingSignLabels" type="{com.bestsign.contract}createSignLabelPO" maxOccurs="unbounded" minOccurs="0" form="qualified"/>
 *         &lt;element name="attachments" type="{com.bestsign.contract}createAttachmentPO" maxOccurs="unbounded" minOccurs="0" form="qualified"/>
 *         &lt;element name="content" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="qualified"/>
 *         &lt;element name="contentPageSize" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0" form="qualified"/>
 *         &lt;element name="contractConfig" type="{com.bestsign.contract}createContractConfigPO" minOccurs="0" form="qualified"/>
 *         &lt;element name="descriptionFields" type="{com.bestsign.contract}createDescribeField" maxOccurs="unbounded" minOccurs="0" form="qualified"/>
 *         &lt;element name="disabled" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0" form="qualified"/>
 *         &lt;element name="documentId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0" form="qualified"/>
 *         &lt;element name="fileName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="qualified"/>
 *         &lt;element name="order" type="{http://www.w3.org/2001/XMLSchema}int" form="qualified"/>
 *         &lt;element name="fixedPlaceHolders" type="{com.bestsign.contract}fillLabelPO" maxOccurs="unbounded" minOccurs="0" form="qualified"/>
 *         &lt;element name="dynamicPlaceHolderRows" type="{com.bestsign.contract}dynamicPlaceHolderPO" maxOccurs="unbounded" minOccurs="0" form="qualified"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createDocumentPO", propOrder = {
    "appendingSignLabels",
    "attachments",
    "content",
    "contentPageSize",
    "contractConfig",
    "descriptionFields",
    "disabled",
    "documentId",
    "fileName",
    "order",
    "fixedPlaceHolders",
    "dynamicPlaceHolderRows"
})
public class CreateDocumentPO {

    @XmlElement(nillable = true)
    protected List<CreateSignLabelPO> appendingSignLabels;
    @XmlElement(nillable = true)
    protected List<CreateAttachmentPO> attachments;
    protected String content;
    protected Integer contentPageSize;
    protected CreateContractConfigPO contractConfig;
    @XmlElement(nillable = true)
    protected List<CreateDescribeField> descriptionFields;
    protected Boolean disabled;
    protected Long documentId;
    protected String fileName;
    protected int order;
    @XmlElement(nillable = true)
    protected List<FillLabelPO> fixedPlaceHolders;
    @XmlElement(nillable = true)
    protected List<DynamicPlaceHolderPO> dynamicPlaceHolderRows;

    /**
     * Gets the value of the appendingSignLabels property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the appendingSignLabels property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAppendingSignLabels().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CreateSignLabelPO }
     * 
     * 
     */
    public List<CreateSignLabelPO> getAppendingSignLabels() {
        if (appendingSignLabels == null) {
            appendingSignLabels = new ArrayList<CreateSignLabelPO>();
        }
        return this.appendingSignLabels;
    }

    /**
     * Gets the value of the attachments property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the attachments property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAttachments().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CreateAttachmentPO }
     * 
     * 
     */
    public List<CreateAttachmentPO> getAttachments() {
        if (attachments == null) {
            attachments = new ArrayList<CreateAttachmentPO>();
        }
        return this.attachments;
    }

    /**
     * 获取content属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContent() {
        return content;
    }

    /**
     * 设置content属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContent(String value) {
        this.content = value;
    }

    /**
     * 获取contentPageSize属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getContentPageSize() {
        return contentPageSize;
    }

    /**
     * 设置contentPageSize属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setContentPageSize(Integer value) {
        this.contentPageSize = value;
    }

    /**
     * 获取contractConfig属性的值。
     * 
     * @return
     *     possible object is
     *     {@link CreateContractConfigPO }
     *     
     */
    public CreateContractConfigPO getContractConfig() {
        return contractConfig;
    }

    /**
     * 设置contractConfig属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link CreateContractConfigPO }
     *     
     */
    public void setContractConfig(CreateContractConfigPO value) {
        this.contractConfig = value;
    }

    /**
     * Gets the value of the descriptionFields property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the descriptionFields property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDescriptionFields().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CreateDescribeField }
     * 
     * 
     */
    public List<CreateDescribeField> getDescriptionFields() {
        if (descriptionFields == null) {
            descriptionFields = new ArrayList<CreateDescribeField>();
        }
        return this.descriptionFields;
    }

    /**
     * 获取disabled属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDisabled() {
        return disabled;
    }

    /**
     * 设置disabled属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDisabled(Boolean value) {
        this.disabled = value;
    }

    /**
     * 获取documentId属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getDocumentId() {
        return documentId;
    }

    /**
     * 设置documentId属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setDocumentId(Long value) {
        this.documentId = value;
    }

    /**
     * 获取fileName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * 设置fileName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileName(String value) {
        this.fileName = value;
    }

    /**
     * 获取order属性的值。
     * 
     */
    public int getOrder() {
        return order;
    }

    /**
     * 设置order属性的值。
     * 
     */
    public void setOrder(int value) {
        this.order = value;
    }

    /**
     * Gets the value of the fixedPlaceHolders property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the fixedPlaceHolders property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFixedPlaceHolders().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FillLabelPO }
     * 
     * 
     */
    public List<FillLabelPO> getFixedPlaceHolders() {
        if (fixedPlaceHolders == null) {
            fixedPlaceHolders = new ArrayList<FillLabelPO>();
        }
        return this.fixedPlaceHolders;
    }

    /**
     * Gets the value of the dynamicPlaceHolderRows property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the dynamicPlaceHolderRows property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDynamicPlaceHolderRows().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DynamicPlaceHolderPO }
     * 
     * 
     */
    public List<DynamicPlaceHolderPO> getDynamicPlaceHolderRows() {
        if (dynamicPlaceHolderRows == null) {
            dynamicPlaceHolderRows = new ArrayList<DynamicPlaceHolderPO>();
        }
        return this.dynamicPlaceHolderRows;
    }

}
