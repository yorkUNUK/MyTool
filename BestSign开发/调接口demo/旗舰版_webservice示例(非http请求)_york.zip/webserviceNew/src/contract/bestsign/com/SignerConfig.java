
package contract.bestsign.com;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>signerConfig complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="signerConfig">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="accessPassword" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="qualified"/>
 *         &lt;element name="archiveId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0" form="qualified"/>
 *         &lt;element name="attachmentRequired" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0" form="qualified"/>
 *         &lt;element name="autoSign" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0" form="qualified"/>
 *         &lt;element name="contractPayer" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0" form="qualified"/>
 *         &lt;element name="faceFirst" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0" form="qualified"/>
 *         &lt;element name="faceVerify" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0" form="qualified"/>
 *         &lt;element name="forceHandWrite" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0" form="qualified"/>
 *         &lt;element name="handWriteNotAllowed" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0" form="qualified"/>
 *         &lt;element name="handWritingRecognition" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0" form="qualified"/>
 *         &lt;element name="isCertSign" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0" form="qualified"/>
 *         &lt;element name="messageVerifyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="qualified"/>
 *         &lt;element name="mustReadBeforeSign" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0" form="qualified"/>
 *         &lt;element name="newAttachmentRequired" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0" form="qualified"/>
 *         &lt;element name="requireCertType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="qualified"/>
 *         &lt;element name="signImmediately" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0" form="qualified"/>
 *         &lt;element name="signSealFileName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="qualified"/>
 *         &lt;element name="signType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="qualified"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "signerConfig", propOrder = {
    "accessPassword",
    "archiveId",
    "attachmentRequired",
    "autoSign",
    "contractPayer",
    "faceFirst",
    "faceVerify",
    "forceHandWrite",
    "handWriteNotAllowed",
    "handWritingRecognition",
    "isCertSign",
    "messageVerifyCode",
    "mustReadBeforeSign",
    "newAttachmentRequired",
    "requireCertType",
    "signImmediately",
    "signSealFileName",
    "signType"
})
public class SignerConfig {

    protected String accessPassword;
    protected Long archiveId;
    protected Boolean attachmentRequired;
    protected Boolean autoSign;
    protected Boolean contractPayer;
    protected Boolean faceFirst;
    protected Boolean faceVerify;
    protected Boolean forceHandWrite;
    protected Boolean handWriteNotAllowed;
    protected Boolean handWritingRecognition;
    protected Boolean isCertSign;
    protected String messageVerifyCode;
    protected Boolean mustReadBeforeSign;
    protected Boolean newAttachmentRequired;
    protected String requireCertType;
    protected Boolean signImmediately;
    protected String signSealFileName;
    protected String signType;

    /**
     * 获取accessPassword属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccessPassword() {
        return accessPassword;
    }

    /**
     * 设置accessPassword属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccessPassword(String value) {
        this.accessPassword = value;
    }

    /**
     * 获取archiveId属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getArchiveId() {
        return archiveId;
    }

    /**
     * 设置archiveId属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setArchiveId(Long value) {
        this.archiveId = value;
    }

    /**
     * 获取attachmentRequired属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isAttachmentRequired() {
        return attachmentRequired;
    }

    /**
     * 设置attachmentRequired属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAttachmentRequired(Boolean value) {
        this.attachmentRequired = value;
    }

    /**
     * 获取autoSign属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isAutoSign() {
        return autoSign;
    }

    /**
     * 设置autoSign属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAutoSign(Boolean value) {
        this.autoSign = value;
    }

    /**
     * 获取contractPayer属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isContractPayer() {
        return contractPayer;
    }

    /**
     * 设置contractPayer属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setContractPayer(Boolean value) {
        this.contractPayer = value;
    }

    /**
     * 获取faceFirst属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isFaceFirst() {
        return faceFirst;
    }

    /**
     * 设置faceFirst属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setFaceFirst(Boolean value) {
        this.faceFirst = value;
    }

    /**
     * 获取faceVerify属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isFaceVerify() {
        return faceVerify;
    }

    /**
     * 设置faceVerify属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setFaceVerify(Boolean value) {
        this.faceVerify = value;
    }

    /**
     * 获取forceHandWrite属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isForceHandWrite() {
        return forceHandWrite;
    }

    /**
     * 设置forceHandWrite属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setForceHandWrite(Boolean value) {
        this.forceHandWrite = value;
    }

    /**
     * 获取handWriteNotAllowed属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isHandWriteNotAllowed() {
        return handWriteNotAllowed;
    }

    /**
     * 设置handWriteNotAllowed属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setHandWriteNotAllowed(Boolean value) {
        this.handWriteNotAllowed = value;
    }

    /**
     * 获取handWritingRecognition属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isHandWritingRecognition() {
        return handWritingRecognition;
    }

    /**
     * 设置handWritingRecognition属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setHandWritingRecognition(Boolean value) {
        this.handWritingRecognition = value;
    }

    /**
     * 获取isCertSign属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsCertSign() {
        return isCertSign;
    }

    /**
     * 设置isCertSign属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsCertSign(Boolean value) {
        this.isCertSign = value;
    }

    /**
     * 获取messageVerifyCode属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessageVerifyCode() {
        return messageVerifyCode;
    }

    /**
     * 设置messageVerifyCode属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessageVerifyCode(String value) {
        this.messageVerifyCode = value;
    }

    /**
     * 获取mustReadBeforeSign属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isMustReadBeforeSign() {
        return mustReadBeforeSign;
    }

    /**
     * 设置mustReadBeforeSign属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setMustReadBeforeSign(Boolean value) {
        this.mustReadBeforeSign = value;
    }

    /**
     * 获取newAttachmentRequired属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isNewAttachmentRequired() {
        return newAttachmentRequired;
    }

    /**
     * 设置newAttachmentRequired属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setNewAttachmentRequired(Boolean value) {
        this.newAttachmentRequired = value;
    }

    /**
     * 获取requireCertType属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequireCertType() {
        return requireCertType;
    }

    /**
     * 设置requireCertType属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequireCertType(String value) {
        this.requireCertType = value;
    }

    /**
     * 获取signImmediately属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isSignImmediately() {
        return signImmediately;
    }

    /**
     * 设置signImmediately属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setSignImmediately(Boolean value) {
        this.signImmediately = value;
    }

    /**
     * 获取signSealFileName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSignSealFileName() {
        return signSealFileName;
    }

    /**
     * 设置signSealFileName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSignSealFileName(String value) {
        this.signSealFileName = value;
    }

    /**
     * 获取signType属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSignType() {
        return signType;
    }

    /**
     * 设置signType属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSignType(String value) {
        this.signType = value;
    }

}
