
package contract.bestsign.com;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>realNameAuthentication complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="realNameAuthentication">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="entUserName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="qualified"/>
 *         &lt;element name="idNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="qualified"/>
 *         &lt;element name="requireEnterIdentityAssurance" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0" form="qualified"/>
 *         &lt;element name="requireIdentityAssurance" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0" form="qualified"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "realNameAuthentication", propOrder = {
    "entUserName",
    "idNumber",
    "requireEnterIdentityAssurance",
    "requireIdentityAssurance"
})
public class RealNameAuthentication {

    protected String entUserName;
    protected String idNumber;
    protected Boolean requireEnterIdentityAssurance;
    protected Boolean requireIdentityAssurance;

    /**
     * 获取entUserName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEntUserName() {
        return entUserName;
    }

    /**
     * 设置entUserName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEntUserName(String value) {
        this.entUserName = value;
    }

    /**
     * 获取idNumber属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdNumber() {
        return idNumber;
    }

    /**
     * 设置idNumber属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdNumber(String value) {
        this.idNumber = value;
    }

    /**
     * 获取requireEnterIdentityAssurance属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isRequireEnterIdentityAssurance() {
        return requireEnterIdentityAssurance;
    }

    /**
     * 设置requireEnterIdentityAssurance属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRequireEnterIdentityAssurance(Boolean value) {
        this.requireEnterIdentityAssurance = value;
    }

    /**
     * 获取requireIdentityAssurance属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isRequireIdentityAssurance() {
        return requireIdentityAssurance;
    }

    /**
     * 设置requireIdentityAssurance属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRequireIdentityAssurance(Boolean value) {
        this.requireIdentityAssurance = value;
    }

}
