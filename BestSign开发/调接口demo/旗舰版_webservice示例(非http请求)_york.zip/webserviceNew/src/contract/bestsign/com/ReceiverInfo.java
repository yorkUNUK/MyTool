
package contract.bestsign.com;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>receiverInfo complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="receiverInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="attachRequires" type="{com.bestsign.contract}attachRequired" maxOccurs="unbounded" minOccurs="0" form="qualified"/>
 *         &lt;element name="batchAdd" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0" form="qualified"/>
 *         &lt;element name="communicateInfo" type="{com.bestsign.contract}communicateInfoVO" minOccurs="0" form="qualified"/>
 *         &lt;element name="disabled" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0" form="qualified"/>
 *         &lt;element name="noticeConfig" type="{com.bestsign.contract}noticeConfig" minOccurs="0" form="qualified"/>
 *         &lt;element name="proxyClaimer" type="{com.bestsign.contract}signerProxyClaimer" minOccurs="0" form="qualified"/>
 *         &lt;element name="realNameAuthentication" type="{com.bestsign.contract}realNameAuthentication" minOccurs="0" form="qualified"/>
 *         &lt;element name="receiverId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0" form="qualified"/>
 *         &lt;element name="receiverType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="qualified"/>
 *         &lt;element name="ridingSealY" type="{http://www.w3.org/2001/XMLSchema}float" minOccurs="0" form="qualified"/>
 *         &lt;element name="roleName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="qualified"/>
 *         &lt;element name="routeOrder" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0" form="qualified"/>
 *         &lt;element name="signerConfig" type="{com.bestsign.contract}signerConfig" minOccurs="0" form="qualified"/>
 *         &lt;element name="userInfo" type="{com.bestsign.contract}userInfo" minOccurs="0" form="qualified"/>
 *         &lt;element name="userType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="qualified"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "receiverInfo", propOrder = {
    "attachRequires",
    "batchAdd",
    "communicateInfo",
    "disabled",
    "noticeConfig",
    "proxyClaimer",
    "realNameAuthentication",
    "receiverId",
    "receiverType",
    "ridingSealY",
    "roleName",
    "routeOrder",
    "signerConfig",
    "userInfo",
    "userType"
})
public class ReceiverInfo {

    @XmlElement(nillable = true)
    protected List<AttachRequired> attachRequires;
    protected Boolean batchAdd;
    protected CommunicateInfoVO communicateInfo;
    protected Boolean disabled;
    protected NoticeConfig noticeConfig;
    protected SignerProxyClaimer proxyClaimer;
    protected RealNameAuthentication realNameAuthentication;
    protected Long receiverId;
    protected String receiverType;
    protected Float ridingSealY;
    protected String roleName;
    protected Integer routeOrder;
    protected SignerConfig signerConfig;
    protected UserInfo userInfo;
    protected String userType;

    /**
     * Gets the value of the attachRequires property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the attachRequires property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAttachRequires().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AttachRequired }
     * 
     * 
     */
    public List<AttachRequired> getAttachRequires() {
        if (attachRequires == null) {
            attachRequires = new ArrayList<AttachRequired>();
        }
        return this.attachRequires;
    }

    /**
     * 获取batchAdd属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isBatchAdd() {
        return batchAdd;
    }

    /**
     * 设置batchAdd属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setBatchAdd(Boolean value) {
        this.batchAdd = value;
    }

    /**
     * 获取communicateInfo属性的值。
     * 
     * @return
     *     possible object is
     *     {@link CommunicateInfoVO }
     *     
     */
    public CommunicateInfoVO getCommunicateInfo() {
        return communicateInfo;
    }

    /**
     * 设置communicateInfo属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link CommunicateInfoVO }
     *     
     */
    public void setCommunicateInfo(CommunicateInfoVO value) {
        this.communicateInfo = value;
    }

    /**
     * 获取disabled属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDisabled() {
        return disabled;
    }

    /**
     * 设置disabled属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDisabled(Boolean value) {
        this.disabled = value;
    }

    /**
     * 获取noticeConfig属性的值。
     * 
     * @return
     *     possible object is
     *     {@link NoticeConfig }
     *     
     */
    public NoticeConfig getNoticeConfig() {
        return noticeConfig;
    }

    /**
     * 设置noticeConfig属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link NoticeConfig }
     *     
     */
    public void setNoticeConfig(NoticeConfig value) {
        this.noticeConfig = value;
    }

    /**
     * 获取proxyClaimer属性的值。
     * 
     * @return
     *     possible object is
     *     {@link SignerProxyClaimer }
     *     
     */
    public SignerProxyClaimer getProxyClaimer() {
        return proxyClaimer;
    }

    /**
     * 设置proxyClaimer属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link SignerProxyClaimer }
     *     
     */
    public void setProxyClaimer(SignerProxyClaimer value) {
        this.proxyClaimer = value;
    }

    /**
     * 获取realNameAuthentication属性的值。
     * 
     * @return
     *     possible object is
     *     {@link RealNameAuthentication }
     *     
     */
    public RealNameAuthentication getRealNameAuthentication() {
        return realNameAuthentication;
    }

    /**
     * 设置realNameAuthentication属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link RealNameAuthentication }
     *     
     */
    public void setRealNameAuthentication(RealNameAuthentication value) {
        this.realNameAuthentication = value;
    }

    /**
     * 获取receiverId属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getReceiverId() {
        return receiverId;
    }

    /**
     * 设置receiverId属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setReceiverId(Long value) {
        this.receiverId = value;
    }

    /**
     * 获取receiverType属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiverType() {
        return receiverType;
    }

    /**
     * 设置receiverType属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiverType(String value) {
        this.receiverType = value;
    }

    /**
     * 获取ridingSealY属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Float }
     *     
     */
    public Float getRidingSealY() {
        return ridingSealY;
    }

    /**
     * 设置ridingSealY属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Float }
     *     
     */
    public void setRidingSealY(Float value) {
        this.ridingSealY = value;
    }

    /**
     * 获取roleName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRoleName() {
        return roleName;
    }

    /**
     * 设置roleName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRoleName(String value) {
        this.roleName = value;
    }

    /**
     * 获取routeOrder属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getRouteOrder() {
        return routeOrder;
    }

    /**
     * 设置routeOrder属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRouteOrder(Integer value) {
        this.routeOrder = value;
    }

    /**
     * 获取signerConfig属性的值。
     * 
     * @return
     *     possible object is
     *     {@link SignerConfig }
     *     
     */
    public SignerConfig getSignerConfig() {
        return signerConfig;
    }

    /**
     * 设置signerConfig属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link SignerConfig }
     *     
     */
    public void setSignerConfig(SignerConfig value) {
        this.signerConfig = value;
    }

    /**
     * 获取userInfo属性的值。
     * 
     * @return
     *     possible object is
     *     {@link UserInfo }
     *     
     */
    public UserInfo getUserInfo() {
        return userInfo;
    }

    /**
     * 设置userInfo属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link UserInfo }
     *     
     */
    public void setUserInfo(UserInfo value) {
        this.userInfo = value;
    }

    /**
     * 获取userType属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserType() {
        return userType;
    }

    /**
     * 设置userType属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserType(String value) {
        this.userType = value;
    }

}
