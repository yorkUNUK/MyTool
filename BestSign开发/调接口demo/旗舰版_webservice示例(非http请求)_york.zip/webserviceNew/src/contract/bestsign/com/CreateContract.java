
package contract.bestsign.com;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>createContract complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="createContract">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="sendReq" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="approvalWorkFlow" type="{com.bestsign.contract}approvalWorkFlowPO" minOccurs="0" form="qualified"/>
 *                   &lt;element name="bizNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="qualified"/>
 *                   &lt;element name="contractName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="qualified"/>
 *                   &lt;element name="documentFederationId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0" form="qualified"/>
 *                   &lt;element name="documents" type="{com.bestsign.contract}createDocumentPO" maxOccurs="unbounded" minOccurs="0" form="qualified"/>
 *                   &lt;element name="imageLabels" type="{com.bestsign.contract}fillLabelPO" maxOccurs="unbounded" minOccurs="0" form="qualified"/>
 *                   &lt;element name="pushUrl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="qualified"/>
 *                   &lt;element name="returnUrl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="qualified"/>
 *                   &lt;element name="roles" type="{com.bestsign.contract}receiverInfo" maxOccurs="unbounded" minOccurs="0" form="qualified"/>
 *                   &lt;element name="sendAction" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="qualified"/>
 *                   &lt;element name="sender" type="{com.bestsign.contract}operatorVO" minOccurs="0" form="qualified"/>
 *                   &lt;element name="signOrderly" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0" form="qualified"/>
 *                   &lt;element name="signTextLabels" type="{com.bestsign.contract}defaultValuePO" maxOccurs="unbounded" minOccurs="0" form="qualified"/>
 *                   &lt;element name="templateId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0" form="qualified"/>
 *                   &lt;element name="textLabels" type="{com.bestsign.contract}fillLabelPO" maxOccurs="unbounded" minOccurs="0" form="qualified"/>
 *                   &lt;element name="watermarks" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0" form="qualified"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createContract", propOrder = {
    "sendReq"
})
public class CreateContract {

    @XmlElement(namespace = "")
    protected CreateContract.SendReq sendReq;

    /**
     * 获取sendReq属性的值。
     * 
     * @return
     *     possible object is
     *     {@link CreateContract.SendReq }
     *     
     */
    public CreateContract.SendReq getSendReq() {
        return sendReq;
    }

    /**
     * 设置sendReq属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link CreateContract.SendReq }
     *     
     */
    public void setSendReq(CreateContract.SendReq value) {
        this.sendReq = value;
    }


    /**
     * <p>anonymous complex type的 Java 类。
     * 
     * <p>以下模式片段指定包含在此类中的预期内容。
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="approvalWorkFlow" type="{com.bestsign.contract}approvalWorkFlowPO" minOccurs="0" form="qualified"/>
     *         &lt;element name="bizNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="qualified"/>
     *         &lt;element name="contractName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="qualified"/>
     *         &lt;element name="documentFederationId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0" form="qualified"/>
     *         &lt;element name="documents" type="{com.bestsign.contract}createDocumentPO" maxOccurs="unbounded" minOccurs="0" form="qualified"/>
     *         &lt;element name="imageLabels" type="{com.bestsign.contract}fillLabelPO" maxOccurs="unbounded" minOccurs="0" form="qualified"/>
     *         &lt;element name="pushUrl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="qualified"/>
     *         &lt;element name="returnUrl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="qualified"/>
     *         &lt;element name="roles" type="{com.bestsign.contract}receiverInfo" maxOccurs="unbounded" minOccurs="0" form="qualified"/>
     *         &lt;element name="sendAction" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="qualified"/>
     *         &lt;element name="sender" type="{com.bestsign.contract}operatorVO" minOccurs="0" form="qualified"/>
     *         &lt;element name="signOrderly" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0" form="qualified"/>
     *         &lt;element name="signTextLabels" type="{com.bestsign.contract}defaultValuePO" maxOccurs="unbounded" minOccurs="0" form="qualified"/>
     *         &lt;element name="templateId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0" form="qualified"/>
     *         &lt;element name="textLabels" type="{com.bestsign.contract}fillLabelPO" maxOccurs="unbounded" minOccurs="0" form="qualified"/>
     *         &lt;element name="watermarks" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0" form="qualified"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "approvalWorkFlow",
        "bizNo",
        "contractName",
        "documentFederationId",
        "documents",
        "imageLabels",
        "pushUrl",
        "returnUrl",
        "roles",
        "sendAction",
        "sender",
        "signOrderly",
        "signTextLabels",
        "templateId",
        "textLabels",
        "watermarks"
    })
    public static class SendReq {

        protected ApprovalWorkFlowPO approvalWorkFlow;
        protected String bizNo;
        protected String contractName;
        protected Long documentFederationId;
        @XmlElement(nillable = true)
        protected List<CreateDocumentPO> documents;
        @XmlElement(nillable = true)
        protected List<FillLabelPO> imageLabels;
        protected String pushUrl;
        protected String returnUrl;
        @XmlElement(nillable = true)
        protected List<ReceiverInfo> roles;
        protected String sendAction;
        protected OperatorVO sender;
        protected Boolean signOrderly;
        @XmlElement(nillable = true)
        protected List<DefaultValuePO> signTextLabels;
        protected Long templateId;
        @XmlElement(nillable = true)
        protected List<FillLabelPO> textLabels;
        @XmlElement(nillable = true)
        protected List<String> watermarks;

        /**
         * 获取approvalWorkFlow属性的值。
         * 
         * @return
         *     possible object is
         *     {@link ApprovalWorkFlowPO }
         *     
         */
        public ApprovalWorkFlowPO getApprovalWorkFlow() {
            return approvalWorkFlow;
        }

        /**
         * 设置approvalWorkFlow属性的值。
         * 
         * @param value
         *     allowed object is
         *     {@link ApprovalWorkFlowPO }
         *     
         */
        public void setApprovalWorkFlow(ApprovalWorkFlowPO value) {
            this.approvalWorkFlow = value;
        }

        /**
         * 获取bizNo属性的值。
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getBizNo() {
            return bizNo;
        }

        /**
         * 设置bizNo属性的值。
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setBizNo(String value) {
            this.bizNo = value;
        }

        /**
         * 获取contractName属性的值。
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getContractName() {
            return contractName;
        }

        /**
         * 设置contractName属性的值。
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setContractName(String value) {
            this.contractName = value;
        }

        /**
         * 获取documentFederationId属性的值。
         * 
         * @return
         *     possible object is
         *     {@link Long }
         *     
         */
        public Long getDocumentFederationId() {
            return documentFederationId;
        }

        /**
         * 设置documentFederationId属性的值。
         * 
         * @param value
         *     allowed object is
         *     {@link Long }
         *     
         */
        public void setDocumentFederationId(Long value) {
            this.documentFederationId = value;
        }

        /**
         * Gets the value of the documents property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the documents property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDocuments().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link CreateDocumentPO }
         * 
         * 
         */
        public List<CreateDocumentPO> getDocuments() {
            if (documents == null) {
                documents = new ArrayList<CreateDocumentPO>();
            }
            return this.documents;
        }

        /**
         * Gets the value of the imageLabels property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the imageLabels property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getImageLabels().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link FillLabelPO }
         * 
         * 
         */
        public List<FillLabelPO> getImageLabels() {
            if (imageLabels == null) {
                imageLabels = new ArrayList<FillLabelPO>();
            }
            return this.imageLabels;
        }

        /**
         * 获取pushUrl属性的值。
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPushUrl() {
            return pushUrl;
        }

        /**
         * 设置pushUrl属性的值。
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPushUrl(String value) {
            this.pushUrl = value;
        }

        /**
         * 获取returnUrl属性的值。
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getReturnUrl() {
            return returnUrl;
        }

        /**
         * 设置returnUrl属性的值。
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setReturnUrl(String value) {
            this.returnUrl = value;
        }

        /**
         * Gets the value of the roles property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the roles property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getRoles().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link ReceiverInfo }
         * 
         * 
         */
        public List<ReceiverInfo> getRoles() {
            if (roles == null) {
                roles = new ArrayList<ReceiverInfo>();
            }
            return this.roles;
        }

        /**
         * 获取sendAction属性的值。
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getSendAction() {
            return sendAction;
        }

        /**
         * 设置sendAction属性的值。
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSendAction(String value) {
            this.sendAction = value;
        }

        /**
         * 获取sender属性的值。
         * 
         * @return
         *     possible object is
         *     {@link OperatorVO }
         *     
         */
        public OperatorVO getSender() {
            return sender;
        }

        /**
         * 设置sender属性的值。
         * 
         * @param value
         *     allowed object is
         *     {@link OperatorVO }
         *     
         */
        public void setSender(OperatorVO value) {
            this.sender = value;
        }

        /**
         * 获取signOrderly属性的值。
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public Boolean isSignOrderly() {
            return signOrderly;
        }

        /**
         * 设置signOrderly属性的值。
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setSignOrderly(Boolean value) {
            this.signOrderly = value;
        }

        /**
         * Gets the value of the signTextLabels property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the signTextLabels property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getSignTextLabels().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link DefaultValuePO }
         * 
         * 
         */
        public List<DefaultValuePO> getSignTextLabels() {
            if (signTextLabels == null) {
                signTextLabels = new ArrayList<DefaultValuePO>();
            }
            return this.signTextLabels;
        }

        /**
         * 获取templateId属性的值。
         * 
         * @return
         *     possible object is
         *     {@link Long }
         *     
         */
        public Long getTemplateId() {
            return templateId;
        }

        /**
         * 设置templateId属性的值。
         * 
         * @param value
         *     allowed object is
         *     {@link Long }
         *     
         */
        public void setTemplateId(Long value) {
            this.templateId = value;
        }

        /**
         * Gets the value of the textLabels property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the textLabels property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getTextLabels().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link FillLabelPO }
         * 
         * 
         */
        public List<FillLabelPO> getTextLabels() {
            if (textLabels == null) {
                textLabels = new ArrayList<FillLabelPO>();
            }
            return this.textLabels;
        }

        /**
         * Gets the value of the watermarks property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the watermarks property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getWatermarks().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getWatermarks() {
            if (watermarks == null) {
                watermarks = new ArrayList<String>();
            }
            return this.watermarks;
        }

    }

}
