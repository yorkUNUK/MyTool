
package contract.bestsign.com;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>noticeConfig complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="noticeConfig">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="downloadReceiveEmail" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="qualified"/>
 *         &lt;element name="needNotice" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0" form="qualified"/>
 *         &lt;element name="noticeAfterShared" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0" form="qualified"/>
 *         &lt;element name="noticeInEnglish" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0" form="qualified"/>
 *         &lt;element name="noticeMail" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="qualified"/>
 *         &lt;element name="noticePhone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="qualified"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "noticeConfig", propOrder = {
    "downloadReceiveEmail",
    "needNotice",
    "noticeAfterShared",
    "noticeInEnglish",
    "noticeMail",
    "noticePhone"
})
public class NoticeConfig {

    protected String downloadReceiveEmail;
    protected Boolean needNotice;
    protected Boolean noticeAfterShared;
    protected Boolean noticeInEnglish;
    protected String noticeMail;
    protected String noticePhone;

    /**
     * 获取downloadReceiveEmail属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDownloadReceiveEmail() {
        return downloadReceiveEmail;
    }

    /**
     * 设置downloadReceiveEmail属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDownloadReceiveEmail(String value) {
        this.downloadReceiveEmail = value;
    }

    /**
     * 获取needNotice属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isNeedNotice() {
        return needNotice;
    }

    /**
     * 设置needNotice属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setNeedNotice(Boolean value) {
        this.needNotice = value;
    }

    /**
     * 获取noticeAfterShared属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isNoticeAfterShared() {
        return noticeAfterShared;
    }

    /**
     * 设置noticeAfterShared属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setNoticeAfterShared(Boolean value) {
        this.noticeAfterShared = value;
    }

    /**
     * 获取noticeInEnglish属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isNoticeInEnglish() {
        return noticeInEnglish;
    }

    /**
     * 设置noticeInEnglish属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setNoticeInEnglish(Boolean value) {
        this.noticeInEnglish = value;
    }

    /**
     * 获取noticeMail属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNoticeMail() {
        return noticeMail;
    }

    /**
     * 设置noticeMail属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNoticeMail(String value) {
        this.noticeMail = value;
    }

    /**
     * 获取noticePhone属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNoticePhone() {
        return noticePhone;
    }

    /**
     * 设置noticePhone属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNoticePhone(String value) {
        this.noticePhone = value;
    }

}
