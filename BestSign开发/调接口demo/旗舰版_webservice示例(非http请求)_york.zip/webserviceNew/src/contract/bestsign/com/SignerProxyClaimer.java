
package contract.bestsign.com;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>signerProxyClaimer complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="signerProxyClaimer">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="agentEntId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0" form="qualified"/>
 *         &lt;element name="devAccountIds" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0" form="qualified"/>
 *         &lt;element name="ifProxyClaimer" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0" form="qualified"/>
 *         &lt;element name="proxyClaimerAccounts" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0" form="qualified"/>
 *         &lt;element name="proxyClaimerNoticeMobile" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="qualified"/>
 *         &lt;element name="roleName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="qualified"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "signerProxyClaimer", propOrder = {
    "agentEntId",
    "devAccountIds",
    "ifProxyClaimer",
    "proxyClaimerAccounts",
    "proxyClaimerNoticeMobile",
    "roleName"
})
public class SignerProxyClaimer {

    protected Long agentEntId;
    @XmlElement(nillable = true)
    protected List<String> devAccountIds;
    protected Boolean ifProxyClaimer;
    @XmlElement(nillable = true)
    protected List<String> proxyClaimerAccounts;
    protected String proxyClaimerNoticeMobile;
    protected String roleName;

    /**
     * 获取agentEntId属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getAgentEntId() {
        return agentEntId;
    }

    /**
     * 设置agentEntId属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setAgentEntId(Long value) {
        this.agentEntId = value;
    }

    /**
     * Gets the value of the devAccountIds property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the devAccountIds property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDevAccountIds().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getDevAccountIds() {
        if (devAccountIds == null) {
            devAccountIds = new ArrayList<String>();
        }
        return this.devAccountIds;
    }

    /**
     * 获取ifProxyClaimer属性的值。
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIfProxyClaimer() {
        return ifProxyClaimer;
    }

    /**
     * 设置ifProxyClaimer属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIfProxyClaimer(Boolean value) {
        this.ifProxyClaimer = value;
    }

    /**
     * Gets the value of the proxyClaimerAccounts property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the proxyClaimerAccounts property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProxyClaimerAccounts().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getProxyClaimerAccounts() {
        if (proxyClaimerAccounts == null) {
            proxyClaimerAccounts = new ArrayList<String>();
        }
        return this.proxyClaimerAccounts;
    }

    /**
     * 获取proxyClaimerNoticeMobile属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProxyClaimerNoticeMobile() {
        return proxyClaimerNoticeMobile;
    }

    /**
     * 设置proxyClaimerNoticeMobile属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProxyClaimerNoticeMobile(String value) {
        this.proxyClaimerNoticeMobile = value;
    }

    /**
     * 获取roleName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRoleName() {
        return roleName;
    }

    /**
     * 设置roleName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRoleName(String value) {
        this.roleName = value;
    }

}
