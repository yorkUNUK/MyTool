
package contract.bestsign.com;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>communicateInfoVO complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="communicateInfoVO">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="privateLetter" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="qualified"/>
 *         &lt;element name="privateLetterFileInfos" type="{com.bestsign.contract}privateLetterFileInfo" maxOccurs="unbounded" minOccurs="0" form="qualified"/>
 *         &lt;element name="privateLetterFileList" type="{http://www.w3.org/2001/XMLSchema}long" maxOccurs="unbounded" minOccurs="0" form="qualified"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "communicateInfoVO", propOrder = {
    "privateLetter",
    "privateLetterFileInfos",
    "privateLetterFileList"
})
public class CommunicateInfoVO {

    protected String privateLetter;
    @XmlElement(nillable = true)
    protected List<PrivateLetterFileInfo> privateLetterFileInfos;
    @XmlElement(nillable = true)
    protected List<Long> privateLetterFileList;

    /**
     * 获取privateLetter属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrivateLetter() {
        return privateLetter;
    }

    /**
     * 设置privateLetter属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrivateLetter(String value) {
        this.privateLetter = value;
    }

    /**
     * Gets the value of the privateLetterFileInfos property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the privateLetterFileInfos property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPrivateLetterFileInfos().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PrivateLetterFileInfo }
     * 
     * 
     */
    public List<PrivateLetterFileInfo> getPrivateLetterFileInfos() {
        if (privateLetterFileInfos == null) {
            privateLetterFileInfos = new ArrayList<PrivateLetterFileInfo>();
        }
        return this.privateLetterFileInfos;
    }

    /**
     * Gets the value of the privateLetterFileList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the privateLetterFileList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPrivateLetterFileList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Long }
     * 
     * 
     */
    public List<Long> getPrivateLetterFileList() {
        if (privateLetterFileList == null) {
            privateLetterFileList = new ArrayList<Long>();
        }
        return this.privateLetterFileList;
    }

}
