/**
 * @Description: demo for bestsign ultimate api call
 * @author York
 * @date 2022/7/5
 */
'use strict';

const {KEYUTIL, KJUR, hextob64} = require('jsrsasign')
const urlencode = require('urlencode');
const PEM_BEGIN = '-----BEGIN PRIVATE KEY-----\n'
const PEM_END = '\n-----END PRIVATE KEY-----'

function sign(inputString, privateKey) {
    const privateKeyStandard = formatKey(privateKey);
    const key = KEYUTIL.getKey(privateKeyStandard);
    // 创建 Signature 对象，设置签名编码算法
    const signature = new KJUR.crypto.Signature({ alg: 'SHA256withRSA' });
    // 初始化
    signature.init(key);
    // 传入待加密字符串
    signature.updateString(inputString);
    // 生成密文
    const originSign = signature.sign();
    return urlencode(hextob64(originSign));
}

function formatKey(key) {
    if (!key.startsWith(PEM_BEGIN)) {
        key = PEM_BEGIN + key
    }
    if (!key.endsWith(PEM_END)) {
        key = key + PEM_END
    }
    return key
}

module.exports = {sign};