/**
 * @Description: demo for bestsign ultimate api call
 * @author York
 * @date 2022/7/6
 */

const developerConfig = {
    host: "https://api.bestsign.info",
    clientId: "1626074470012587260",
    clientSecret: "be6cc5dc30234774b21f8ed12d831b3d",
    privateKey: "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAKxU/jmowdXypsKW991/g20t5MhQY2lyQkS7Q6jc4QrxPIazGAkubE+fxE852ljKRom/JEsYVUZ4SJeqimVp5U1prlXtrejxkpSA3FZ198ow8b++WV2OazFZmwwJxfdx3znoCM1ZliPauRITfYhDByOZ6VXAntMQcVeIuwSF8rWNAgMBAAECgYA4zEp99oDsYu1TdS58cmp+sYGWA+i/+EifHplOLn59fMTWIHDrlcFc/OtWsVqlqQVWoQj1Ny/j6gEC+9JhWmWYcpXxSg/YwcJQfQ79NHgPIOMtT/cVQ//Vih9qn0y3dQJEt282ttKA3HhHoYfZ8clN2w2yzefZp+5FJHpwxMmSgQJBAO3WcugeTz0cqx8pPbLK45lUtkmJZSyGSGz/edh1+1LrkHKNo+MaXM0h2UdvGPlPTc/6KjBV71tcFqByku3Z6gMCQQC5ffTYy31uWyWw+JG0gvMw/xjHcFW9C6u+2ST7LlcfZ8omW+Uf5zTcXkjMoaQUlVOmt0E7xfSWROKg/LglP5UvAkAHDDG/exZyAyV2+OvhHm38Hyx/pVigJyKCSFe9+FEINf7DxjqzAhb55SThHwOob5cosIsLf6BmHqZ0/rAn6CstAkBhA0Nfb232na0k1Zw+8I4IfiKTjGkLKmN0uVTiGeZvAnVzgnRfLykyaA1jGNcb/M13UDjJ7kpxnS16TTJyKML5AkEAoJ0AkfoFzzWDnVAb3922pvr2DQaqB87XUfiNKoV+FIGdXYnMHjKMMFNV84m+UMj7s2lKB2wS7id4HxqAVTFl6Q=="
}

module.exports = {developerConfig}