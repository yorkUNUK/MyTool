##注意事项

1. 确保您的机器上已有nodejs和npm
2. 您已有上上签的开发者

developerInfo.ini 文件里为开发商者配置，请提前配置好您的开发者信息
demo.py中包含了两个接口的请求示例，请自行调整参数

终端中进入js文件所在目录下

    cnpm install

然后运行

    node demo.js


