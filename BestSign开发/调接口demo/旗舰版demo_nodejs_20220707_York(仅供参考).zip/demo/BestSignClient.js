/**
 * @Description: demo for bestsign ultimate api call
 * @author York
 * @date 2022/7/6
 */
'use strict';

const request = require('request');
const RSAUtils = require("./RSAUtils");
const util = require('util');
const crypto = require('crypto');

class BestSignClient {
    constructor(Host, ClientId, ClientSecret, PrivateKey) {
        this.host = Host;
        this.clientId = ClientId;
        this.clientSecret = ClientSecret;
        this.privateKey = PrivateKey;
    }

    /**
     * 获取token
     * @returns {Promise<unknown>}
     */
    queryToken(){
        return new Promise((resolve,reject) => {
            const requestData = {
                "clientId": this.clientId,
                "clientSecret": this.clientSecret
            };
            request({
                url: this.host + "/api/oa2/client-credentials/token",
                method: "POST",
                json: true,
                headers: {
                    "Content-Type": "application/json",
                },
                body: requestData
            }, function(error, response, body) {
                if (!error && response.statusCode === 200) {
                    resolve(body["data"]["accessToken"]);
                }
                else {
                    console.log(response.statusCode);
                    console.log(body);
                    reject();
                }
            });
        })
    }

    /**
     * 发起api请求
     * @param uriWithParam
     * @param method
     * @param requestData
     * @returns {Promise<void>}
     */
    async executeRequest(uriWithParam, method, requestData){
        const token = await this.queryToken();
        return new Promise((resolve,reject) => {
            const timeStamp = (Math.floor(Date.now())).toString();
            const urlWithQueryParam = util.format("%s%s", this.host, uriWithParam);
            const signRSA = this.signRequest(uriWithParam, timeStamp, requestData);
            request({
                url: urlWithQueryParam,
                method: method,
                json: true,
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": "bearer " + token,
                    "bestsign-sign-timestamp": timeStamp,
                    "bestsign-client-id": this.clientId,
                    "bestsign-signature-type": "RSA256",
                    "bestsign-signature": signRSA,
                },
                body: requestData
            }, function (error, response, body) {
                if (!error && response.statusCode === 200) {
                    resolve(body);
                } else {
                    console.log(response.statusCode);
                    console.log(body);
                    reject();
                }
            });
        })
    }

    /**
     * 签名计算
     * @param uriWithParam
     * @param timeStamp
     * @param requestData
     * @returns {*}
     */
    signRequest(uriWithParam, timeStamp, requestData){
        const md5 = crypto.createHash('md5');
        const md5Result = md5.update(JSON.stringify(requestData)).digest('hex');
        const content = util.format(
            "bestsign-client-id=%sbestsign-sign-timestamp=%sbestsign-signature-type=%srequest-body=%suri=%s",
            this.clientId,
            timeStamp,
            "RSA256",
            md5Result,
            uriWithParam
        )
        return RSAUtils.sign(content, this.privateKey);
    }
}

module.exports = BestSignClient;