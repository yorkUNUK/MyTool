/**
 * @Description: demo for bestsign ultimate api call
 * @author York
 * @date 2022/7/5
 */

'use strict';

const config = require('./developerInfo');
const BestSignClient = require('./BestSignClient');

const bestSignClient = new BestSignClient(
    config.developerConfig.host,
    config.developerConfig.clientId,
    config.developerConfig.clientSecret,
    config.developerConfig.privateKey
);

/**
 * 调试接口
 */
testCreateContract();
testQueryTemplates();

/**
 * 发送合同
 */
function testCreateContract() {
    const requestData = {
        "templateId": "2902275519070340097",
        "roles": [
            {
                "roleId": "3062952243905954823",
                "userInfo": {
                    "userAccount": "18236922636",
                    "enterpriseName": "上上签签签公司"
                }
            }
        ]
    };
    bestSignClient.executeRequest("/api/templates/send-contracts-sync-v2", "POST", requestData).then(result => {
        if (result["code"] == 0) {
            console.log("发送成功");
            console.log("合同ID为: " + result["data"]["contractId"]);
        } else {
            console.log("报错啦");
            console.log(JSON.stringify(result));
        }
    });
}

/**
 * 查询模板列表
 */
function testQueryTemplates() {
    let uri = "/api/templates/v2?currentPage=1&pageSize=20&account=15867397177&enterpriseName=徐宇超市场经营管理有限公司";
    bestSignClient.executeRequest(encodeURI(uri), "GET", "").then(result => {
        if (result["code"] == 0) {
            console.log(JSON.stringify(result));
        } else {
            console.log("报错啦");
            console.log(JSON.stringify(result));
        }
    });
}
