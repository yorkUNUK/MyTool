<?php
namespace BestSignSDK;

define('CONFIG_NAME', 'demo');

require(__DIR__ . '/initialize.php');
require(dirname(__DIR__) . '/src/SDK.php');

error_reporting(E_ALL);

testAll();
echo "\nFinish!\n";

class Tester
{
    private static $instance;
    
    public static function getInstance($config_name = CONFIG_NAME)
    {
        $key = $config_name;
        if (isset(self::$instance[$key]))
        {
            return self::$instance[$key];
        }
        $class = __CLASS__;
        self::$instance[$key] = new $class($config_name);
        return self::$instance[$key];    
    }
    
    private $_config_name = null;
    private $_sdk = null;
    private $_is_output_info = false;
    
    private function __construct($config_name)
    {
        $this->_config_name = $config_name;
        $this->_sdk = $this->_getSdk($config_name);
    }
    
    public function __destruct()
    {
        Logger::flush();
    }
    
    public function test_contractsAppendixFile()
    {
        $this->outputInfo();
        
        $this->addToLog('');
        $this->addToLog('TEST ' . __FUNCTION__ . '......');
        
        $sdk = $this->_sdk;
        $response = $sdk->contractsAppendixFile('2283941012978008072', 'xi_zheng@bestsign.cn', '奥观海科技有限公司');
        
        $this->addToLog('TEST ' . __FUNCTION__ . ' response: ');
        $this->dump2($response);
        $this->addToLog('');
    }
    
    public function test_contractsDetail()
    {
        $this->outputInfo();
        
        $this->addToLog('');
        $this->addToLog('TEST ' . __FUNCTION__ . '......');
        
        $sdk = $this->_sdk;
        $response = $sdk->contractsDetail('2851577729529152515');
        
        $this->addToLog('TEST ' . __FUNCTION__ . ' response: ');
        $this->dump(isset($response['response_json']) ? $response['response_json'] : $response);
        $this->addToLog('');
    }
    
    public function test_contractsDownloadFile()
    {
        $this->outputInfo();
        
        $this->addToLog('');
        $this->addToLog('TEST ' . __FUNCTION__ . '......');
        
        $sdk = $this->_sdk;
        $response = $sdk->contractsDownloadFile(array('2851577729529152515'), Operator::buildData('', ''));
        
        $this->addToLog('TEST ' . __FUNCTION__ . ' response: ');
        $this->dump2($response);
        $this->addToLog('');
    }
    
    public function test_contractsRemind()
    {
        $this->outputInfo();
        
        $this->addToLog('');
        $this->addToLog('TEST ' . __FUNCTION__ . '......');
        
        $sdk = $this->_sdk;
        $response = $sdk->contractsRemind('2851577729529152515');
        
        $this->addToLog('TEST ' . __FUNCTION__ . ' response: ');
        $this->dump(isset($response['response_json']) ? $response['response_json'] : $response);
        $this->addToLog('');
    }
    
    public function test_contractsSign()
    {
        $this->outputInfo();
        
        $this->addToLog('');
        $this->addToLog('TEST ' . __FUNCTION__ . '......');
        
        $sdk = $this->_sdk;
        
        $contractIds = array('2851577729529152515');
        $signer = Signer::buildData('', '');
        $sealName = '公章';
        
        $response = $sdk->contractsSign($contractIds, $signer, $sealName);
        
        $this->addToLog('TEST ' . __FUNCTION__ . ' response: ');
        $this->dump(isset($response['response_json']) ? $response['response_json'] : $response);
        $this->addToLog('');
    }
    
    public function test_entsBoxGetArchiveInfo()
    {
        $this->outputInfo();
        
        $this->addToLog('');
        $this->addToLog('TEST ' . __FUNCTION__ . '......');
        
        $sdk = $this->_sdk;
        
        $archiveId = '2852944782102102021';
        $response = $sdk->entsBoxGetArchiveInfo($archiveId);
        
        $this->addToLog('TEST ' . __FUNCTION__ . ' response: ');
        $this->dump(isset($response['response_json']) ? $response['response_json'] : $response);
        $this->addToLog('');
    }
    
    public function test_entsBoxRequestAuthorizationCollection()
    {
        $this->outputInfo();
        
        $this->addToLog('');
        $this->addToLog('TEST ' . __FUNCTION__ . '......');
        
        $sdk = $this->_sdk;
        
        $archiveId = '2852944782102102021';
        $authorizeEntList = array(
            AuthorizeEnt::buildData('mason_hua@bestsign.com', '杭州上上签北京分公司'),
            AuthorizeEnt::buildData('12000000038', '客户乙公司名称'),
        );
        
        $response = $sdk->entsBoxRequestAuthorizationCollection($archiveId, $authorizeEntList);
        
        $this->addToLog('TEST ' . __FUNCTION__ . ' response: ');
        $this->dump(isset($response['response_json']) ? $response['response_json'] : $response);
        $this->addToLog('');
    }
    
    public function test_entsBoxEntProxyCollection()
    {
        $this->outputInfo();
        
        $this->addToLog('');
        $this->addToLog('TEST ' . __FUNCTION__ . '......');
        
        $sdk = $this->_sdk;
        
        $account = 'mason_hua@bestsign.com';
        $archiveId = '2852944782102102021';
        $entName = '杭州上上签北京分公司';
        $authorizeEntList = array(
            Collection::buildData('MU', '1111111111dddddd'),
        );
        
        $response = $sdk->entsBoxEntProxyCollection($account, $archiveId, $entName, $authorizeEntList);
        
        $this->addToLog('TEST ' . __FUNCTION__ . ' response: ');
        $this->dump(isset($response['response_json']) ? $response['response_json'] : $response);
        $this->addToLog('');
    }
    
    public function test_entsBoxGetEntCollectionList()
    {
        $this->outputInfo();
        
        $this->addToLog('');
        $this->addToLog('TEST ' . __FUNCTION__ . '......');
        
        $sdk = $this->_sdk;
        
        $archiveId = '2852944782102102021';
        $collectionStatus = '';
        $verifyStatus = '';
        $resourceAuthorizationStatus = 0;
        
        $response = $sdk->entsBoxGetEntCollectionList($archiveId, $collectionStatus, $verifyStatus, $resourceAuthorizationStatus);
        
        $this->addToLog('TEST ' . __FUNCTION__ . ' response: ');
        $this->dump(isset($response['response_json']) ? $response['response_json'] : $response);
        $this->addToLog('');
    }
    
    public function test_entsBoxGetEntAuthorizationInfo()
    {
        $this->outputInfo();
        
        $this->addToLog('');
        $this->addToLog('TEST ' . __FUNCTION__ . '......');
        
        $sdk = $this->_sdk;
        
        $archiveId = '2852944782102102021';
        $entName = '杭州上上签北京分公司';
        $requires = array();
        
        $response = $sdk->entsBoxGetEntAuthorizationInfo($archiveId, $entName, $requires);
        
        $this->addToLog('TEST ' . __FUNCTION__ . ' response: ');
        $this->dump(isset($response['response_json']) ? $response['response_json'] : $response);
        $this->addToLog('');
    }
    
    public function test_templatesOverview()
    {
        $this->outputInfo();
        
        $this->addToLog('');
        $this->addToLog('TEST ' . __FUNCTION__ . '......');
    
        $sdk = $this->_sdk;
        $response = $sdk->templatesOverview('2850005811470533637', 'template-detail');
        
        $this->addToLog('TEST ' . __FUNCTION__ . ' response: ');
        $this->dump(isset($response['response_json']) ? $response['response_json'] : $response);
        $this->addToLog('');
    }
    
    public function test_templatesSendContractsSyncV2()
    {
        $this->outputInfo();
        
        $this->addToLog('');
        $this->addToLog('TEST ' . __FUNCTION__ . '......');
    
        $sdk = $this->_sdk;
        
        $templateId = '2850005811470533637';
        $contractName = '百事年度合同';
        $sender = Sender::buildData('Pepsi@bestsign.cn', '百事公司测试账号', '');
        
        $roles = array(
            Role::buildData('2850006510073806849', UserInfo::buildData('11100001129', '昌吉市华国海电器有限公司')),
            Role::buildData('2850006510124138499', UserInfo::buildData('Pepsi@bestsign.cn', '百事公司测试账号')),
        );
        
        $textLabels = array(
            TextLabel::buildData('客户名称（乙方）', '昌吉市华国海电器有限公司'),
            TextLabel::buildData('合同订立期间', '2021年 01月01日'),
            TextLabel::buildData('省', '四川'),
            TextLabel::buildData('市', '成都'),
            TextLabel::buildData('县（区）', '天府'),
            TextLabel::buildData('破瘪包补偿-乐事', '0.80%'),
            TextLabel::buildData('合同终止时间', '2021年 12月31日'),
        );
        
        $documents = array(
            Document::buildData('2850006179839475720', ContractConfig::buildData('百事年度合同', '', '5')),
        );
        
        $documentFederationId = '';
        $signOrderly = true;
        
        $response = $sdk->templatesSendContractsSyncV2($templateId, $contractName, $sender, $roles, $textLabels, $documents, $documentFederationId, $signOrderly);
        
        $this->addToLog('TEST ' . __FUNCTION__ . ' response: ');
        $this->dump(isset($response['response_json']) ? $response['response_json'] : $response);
        $this->addToLog('');
    }
    
    public function test_templatesSendContractsSyncV2_2()
    {
        $this->outputInfo();
        
        $this->addToLog('');
        $this->addToLog('TEST ' . __FUNCTION__ . '......');
    
        $sdk = $this->_sdk;
        
        $templateId = '2858138402451096584';
        $contractName = '百事年度合同';
        $sender = Sender::buildData('Pepsi@bestsign.cn', '百事公司测试账号', '');
        
        $roles = array(
            Role::buildData('2858138404112040966', UserInfo::buildData('bjbestsign@bestsign.info', '新合同模板测试公司')),
            Role::buildData('2858138404153984005', UserInfo::buildData('Pepsi@bestsign.cn', '百事公司测试账号')),
        );
        
        $textLabels = array(
            TextLabel::buildData('MU', 'SMU'),
            TextLabel::buildData('合同订立期间', '2021-08-25'),
            TextLabel::buildData('盖章主体（甲方）', '百事食品（中国）有限公司广州分公司'),
            TextLabel::buildData('甲方注册地址', '广州市天河区花城大道85号2201房之自编01-03单元'),
            TextLabel::buildData('客户名称（乙方）', '成都韩利铱钒商贸有限公司'),
            TextLabel::buildData('经销商注册地址', '广东省广州市天河区'),
            TextLabel::buildData('合同订立期间', '2021-08-25'),
            TextLabel::buildData('品牌1', '乐事'),
            TextLabel::buildData('品牌1-最低起订量', '400'),
            TextLabel::buildData('品牌1-spoke客户 最低起订量', '100'),
            TextLabel::buildData('品牌1-其他要求', '1234567'),
            TextLabel::buildData('品牌1-破瘪包补偿', '0.08'),
        );
        
        $documents = array(
            Document::buildData2('2860849176856495110', '产品清单-百事.pdf', 'JVBERi0xLjcKJcKzx9gNCjEgMCBvYmoNPDwvTmFtZXMgPDwvRGVzdHMgNCAwIFI+PiAvT3V0bGluZXMgNSAwIFIgL1BhZ2VzIDIgMCBSIC9UeXBlIC9DYXRhbG9nPj4NZW5kb2JqDTMgMCBvYmoNPDwvQXV0aG9yICgxOTQ1MSkgL0NvbW1lbnRzICgpIC9Db21wYW55ICgpIC9DcmVhdGlvbkRhdGUgKEQ6MjAyMTA4MjQyMDE5NTUrMTInMTknKSAvQ3JlYXRvciAo/v8AVwBQAFMAIGWHW1cpIC9LZXl3b3JkcyAoKSAvTW9kRGF0ZSAoRDoyMDIxMDgyNDIwMTk1NSsxMicxOScpIC9Qcm9kdWNlciAoKSAvU291cmNlTW9kaWZpZWQgKEQ6MjAyMTA4MjQyMDE5NTUrMTInMTknKSAvU3ViamVjdCAoKSAvVGl0bGUgKCkgL1RyYXBwZWQgL0ZhbHNlPj4NZW5kb2JqDTEzIDAgb2JqDTw8L0FJUyBmYWxzZSAvQk0gL05vcm1hbCAvQ0EgMSAvVHlwZSAvRXh0R1N0YXRlIC9jYSAxPj4NZW5kb2JqDTYgMCBvYmoNPDwvQ29udGVudHMgNyAwIFIgL01lZGlhQm94IFswIDAgNTk1LjMgODQxLjldIC9QYXJlbnQgMiAwIFIgL1Jlc291cmNlcyA8PC9FeHRHU3RhdGUgPDwvR1MxMyAxMyAwIFI+PiAvRm9udCA8PC9GVDggOCAwIFI+Pj4+IC9UeXBlIC9QYWdlPj4NZW5kb2JqDTcgMCBvYmoNPDwvRmlsdGVyIC9GbGF0ZURlY29kZSAvTGVuZ3RoIDM3ND4+DQpzdHJlYW0NCnicvZTbSgMxEIbvhbxDrgWnmWRygiJ07QEKXmgXfADRQnGF1gtf32SzJ90GqrQSwu4/+bL7ZzLJniEXod3EhyMEz58rtmcxpr0G1QQPL+zpmr8zAULzTyb5fejr0Hc1KvjjKswqykYdtmyyLB2XwvPylU1WG1R8+5Gm1/+r3xCROwsUqYpN5d1scVvuwiwH1tsA8XI+FVQUdRQR0LkuOrdH2NkSx6wkpY+w3sXo1aJkD6Hl17xnjsDwMELcYvQt1UVTEjrIE1LSWj/BPKIPQ//jXumzuycFsnVPQPqS9rUHtOexL4Bc5+6bs85BWJ+qa8sQr5hGAZ4a+cY29dd/sHEr9QBudI4OqaMhnXSONhbUkE76GN0ciKrZoQDimEOtezCJDCml6ckkcqS3A7IWGVIZ15NJZEhSHoxu0UZl2Jga26JJDMmuItd/LEApPTidCrAwclyAWCz8kUtuLsyYVYiiK9bf+6F44Ho/gpw/o5/YvgDnlloQDQplbmRzdHJlYW0NZW5kb2JqDTggMCBvYmoNPDwvQmFzZUZvbnQgL0xOVUhORitTaW1TdW4gL0Rlc2NlbmRhbnRGb250cyBbMTAgMCBSXSAvRW5jb2RpbmcgL0lkZW50aXR5LUggL1N1YnR5cGUgL1R5cGUwIC9Ub1VuaWNvZGUgOSAwIFIgL1R5cGUgL0ZvbnQ+Pg1lbmRvYmoNOSAwIG9iag08PC9GaWx0ZXIgL0ZsYXRlRGVjb2RlIC9MZW5ndGggMzA0Pj4NCnN0cmVhbQ0KeJxdkctqwzAQRff+ilmmi2DLzwSMwa+AF33QtB/gSOPUUMtCdhb++86oIYUKJDjMvcPojl93TafHFfw3O8szrjCMWllc5puVCBe8jtoTIahRrndyr5x64/lkPm/LilOnhxny3H+n2rLaDXalmi/4BP6rVWhHfYXdZ30mPt+M+cYJ9QpBUYDCgdo89+alnxB859p3isrjuu3J8qf42AxC6Fj8jiJnhYvpJdpeX9HLAzoF5Cc6hYda/auLu+0yyK/ekjw+HEket8mxYKoqR4fKUZM5KjOm4yEhSqIkYSpPgimuBZGoWu6SJhV3CeOIlWkbsDKs0pAoS6KQqS5bpjRrmZogddSkRJEQPHpWtoEb/T4jf4KShkdC8mYthePW4VLhPEaNj42Z2QC5+P4APxeMqg0KZW5kc3RyZWFtDWVuZG9iag0xNCAwIG9iag08PC9PcmRlcmluZyAoSWRlbnRpdHkpIC9SZWdpc3RyeSAoQWRvYmUpIC9TdXBwbGVtZW50IDA+Pg1lbmRvYmoNMTAgMCBvYmoNPDwvQmFzZUZvbnQgL0xOVUhORitTaW1TdW4gL0NJRFN5c3RlbUluZm8gMTQgMCBSIC9DSURUb0dJRE1hcCAvSWRlbnRpdHkgL0RXIDEwMDAgL0ZvbnREZXNjcmlwdG9yIDExIDAgUiAvU3VidHlwZSAvQ0lERm9udFR5cGUyIC9UeXBlIC9Gb250IC9XIFtdPj4NZW5kb2JqDTExIDAgb2JqDTw8L0FzY2VudCA4NTkgL0F2Z1dpZHRoIDUwMCAvQ2FwSGVpZ2h0IDY4MyAvRGVzY2VudCAtMTQwIC9GbGFncyAzMiAvRm9udEJCb3ggWy03IC0xNDAgMTAwMCA4NTldIC9Gb250RmFtaWx5IChTaW1TdW4pIC9Gb250RmlsZTIgMTIgMCBSIC9Gb250TmFtZSAvTE5VSE5GK1NpbVN1biAvRm9udFN0cmV0Y2ggL05vcm1hbCAvRm9udFdlaWdodCA0MDAgL0l0YWxpY0FuZ2xlIDAgL01heFdpZHRoIDEwMDAgL01pc3NpbmdXaWR0aCAxMDAwIC9TdGVtViA1NiAvVHlwZSAvRm9udERlc2NyaXB0b3IgL1hIZWlnaHQgNDUzPj4NZW5kb2JqDTEyIDAgb2JqDTw8L0ZpbHRlciAvRmxhdGVEZWNvZGUgL0xlbmd0aCAyNTU2MiAvTGVuZ3RoMSAyMjQwODQ+Pg0Kc3RyZWFtDQp4nO29a5BkyXUedrMfVXVf9a5+Tk9VT0337KJnd3Z2dmZn343dncE+gX0NML0LEDM7uwuAXBALAsSDIsgVRRBgU6Bp+w8tU7IdDkv/pB7IEXjYcog/GLYibIVDdjjCDobNP5ZkhSUrwhKtCIfZzsybX93vns7bM0tJtmTn1Jyue/Nx8uTJk+ecPJn3VqSiKIqjD6P5qPvBL7z7wauvdv5epH7v61E0t/Dlm9/64GtvLvzXusQ/0zB5/yu3bs5/+advRurfeyhSv//3v/jlr3/rq//2lf8ritRKpH7w/he/+O7NOfWZni7732o4rW/f+Yf/4N/5PX1t4NIX3v/2e7/5P/yN5Wj+5okoSi6998EXvvwH7/zHfxyp3/71KMr/0a1vfH2y8FP1X0XqL31Ll/9pZGhbvOeP/8rvPfpbn+88/k+j1CRE0Y9+9+kPzfd/98D/9v7hnxz+oU79Q32bRXNRUcD8/cPDP4xOq0jn/x8qcumzf59+wqR88G31Z6PzNmEu6kbnou/ri+X5k0Bh/304g/Ma+hoMt3qWYwW0NTysIXV5qUtruXImLdOwoSHX0HFpHZfedXUMPKDhgktDfVMn0TCnYcGlL2poami4b5O+4vA2XJk5B5zWcu2gzoIrA1ym7IMaBq7tk67vI1ev4ejuOBrbDkz9dQ1D18aq403L9bHp+tFyuLrUniK+mTYvaXjc0ZDocVjR8CkNr2nY1HCPhrc13E986xL0HZj2Ml3utOMXIBVlwZeM8vt0L8GOs8b7qqPprIbHNexqeELDRXd9v4ZHNXxOw4Pu+rS7ftrdm75c1nDJ3Rs892r4mIZth+8ZDU85nK9oeMvx4zkN1zT8nIYXNHxCw/MaXnR0veLKmLpXNLzh0p505Uydh1375136o66dc64f666soWfHlTf93XL3jzh6L7l2HnH923HpOw4yBybthCtnaFt27YO2F13fTF9ed+2ZvKsOPuH68oSj95Mu/SVX/pMu72HXj2ddnW1H85OuXy87Hl1y+MxYtjTc0vBXNUw1fEvDKQ1rGvpuPA1fJho2NPTc2BocRh6GGs5oSB2YtIHj15IGI8sjDTfc9+c1POD4ccbx+YTDPXFpU3f9iIOXHa33O3jffaPeBl2fcPX5/rTjeez6eydI/gXDDcd3M6YvuL684fpl4Jrj+d2A0QuRg29o+OAu7r9B15zP5T5KvgRZ/l81OO3AyKWR6XUHE4K2g/NuTEw9yJIZq49r+I9c2m+5cfhLDu+/675/xZU3c+KvqGLef9vVMfPS6AQzF82cNHP+MXdvZNnMXyP7Y0fPZVf/RXdt8Jv5ZOax0UvQSQaH0V+nXLumra6ru+zaOuXKGrwPue9Vl2faM/r3nLs3OmPD4ZrQ9cjdL7u6ptxJV3/VwbpLX3PwhKt/2vHlMddXg+MR14+rri8m7zl3vebG4ZJrc8vBOdfGx11/Lri+XXFlH3PlzrtyO65d2JYLjt4zrj+X3bUp23HXZ1UpK6Zu39EEXdp25dqObw+4Ppo0IxNfUoV+PKVK3WTw3aNKuTvpaN11fb7PtdNzdC05+BgBZOac46HBd9GNt+mH8RGed+NrbNELrq2nHP0fd+lT1/5Fh+uEG6dHXd93HP7TLm+JePIQjf/Trr2xG6+H3Peu43/f0Xi/a++k698q4dp0uMG7sft+3/HN1LkrHQsf0eGQcEqV8+okwabLM+P4edf3px09mDP/puP9RVd/TPVgl6656xccn6HXP+HG7JOq1DMbbgw23bfhyb1ujC65b8BZl/eW49cDbqwhUyh32X0/6b7vdbDhcNzn6P+BKubd1NFsdNxfdfTBHzDz0fgin3H9Mfx4x/HIjPdNVeqzF1yaKf9ZAsi1aftZh9P4Od9ThT40/TDycc7RbugwcvEzqvBxv+xo2XR9+pLDNXBjs+X6v+X4bebmNx1e+Cv3Obxf0fBL7vsrqmoXPmr63cC3xbUiuBvfow5G7vu/V4UMnnB9ZHjAjbOR7V9XxXz8uirs14OOT4aPxic18zhXhR4z16kbE+MjdV3eyF2b8hNXxtBg5ucvuutFQedxPhbq77hr+MmwHeDbmksz119zff3AjcdXVSFj5vuLqvBdjXwauXnLlcM6wcjwa+4b92ZeGFl81fHrWVf/EVX6jBccPdAvRgc+6fj6S46H8OsGro3/QJUyb/Ca+WTmTOTWwFjbNt16UacfHtK6NonKNfe8WyeeLNaGh3+iv5fdOnGB8DTdddetJ+sAa2GGZQGJK9uqgXkBiy49dnUZ0GbH9XXk7pu0dsV6HH1fcN/IS4g3EdGAGEPu+DFx7Zj0SJV+XMfJIu5zJ8s9N3aZk/cOlUd+5r5TV1Z+A3fqxh+4uoQLcwvrorara/TUS+76ficjp1xdzEPTttF9Zv6tOPxGdqeqXMfkRCfk9Kpre+C+U4cjd2kp0bapyvUp+LNE/QDOVJRJHB3PuPKZK99xsO7aNPN36NqdEJ+7ru3Y1YXvBT0zFHztuD62HS/QB+ShXE542tTf1PF70+HpU/2ExgtjlVF76Hfi8DMwT8DHjqqOC9KYp0NVylDq0rvUXkbt9VxeSpDRd59oWFOlfIIfsbtvqVKeU0pPqH7u8lAvo3LAy/VAQyK+mX7MkTOqlBOun3pwJdQ26vM17Ajj53qYa5kHZP9TVe2ngaZro6Oq/OS6kia+b4ly0lfNVJWfjEP2v452To9FGssJ37fomsug7zEBjzn0J9PE/fP1xccvKVegL6c6iWhftsN94jYzdZQeKbO5wAled1S1T4yTx7+tqnTllMcg08B7yIakm8eb8bPelfhYdjNRh2WE25Z4fW3JucH95/Hh9FjgrNMJknaf3Mv5JueOHDtZj9v11ecxT0X7jJt1rOSP9AdiVbUnsp6vv1J3Mc9zT5oEqTPTmrK+vtelx+JajotPn/n0luRX3bxORVs+miHHrLtahEvSJHkqaeF+MO9aNfUkv4+TA9kntmd1OvZOslpHA2j2jYOkz9eXvKasnAfcZ7Z7Pj1bxzOm00eblA2fnMY17dTxy6fDpO6Vdtw3Vvxdx6s78U7KXR2/pGzU9Y3ngvRd4IMPVOmHLqnS9q2oqu+M9Q6vexCHhP8M37Tr8mCTUnXU/2W6pPyb9cA97p7XXX0qP6DyA1VdS6XUP9QDDakqfWzw16ypENc3a/4tukYfxjS2iO1xbMnQcEKVsRDQYfgzVKVPAHpA81CV6xmUTVS5/ujTeGHtlBM+8LJP/OVvXCeqjNW0KZ99erm2kGMGWehQX5DWJuB2QS/6ANnuqOoYyTU0A8sM7DH636U8wzvEh4z8broxmbh2V1QZV8caw4zVb6hS1ofqqM1lXqJf8NGkvoM+R187rl3WJx26xpoc/ZF6DHhz+gYve6JttjlSb0lf3OBZFmUwHojfrbr0NVXqDoxV7vJRF2k++2a+B9SuXIuwHWTeYw2Y0n3LjVFH1IOugNy2KB38hqww3pjyIFdyzcdy4PPHpQ8CYHvWVtXxbwucPWr3OH8Xcgd5ZvrZH2R54v6hHL7Bm5zaWHbjhTkJufetDUDzSNTvqyofWealjWP/z7dmY1vXJT5L2UI9botlok/4YVe4f+Af8hAvYhsF+cXYsm0z8CilrboyG26sVt33kuPREqUZnbRGvEdcW34PXD3D7yEB7wUOaQyWXftLVKbvyiBGxvOB5R5jDj2PsuA1x5TYTwSfOI5k0t4nPEYvP0R1jb039nbb3WOP77uqiLubelNVyqmh/yS1u6FKnShtFex+4tqFHEEupf3jGJdc/6WqqufkmpV1nIwzcjscB2V/DPHILt13Ba6E8rsCTB7ie2x7gRd08LiDV5mq6gH0S/rU8GcgG9xn7jf0zyr1m3GxH3FeVXVU1/UDZwZwtgBzJHPjv0q0o+9rrj78AfhmK64u9lK7qpwD8H2XXRpk19Q1ctlXpfxBn5iyxv8bOTBlzrr6oAE+Xa5KPxTx8xOqnMdLNN59RzfmMnwE0L9GY7/syoD3I1ce7S67stwGfM1l972jyvg8zwf2/aEv0Ke2q5NS/6HbcD10PEPasvvuEF7QwXUNrKtSFqDfenTfpbLMQ/BsRZXrE/hgsJfQgauq1IXQq4iPg28A7DVgDKFLwa++u18RtC5TGmjvC9zMQ7Ql+5RQepfKYkxgUzA2WEdgDWHuN125ript5liVMgbcoBf+4UC0AbkCD4aUBxqWqQ74yv0B/TwGkAfwgveFeG2C8cOar0P14Z/yegnzAfawT21hDPuuzYGq7tMNCU+b2oDvC56Bbz26h/wOVDlHkYf2oKNwjf6ATtDYVaUuS6j8MpVBffAPfBpQWpvGFvOkQ/iwHwgeQTbY3pj2TxLvmDdoF7zkukuqXCPCvixRXcgd5hLqYT5h3c887whAvk9nYO6hj5BFyDL0Imwl5i7rLdmXEaXx/GOd21dVnQk5hCzxPeSf4x68nmT84E2bykNeeY62CSf4wP4N079M7WIc4DMM1dF5xjoYMjuiMqzrpf6CjTLfa6qqX2DLMJ5LqpR91i88jqwXed5KeR5QmZGq6h6mF3EcHhfef4ZuYZvIcom0NqVBtiSP4PdzHILzodNHdN8W9djP4Pyc8pDOc7cj8tgH4DIr1J4cX+DkuArrNOzJc4wINEPmIKMYB9YR7AtJncJ+cKqqehR0gp5EpLPugr0aqWrf2F7zWov1CeQf6zq2iyeofbaFqA97wGs0+BJLoi50FOwjfLBUVW0s62HweJWupY7GeWfoWOTzegNrfPijGA/Zpilr/GKcpcS5SpyjND4hzgSfcmlm/uPMJc4s4vqUKs/m4zwbzkgCz7rDM3HXOE/LZznHrm08M7BBZXFOk9sAvbiXzw+su2sJWMuvi7QNNwYniI+QM/gbuOcYCdbTGGOOE2Yij2O8HA/icryWk3sGdXky9sLpUnfw/jfmmW8fjunjWIGkxRcDYzqBm9fqck/mOPDFTXlti7GR5XgtDVsq9zN8+xuSh7zOljFGGWPg/vjirFxP0sBzF2tYGXPjNvHdEWnMOx5r7qOMh6K+T9a4jsQvxzhVR/sp44WMM/W0Cd8FMghbxLGdPpWXcs/zkePQzD+mg2Pckj7GKeVBzgWWTY7TSH0h5zHHKOWckO3LPJZtn77oiPosZz7eMz08pm1Vzy/wBOURe4WPCl744vIcG0o9uKSMSV0Fvcf6LBdpHCPz6R7eO2GZrNNRuOdzgajPZ8YAfCZB4vPNs7YoI2OhPQ8u3rvgOcBjKMtK2WJ8WM/IucKAtnDGDuskzmf/GzKKNTfinX1V7huBp6h/QpXrCtYBHMNFX9BenVzDj+tQHZMu171LqiovoGlIvOP4G8YedHE8m2O4nM5rbJ/eZHnkmD7LNMamI/CyrmM9BJlgfS/3xOTclLLBezRSdn22CvSw/8Dt+uYX71GgT3LuyralnPrK1ckzr99Zj8j579NNcv9LnmniMnIP0TenfHxn+UAbkAm5Z9eiMrIu7xVJ3STHQ/Ja+oeZ8vOY/QjJA6nnfOMlx9PnV7DOkXlIl3RKfHIucP1EHZVxjB/nZeIeOCG30leSfTnOzvC5Eskvn8/hk3keF5+8+MqiX3Itkojyvn4wDsx36D/oTO6Lzz/yjbmPxrq5w7JfZwt8YwJ65L68D7/PloP+IaXxPKvTU4CBqtLvK8dyDB5L/Fyupao6x9cntMV01/XJB62aNK4D+ZP6MhVpvjnKvqSvfYxzItpnPcz30HNcPxN4+FyeHG9pS+R5U5ZzxMKk7pPyk6lqX5leafulTWFafGdUjB4xz2zco0rficcWMs/nA/iaxwZnduCzt5WfDy1V1SGxqq7F5ZocZRC3banSh0fMHv4l/DWO+4FHiI2xb4V79AV7yPDn+tRuh9pFjBFlOS46oHzEWpepTY7pc6zSlF2lMuAR4uWgDXmI1YM3phxiU6loh/c3UJb3/LF3g30TxIGZJyiPGCj72MAJPsEuYb2FPWXgxjkO7OutUtvMF8grfHc+88bnW1gvY25A3kFTW1XnHZ9/A4+Ak2NBZ1R1zko9if5DNlmG+T0jwMv6qc4Xgo3HOSxpn1iPMLDfBZraoh3MBcxt5qcv/sG6gHWAxIO2fLaQfS0T80WMf1OVMg+ZwRxC/yEX2PtBTHyiyvfP8H4s5gHK4/nKnPABd5dw8nnobVXaXFPPxJK3BB1Mw8CDG/sVqMN7BQPRPmx8j/AhrUNtQveYubShqnsYzK9MVfvPeD9G9OeUzs9j8rkKjktPVVV3gjbwjs8rILbTJ/xLqsor9pGHVIbPODB9OENk7k+Ldgd03xbtgm9ynHBeDXuW6C/eC5KoqlygnqQLYyf3ulPKQ/pEVWnFdUI4mIcZtYPzIpg/wM1jBb0A+iBzSAePgRd7Goiroizv05mybD9Sao/3lXlu9FX1HA/ziOcI+tJX1fmEPUnsZ8k5wDwEvmXCb/LHqpzf0Ang0ZRw8tzhuQCbwPN1TPfyvB/Xz1V1PmAuMn9wFg/7gOg3y1tG7WDMIEt8Xoj1iTwPA/vNdmWN6Fqn8ZP6N3HjeFaVaybQA/1u7u9R1fN1p1w+zuuDbo7JmXm27epuqardYDmL3XiZ6/uJ7m1V2mToKLQDGqEzgBvnHPhsHviFPVnsnULG76FxhmyMCT/sBOYIn+NrUx3IVJvws+8IO4y24NtChqVf2CacmIeYS/AreW8ccmrqwzdBPnxJ0MNnIsBTXIMGyBjes8OxaOCFLHMaX/MaAmnQx7Eq1yawEeyH+HgH3wV57JPlhBflOAbKfk5O5Xyxf+Bs07Vcs/Haif1V9pXk/oZcY3Mf25SWURoD8yUWOPjsiW9dyn1hnZNSuo8m2S7azqheV1Vp5/1L8Ipj+JARjpvLfb5E5GWea9SH/HI++m90G3wq+A7QzXxeF33r0j37wLBFvBcD2WffATYZuBg/23Dk81qY89EG++NY1+Ce4+4sf2uqnFNrhAO6AnqE1w6gH/djooXTZZss3xw/QPkVVaU1ofosfzGViT1tZ+pon+X6iL851uBLk2tNrC+5DM/bnOpIXcLrtZyA10Zs/4Arp2vmD5fnmAPbYPbfMK7AB5vHsgU5hmzCx+BYKZ8paxNO0MZyKucfp2EtjLawXmebhrrQA5BH+CXMS8bbIZwdgYPPEHJbiBm0VOn7gIegnX2LPrULPvepHehP1m18Vg9zD31g3cW+fKaqvGP9nVId1Odzi5xuyjY9tDRVNY6zqkrbhPOuyOd1BNIQr0IafBHInJwLOCvI9eG/Qh5ZV7AsAj98GbZBUv4Qb+lRHschYaNkfzgmxLxDHdYR4OOSKnU940M8EumMC/EZrN9QHvxHfJ7p4uci0SeWBQb2OxOBq0VlwAfIBepIXcpyhzHHPARfmPcNVfqLfI6sqUp5kD4cYmWs+9qqfFeP1N+pqvrW4Cu+wTPIGdZBmOegJ3H0sl1pqXLdCd+YY3FsY2RcDnxmuWeZZ78FekLaHfbfWN81qV2sn9nOgbaBuOa9DfCA7TLjwHjyORnYGaZD2l7URdugH3LRFuWlHWedz3ER9pdzumb/tkftYj7JdRnsA9snyAH7caAD+gh09kWb7D8zDvRF4me5xfdIVWWH48AsX3yeRu4ZDQkfx5lZ5yMPcwn1fD4M6mCcsW+GMQcfkM9rn4Tws1+Fe6w5uX/cJ97Ta6qj8sa4eiKvQ98mf5PGGnW4bbYnuSiL5xnY92WbymdCeD+RxxA8R5+axGfMb4A8d8RzBXaE1xuYF1LupM8J/t+jShkD72Dbgbcj6vhklseax4p9ddYhPr84IRxyPc7vEI1r6iUiX95zGrfF+NjWsM8tecv7N7Jtvmec3DancR257+w7GyQBdoFxsC7gbx5HqX/4TLDcS2IcfC3LxqJtOc/ZPnIe05570nzzyMcPHi+2JbCxuWifx9k3f5lXLHMdVZVRnyxKGQM/5Pj6zkN0RT2fnEmoe8+cpMMn/6xv4xo8LLtynsWirJy/PjrkmEp6WZ8wPVKuZdt1vJe0mTQ+D8N+Fur7xkHSyuOfinZ8/a37rouNHKfn6vrPvPHFBnx0cfs+vZjW5Pt44tNt0if28bNOdiRv62S7Dnfd2Pn0NtMh2/TJvQ8/6/e6MffFyCT/5FjK8bqTTribcT9uvtT1gWVByoWvL7iWZ01RX8bn7ma8W55y2R2uJa9SD3CenDvSJ5ay4Zu3khafXuX6vr7X6dDEg7fOXrDd64iydfpE0iF9ep+uYF4j3iPng483PjlvibpsC0CPjw91c0Hm1c1bmSbHn+esj1foO9driXw5L9hnYv8aa3WU571o2Q+8r8BcYz3GMQN5Rp3jDiwncq6wPHOM2pTBu1zq+Cp1nLTf7ENy31EGsU+WUVmOxxZt854m+iVj7Nxuoqp+tFw/deke8Vzmsw/kXplvfvI6nXULrvvUDo+JlFX0k+e2z3fgta6cd7LOcXpYrgU4xoU9c0PzJUeTOTN3nyrjhDhvwuO5QnhwbgPvpUBsMVXV80DYN8Net0mbOjrxbPu9qowxc7z6jKtjziXsqDLGb2DdlcN5FcT50W/sBbI84Mwkv68CMoazKHxm4F5Kw55BpsrnxfEMOXjE+xR45gjnEvj5bz5ryu9m4X3HlOjkc1v4LSlJK65xdoTfI4JYLZ/76dE1zj5AnrsEvMfDZyR4zxHvL+Q2EWdHOdTD+PGZC/ShT22uEe/4HEOiyrg48AxVlTY+lzZSR+nuqCo9kFnkyzIZXTOeRFX5hLkNG7Au+tkTbZhrvCNpIPK6Lm8g8ni/pKuO0oW2WLYgT/wMB5/ngDxBVpAuzwaasz8fU0VcCvOUz6lgHwtno8z1OVXs1eM8J58J4GftYlXde5K2CjaY9SrbCbwvls8xso5kf5DtLNs48AZ6A/UQa2Obz7rc529w/ILjltIHkz4g58Ui3Wef+Vr6Lz7/wBczAUi6fDZGrovYRjGPpX0GfvYj2I5K4DpZzTWPRyruwW8eW5YduR+BfrNMSd+c6crFPcZZ+k74zmvKZoRPrhF8PGb6U1FG+i9S9mWe7K+UoVzglHtLvv7LMUpVdZwlH+W1bz75fNOPUhdp0CHy+SLJPwbuUy7KccxLzg0pj7H49s0xGa+V7fG4+3xDGeeV+9oJlavzd6U+5HGsi1XJ/Q2+Rx/kmkDOOymnHcJz3JjCzkhdJtvmfrGeknyWNPnWnAxyDvI4++SzrY7yXsqy1C8+WZD6WvYRtLMOy1V1TqOM1Me5uPfJhOy/tF+wpak6Oi51tkzO40zglzLCbcWiPZ8e7tE9tyXveUykTpY0sXy1BE6u59Mz0q4xHdxfqSukjWLdZtL4HR1SBlkGmJ98Lf0fH4+kTHPfWFdK28d0sE6RfJI2hNMkL1NVlW9pS2XbLDvy+S6pNyUOqT+lz+Tzq9gG+ny0VLQv95kZp7TTUk7r5mZd3I1l+Lj4mgQ5Xr59Iqln79Q/tCdxcT99utgXZ/TR26Rr3Pti3rLvLO8+vKCZeeWzHXzPsVI5hj78kDXQzLFXvo9Fed84ct22aIf38hvUD+6jhFhVz0nwWPjkh2WDz6r4eMN2iuUHbbPcSnpikZYL3DJezXyQvPLt+/v6WTcWqarnncQpeSJ56htH2XZLtCn77BsbWfdO/fX1VaZJPC3Xv6annk9OfXPpo9AwonT2/QF4d/uA2oXvaerw+x6Z/ybOsKqq/EtEWy2q64v74nySz3a0PG1CftuirJQ/Oaas91BHPpvAZ6TkWjWhfJ8OZj+MzwNzvvRroAOkbyPvpS8t86V/CMhEGTlGdbaE8R1nT/g5D+4b+zU8Thg3jnnJvQ6Wj7rYCPNkm8Zl6O5xzt23pvD54j5/jsdG0iblHTDw5Es5RB3wwCcXcpwA96riecMptSV9YOlTsf2r64fkh+wf5mJbHe03zqnyuKBPHCOWzwplqoxnd6htPnPbEcD+LT8vIdeu/FyIXH+B51yf5RD7HBy7BE65F9kW7XWUn35TB8+o4txpp6YN3zxiPHzPdLNOy8Q3yxtiufyMmk8nynUO2uCYBGjkmC7zRe6BQCbaVE6ewQR+nHv28UDuw/L6gtfvPNYsWxyTk3KFcvL5CdlnAPcF+o7bkc94dCiN+8P2hnnMfZX9ZMAaLqc6PI6yHsaS+8x85jUr5jWfs+VvCSxnPL5ME6fxWtsXh5HXPG9wzX1h2yHnPuqz/uW+Yx7w3JL85Hki9TfrB0m7T49J/nQEThkrYzo43iXHhHVbh8pwfxNVlW8Z2wY+0MB6L1PVvrYET6Q8Mw7W6bL/TLscW5+cM08lb2NV5Z8PH8s+yrD+5bUh6rLdZV9R6mJuj2WGy0k91RHlfL6izGM5ZF+R7TufC/Dh4msZ5+qoKj+5XcwTxsN9Y15z3J7LNqkM6jJv5Tl/1kOSJu4zaPcB+0WMm2mQulnO5dxzXaebE4GP52qsjsot4+X5AL6wHGGOyzWC5DPWc226xjhKmU1EWdbPCbXZUWVcROpdnnuSTmlL2Raybm6Kvsk5K/076SfI8WTecH8SVV0jSvnGWj0nvrFe5Zid9LnZ3kpfnfvbUNW5BZ3K/e+o6rOIoBF8Yr0m7Qb7/XIeYryZBzyvFlVVNvi5Q1xzXK7p6jQIH3jQpPYRB5FrEpThOc15dfd1669EtOlb//DYyro+fPwMJvjA/pJcO/r6kqijNLL8SVlheatbL7Jdln4CvuXeOfsWLWqH7R8D15drSGmPJC/Yt/X5tIxT7vVyf1nnZJ5yqcDPPMKcZrss22C65FqI9Yhsk/WX9BGkX8i+AdJ8/PHxzmfzcnHP813yL/GkSbmTvJBpx/FO0in71xHtSRvLfEoEHvY12Z/3tSXlRcq95BHPNcQnVwkfbNm6Kn1snlOs4zCu8K0Rp2J+Qney7efnWKWPim/Eg1mWMDdx5g02So4b60DG1RLtYg5C53AMh2WI/Qx+vyj4n6mqvDKvuU2OD+J5d+Bao3bZPvCaW+rcRJVn3ZDfJhws9zy/GkQHz03Ug/5IVJWelirPGnI+/KQW4TPpS9Qm+MjvHAJvRqqM03O/2Y/jeLlJn4h71EHskM9+syxIXQB55nkbE23SbnEa5Lkl8OKe7QPLAtuRFpVhnwV1+T21vM/F6zf5/Kl8Zwe/t5B1rCmL9xdK/SF1I8s4aJX7RrKfPDaxqr7PEnyGbC0TTqmLGT+/h4x9MsgdfC6mVfK7Re1Cd7EPynMb/QEtfVWly+erSB3A5XgOpQI3z1tpm9EvXjuhD+ZaPkvJep99N96bQxmWLdAo91dRln0m+IWYc3JvitvpEV6moelJ5zWJz6fk/b9EVeWA9YTcK4TMm/6edvjkXgPeFdZx15uqjB+Zb/7tEZwd5zPRUvYxjl1PPs8xn45KRDrq4Dy2z6fBGOWivvQJGGRMJFZH+8A6kelkuYON5HeSoA7H3zJRh5/h8emUPuGGvCMNZVnXMq1sL3HmHfoiU+WeSCrKyjGR19y2HMPY0zanL3lwsB7gvTSphzidx1bqEd84++aSzy7Kdn11UvEtgcdxoI72y8cvlFmqafs4uu8EvrFkvsuzE9w3aYt8MiF5Ieef5A3rL46hSd+R2+sKHKzj6sbHx+M63kkbIOe7b4/0uLHg3/Pm2DzrAOhVXu9wXAttckyR/SP2aWLCw34L61w5dszvTNzzeonXetAZXF+uRfANP03qGNZZPr8rF3h4HQKaeI6inFw7Sp9V6vxYtC3lkNc6PDa8D8Ljx3tVbVEO9dgOJKJNKQtSLrgs8DJvJe+ZLtlHnwzzGKDvfcLXEbi7qtoXnwz47DDPzzpdIvWyHGtuT57RlTEy4OHnaAcCn5wHzEcuw/1nuZPzSfZd2jSfjvLpsRbh57ldx1OffpYxFGnfeT745oic68wbOQ+lfZO8qJM7mSdlXuahHtvVWFXnFdbErGdMGX5HHWTcJ5f8jG3i6rHNHFFZth+s1/nZSbTBzyKyXA5E+x1VPbsn5RJ94bWynPuJqq5/8WzvDtFnYmD3OthxYM4j3aPK99LjzAfeV95zuO5R5dmPFVWut8eqfI/ZiNrF70Xj2VzwEM9QAvB7FiPCueFoxjuCwUND1xlVxqewJuTfY2c7lREe/l0C7KVmVA/P3+KZcPQHz2UvU11+3x+/e5XPxqB9fvc86vAazac72Jb77HnmqeObR6kHZ52ulXMb84Lj0T4fQ+oiaVt4Hsn5g/odDz6fj8ZxDbn28YHEJ/093rtK1dE1O3DI/SbpQ8ZUnnnLvGfecZyk5cEZe8r4ysq1Rkuk8ZgxDamnvsTv85N9ZbmN4+itG0fJV1mX6cwEHp/Mchq3xzIj8yHrbbqGvjFz/Zwqf9fD6Ez4StB/RjdsO/rwfgY8E7/i6qyp8jl0vPcAOrKjSh2Gd4bi9zH4vQrQr+sO74q7x+9Y4d2liOXwbxfJdQ3P0ZjqSN3h8y3Zt5D+LnxVuXb3+dGxSOM9Fj4TxHFCfCOGyXsmfJ65Leo95sYA9gzjlzn+LTt+Ju4agLg9/AK8qx/vduCxxPjAFidUDmXxXn/gx+/VLDs6ElW+owTvAcbvpuTUVofqoU/AAflDPvJAH97tsETl4F+gPtM7JBzgD2z8MuGEPC6pKg+Bc1Xggn/BdLaJp3g+ATGsEQHmzYDaBMCmAy/6N6b2kMbvpRhSHtoDDvDHgJl/iOHwnMaeHWQF6eDPQPAAZXqCTn4XyqrAjzZzoo1/v25J4B7QN/iKfmGMl+gauPj9I4gX87s/mFdLhGNEbYI3KbXD7+JgXwrzGXzCe6uhj/COL7YFoIfPXPrWkHy+AH2BXyJjK2zLj7PPPvsr12jS3rCN8tkxX5rPp5F+lFwP+WxoR7R9nA8obYT0p6TPWud7sd8naWW+8vpO9hP2oM7eS3/XfMt4PQPzwUdrKsoyn+San+vLuNqd+MO+YqaO0iPL+dbukh7e4/bhk3Ih5SET17Gq7y/3O1bVs00sO3X+mZxHPr8j97Qp/U3fXJdt8XOdUq7lPg3PRZ+sI913rsUXI+M2pZ8Ui2tZXsZe+DczmPdcVz6XzOsCprVuzvOY89mYjNpri3sfXpYF7o/0H6V8pZ66AOkDSnw8T+raq8uTNPhkA3ZK4ok9uOTY+nTIcYCyfU+6tDc8933x9kSUrYsDGjB7wSYmdMqN82nKYzvLv9GEdKyfsB/gkwEpdz57I2WG5w/3i+0Y6yHGxedGZFsMPdFWndyY+l2BU8qyb6x89qjuvs7+chyJeZGLNiX9d5oTcr9CziP0ORb45Rj52kk87XBZaS98dXwyLPnkqyPnA/eN+4v1E2J9J+gaPqrpP/vy/Bua/D7CdVVdX/HvYWN9Dlwoh5gg1lf8zkPEbbGuwDmLFVWlA20woD2si+XvjrIPzb8XitgH3l2Y0T3768tUpku4+Xc/UVfakU7NPe93IZ33VweqOqZyjFEO/JPPJ8aUxjIhZVaeC80oHXRCN3PcKKc6TFumjv7+FMotiXK+vUf53kTky1i3tN2Jpx7qIF6de9pOxH1PHeUzn+816UOBh+2B5InvuRQpB4wnE/W66qhM+YD7wetA2Q6X4eeWZOzJ96xQ4knLRP20pn5X1OGy2B/hPNTpiDQ+Q8vjAODf4eJ2oNsZD98zLbJ+Iuq11VFafXzhcfDxEP6FHA+mWaYPlJ9WXz/qnveSct2msjy/pSyhHq9b2uKbr/msM+s3/vZBWpMOmYhFWdYPsh9oG9+sKyV+9qF8ZTJPnY4q5ZTnMPvRsBttugY9sg3+HS3mU7cm/Tj6WOZ4/KSeYD9DyhPnS18wVuV8q/O5pK8ocbD+AA0+XW+Az9pmogyXY3uAdJ67dX26k996p/S6MplIOy5eIM8w+/D5/Ewf4Hk7tiXm26wn4C/xPJWyxLqCxwmyjHqsE1lu2A8FLunHJ6o6jux3SP8JupL3tblf0PH8e4/S92a5Y5vOcR4fv2WZlMpBH2Jf1dcu63Re7yBmgbOsco3AfGdeMm97lCbfJ+hb4/BvjDN9GbUp/S8eZ+lLxVSH55q029J2IF3yWsZ0sFZAnziOxnT7Yj4y5sfjAjwZlZX+ckJj2qQyuF5TVZpZ3/EzpTwfAQ265uc8eL3P5bgNyA237XtnHssR0nz7z5JfdfvaiM1hrDmWjOueqtIBXjLt4JN835Xv3ESTcMjfKYxFuqkPOctFGwb6AjfLGdoBfTmVWVbVPoLvLVXGz2W8Vrbt0ysyPiRx8nxBP2U74HdXpHMMgGVc8hbX8tkj6B55RoTpZlqG1CbzR+oW6UfK+YYzSLA1XXEPXcLv0vfZDhnXZT+X73lPnfNZx+WiHdaDbU9bDF3CIddKbbpGGZRnPcvtynVbqo7aXy6bKD8vpC8o09iHbIm6PJ6oK+25pIfrS7+B3/uBtts1AJ8gobJsU3jNjPKQQ5ZdPjMr/Ul8gwd9SuN8+VsRnG9+b8Wc+TMx5i3qE9pBrAky0qMyW8Q3xC/OqPIdiRyLwfnDZdfPHqWZMjhTsexwmNj3uqquReA3TFV57kLGD4CXz0j0CQf6xrzivrK/AD8fe+HSR5M85zHC2Mm1KehlG5yLb/YB8X5J9hG4Lp5zYz3XVmXMlHGxvgZNODuBfI4TwT5Bt0LPpqo8MwDfCD5trkodC1xMV0uV5x9Yn6IfbLeYpzw3WP+z/mD+IJ3XvuxjyLiC5Lv08ZgWmZaINMZz3NqH6WFfFzIq163sx3JaTji4DAPbcpmHsWd8TJeMYa2rozHjOmD/16e/WM/68lkfQx75GUpe6zDvIStTSmPfT9ZhvXgf1bmP2uBnKllHpzX3Ug5YHrjOUJSR0FLVPZ8JXQPfeQ33izYkPt86xqdrJB/5W/r/vCbk+edrYyDy5DxKKV36wKjDv5/GMey6OcZ+iW+smOZctMfrYHkWSI4x08BrP9+aQsqE9K/Znkg8Pp7IPF//ue1lwevjvqUu9LVxHMjyx60zfNescyUOlOtQno/HPnkaetrx0evj8XG8l2Mn7YTPztTphTvxFOX4bJS0nSgnfRfQyvtvzC/fGrelqnIOf9Ckb6jy/CRogJ59SJU+hqm3qqrrGWkHpf4HDeZcN/vdpykffh/WmRzj42fB2W8C7zidfQzYhbaox/s3PC65gESUAT/hd/jW8D49xLik/+Jrj303fLdE2dRTl/vPciR9G5+tyz1l6uABDRdU6SPyOpvXatDZWGvympB9CtDB+6Lsz7dVdczkWo/X2r51Ictk11MnpXy5Hk897ch9JPh6Uv6ZzhWq2xVt+uYMnmn3+VKpqq6bMZa8bmV+8Dpb+p7gq5xH3J7P/5PxFskr1qVSXnl8OOZS529KmZdtgs84T8L+NK/dh+qo/LA8Ymx4X47jFRzLYTrlbzHKeAnLGdrpCPw897mslGUec8izlHN5LWMurA8Q1wf9iA/wM5jcFxlz9801tCHjRRg3PBviqy/rsdzUxZ+Y3zKGw2WAm9e9dfGftqdtH8ixZrky3wMqy76sj17IsIz5oWxH4BqKutABvveKI1/qV7mnnKqjfcgEHi5jcCKuA1udi/bAwxWqCx+W5yd+PxfyyOMt+c3z5Ljxq7uXfYIvg2capH45rp2kph0f7bJdfsYqE/gyUdd3nYl2paz6xpTLZzV53JYBPsvGbUC+pb6XesLcD5W/Dz1Pu7E6Ogd8c6duXDoe3LGnfN3cZtn18Sfx5Mky7FPxeNeN5ciDxzdHeV5CVniM+1Rfto95xr/Py3RAT7JPIWUJY5qIvOPkR47VcTq1DlJPO9Iuy/UZ21Zpz3NVPRvlkwuu0xFlpf8gbT3olXPGAL8XjPUxz2Pp4/dEe4jhsi8haeI2OjV42dZKGa8bU9+9T7/xWPh4zlCnd31l+zV5df4S89lXR+or5iP7zuxf9Wragr68E21dT5vy2rem4HTWM1IWARz/Zd3F4879uxNI35bp8OHPPN99kS/XoHW+rATfulPSWkcDr8HkOhiyK9ekcm3jW8dBNvoine26rCN5V8d7jkWkdM95rAPlc3hy3S9jYL7YOOIzzB/4AtjfY77IuBXTime6+YyljAHKuKJvD0f6NRwH5nveL5G8y0R7cr6xb+ujJRX4JGRUhnFwjJPLyDqMC7LUEXV9McGmOnpGK1fVPvvo98UoO6r6vkWuy3bOVx86gWnMqQzHT+Q85ueCWD9LXsq9WN63Rxr0H2ROygOXlbFpH6/ZD8mpHuNKVHWvAzhaAj/v8caCRvZfmB7Wk765IvdxfDF76JhY+eWe549PLgBtSme7kIg2ffyG/ubYu09HMc1dUV7qMDmXTPkldbR/LEuSj5KfUt9DduVc7VMe2kfcluWV5ZbnM/biuC7rSI7r+8ZI8h30gy6cr5NyeTdQpyM4HXqC6ZbygW/0CWdNmG6830q+97SO5lW67njKcGyW5xz8EOA35eaJlynVx36T1Es8tsA/pDJ4BwPKtQkn2362wcwzObd8c1GOt0yXsu17Htt8Tzz1fHxnv+tuZCcT+I6jU85Fn/6JPeky/27okTqS5zP3Wdpj2RbPQd97KmRfZX+lrpF8z9TRfvfVUTpz0a70C2R7deNQN2a+8fbxyMdr9m2kj3Qn+fG1mx+T77PFcnylbmf+Mn0dgbOtjsqIlLlYHR0v6afwuAKvPF9xnEzXzfE6OZP89M0Rn5z6cPjy6uazL0+e6eLnQRKRxvts7EfINjh2BX6y3Wd5ZNlnP1baMtlmm+7RLuLUwI93McXqqP2C/YjVUXvA8mby8a4y334hcBkcOEMn5denY/i3rqW9kbZcjp1vLFnfyXPhjLNTgwPvhoSPzvNRzhUfSH0yEPfAMa6p79OHichLVXUNLXUhz2OZXtcHjDm/8zQVbUBnSJySNsgA08b1WqI8wPcuDNZrdfV8PLnbcToOn6+frFvvVC//U+ZxX+7Ux0Tk+Wy5r5+4Bx/kb9egjIwzYA0gcbL+kbRyefkMDo9rQmV4TvrWH/geEK6Y2pO4Y5Emf5sj9bSNclJHSP77nj9hnPhG26lor86GcV+4XTm37zQfMf84NtITeXeS5ePmRZ2s1s2dj9oO0y51QU73AI6/oQ6ehWAa8G5Gn8zeqR+IpbIcQIcaHIti3GTfY4ETz2BxDED6eTz+rKM5hgw7BxwcD2LbkHnKybN4POc59sO6g/fgWK/JdYv0eUBnqqqyz7EJ3p/j9Sja5fHlPYiUyrKelfPINx5t0Q77FbjnfT/pr/pkiMeM67LPJP0iCRwTYpp8PpWUFx5Hrs+6hfWdTGPccq8AfeOx4rN1iGcMqc0R4Zc2ATqd+856G23yWjOj+jze8nlo6BKeB+AtyyDPEd98lXLs8/1Z3n37IAxGB5nnH8xzUydUGQ8bqurznaYczsYi7jhU5dmopipt0YqqPq8Tq/KsC3i+KsaB32GMZ2pYBvB+ILZZI+K9tGHgq/x9LDznCR88cbSwH3BCVZ+PAh3YS0C/pUyBFqx3mvTN7+BHGuwFfFacAeJnEfqCt/LZCeBCXu54yTqd/RbmCfoKvp9SpQzjfUuYd1hzsXyxf8TzDjaP9T/4tqKq8WCcKTC4+HkNjG+m/P4q0nMqy2Mg9RTrW96zA599c4P31Fl/yd+CZtuRiXzpj8nfQZY+qexDfId0Wa+uzTo/lPWHD5/UldKvrSuHcWVdxnED6ddIncf5vrMG7BtwPem3yL0h+B1yDSZlJqH2pG0EHrk/7YvB4d3CLHc+/c80tlS174koL9c7cj2Obxnn4b6hblvgYX/BFxtiXsi+xOroGMo5J/dIJY25qsoJ0yttLMsw5JZlZ6iq9IM3DVWVVSnv0r6yvmTfQ8YZYg+wrpZ+qdyfkmOUecrA9qI9lg8eF8bHssD2k3kFHcp+JMuS1BfYr/H1mXlSp6M4ve63MrlOwzM+sDN185dto/w9iDoAno46uv72yYlP/31U8K3z6/I+Spt1PE48ZWR7nMa+Eq9REk+9Onmo6wfrsTpe++xRQx3tn/yNFfa/OI91R66q7zdhXqFNXmPw+pL9Id/ZNPYPOK6NfKmvZNyA03ivn3U9y3xL1BmqozxHOX7OgW0A86NOt/L4dUU+Yh1y/SplN6P6vvHnfta9/0TWSUSbcgyAMyMcshynHyevvCaWPJG0yjVbrPx2RNpgnw/Ic9hnz2OBp05GmF6fHq/TfXV6g+cOz3fZ7nH6J6nB7dNn7D/L+cp9kO9xQrrPBsn3BjUIZ9ODU7bbFMD+t4QW4ZdrAqn/OC4i9VpD1LtXlfPZrOHwbhH2B+Cfs7/KsXX2OVhfIo/nkml3w5XHO42hJzgmid8bQbzP1MezJWxXeE6gPcw11hurlIb9LOhZ/D46eAr7xedOuO9rqio38n3UvPbg3/RKVfncrZx74I0vdhar6hl1jnWwbs9VGUPhvnPMiece22n2vcBffk8e25y2wMP7xjxvNogXI8LdE+VaqhrvYB0oda/Upb7zzBzHwPNQ7BujLGw01p0+fS3jnbIs0thOs23keATTxjFq2YY8EyXtCvsOkOFUHeUL+wKJyGebA1rYtjOtLL9Sx3K+3Efn9RnLiIxhSpvjS5dpANmmLM/8472FRFXftQmZZ3uKmBj6h+cY2G/jNSfX5/5I++mzxcfd3wnq7Dvz4zif4zj++WxwHdSVYb9BntW70/j+85StW2/ebRuSV9BNfM289607uOyd+u7LP25P90/TN/AFtqOuDPL4/Zjoh4+vx+E6rizrzI4ok9Sktzy4GKc88wT670a3+MZc0nsn3kveHqc/mbbj9APziX2KRFxL28R8lH2SdbmO5I28lmsfn8/i44WM64yUf74kyi/7zEs533zrAKZT9o1pr4sHcR1f3IPv5X4kj5X0j3198vGb15pMB++nHCfXdTahzmeTvhbn19HI+Hyy45P9OjySz9CrvrnDPJVyxXjk+B43d+VYSXp8suoDKWsfFYe0Kb555bu+Gz1Txwff/PHpWt/8lm3W0X2nPvvSJU1/GrueirosD7yGrGu3Lp5yHL0+3tXFKj4qn+rG2GfzfHtqsp48byG/pb6UOh2QqqOyz9++uVinq9h++fSF1JF18l2nX6Qc19khX99lumxP9sNHO+Pz6fm6PkreyDa5LK/hYlFHjlHmya/rJ8ugtAuZwF3Hhzp99qcBpk/agDq/wFfeJy/8jnbfGErcPnmoa0OmgS7EJ+QeH8cZJgJGnjSGTfoGnKL0U6Icl63Dcaf27lSmDuI75I9r+ibh5F3AuOb6bqGuzhn3vUlpU5dueL3hqcv34N/U9eUE9WnD4TDl16iO7POE8E4I/7qDscPP5TdEO6A/dfcn3P2Sa9vEVlfc9wkHa+J+ldrccPkr7nvNpZ1U5W9Bow7XG7t0LoPfql5W5Zm0ZcKP+yG1sUx5KwSgY02kIw/v1F6iMmNHG/q/6vJXCT/aw++OAwf/1jpoZr6sUj7//vcS1fd9r1GZJcIHGldEGtrg355fc9fr1KdlUUb+ljun8W+9+9KYJ/jNOf6NQumb8JlNpHMc0ffsLutKGQP22TuO//N6mmPeI8IHOvi9K+wb4kwnvys8VdX3OHXpPlPlfgieWwJePAuFc4aQhw7xDWci0W+cAcRvMIIneIcSxjNW5ftDY8KPM5QdVZ71wG8sYvwywoXfjOczU3ieC2c8gQvvr19x+LCnwr/7jr0e/I4j+g9eDqlcX1X3GPAuVtCM+4Eq5wX2SyAvHDOXZ9E5hiDPN6aC7/zOKfa5uTz7e5kA9sc51sF75Hzt82mkrwZ5QD/4PQAcxzzOr+JzDHy+LCecqQfk72X5/Gqml+dfLsozzT4fU/r34DFkiXUArwlZV0g/nMeorg/M+67Aw+se3qsycsTv/pN8q/NXoU8SVZ7LOCnKQU4l37gMvzvBpME2sM/pe16X+QQZB02YVyuqyp+Y8En+yfVE3T1gSR0de8w7n2zJtbvkLb8PnOcd5oWMtUmQa2e0x3vK0saAZ7KfmCsnBf/luwt8e3Py3IhvXczyyL/XxTznObfsSQM9UlYh1/Isj1wfYs4xT3zycNy9D+piIj496cvDt9TXsg4/z1GnnyStvnweIx+9dTHauwW2w0N1lAafDfHx6040+HDWlUOZf971/t3SVge+vTaW5TvtK0s4p47qe9lvn0zX8bFO3o9LP06WjmtftsvP6Wee/LsdCylfOA/DZwAZGqoqG769VvmOHF9cpS5u6xtz+W4gPufDtNW1we+z8fGnIfD79okaqnpe+U7zT7bj23OKRX6D2mpROR/dkgcSV0u0Ic+gNdXRfS9cD1R17Op8T47ZyWe7pIz5ZKGj6mlHekPc8zfOPkEmGp5yoI1xyDPFGH+Dg58bgo7g5xN4DrOu5HS8Y5n7NRJ4WQ/z+9BYx0n/SY6TyV9WVTr4eUQpf749EZ+draMTsiZ9cUmjz7dnX43bbIkyd9KPUl6Mf4R1K78HFmPC7+zEukICYgO8JuSzfLzel++j5fdF51SH3+sCmcgoP6Y0rBM43gC5w3v3+RwcvwdX3qOOfB8vYjaG/uNisohnmpjZFrW75mhE7IB/Zw80yjNyUh8YWPaMa52d8ukSn/3F79uxPOV0L3V63d4W14ce5Hyp+6X+lPqW7QqfWU7ceLBOlrblOPvi03Hynu0Jpy+ro89KMY3S3stxYLvCYy11Nj+bU2fruc4y1Wl48n2+KMfyfHi5b02BS+L26SapN33+ELcrZV72uc7WSdngb59cHMcXKduSRp9NqLtnHLDV7HtyOaaH+SB9QR/NeAbdd07eF2eRdNbJFtsmTpe+HZ+9Rz3ZtrSLEjf//qTkiy9mwrZO2mM8Wy5tPuumujGt0xlSLwN4nSxtN8r7/I+WyPe16ZtrPh9d+rVyXKWeMsBnz4+jxycnbM/NvbFd2+5aPrvAZxRN+oYqfZ+ep82U6nM8CHTyb3rLeE1MZfl95vATgD+lfBmXZJ+Mf2tBni8BbYjTGT6tOvrgU3JsfZ1oAB7mH/ucfAab3zsH/yhVVZ8SPjfmCvtmqaq+4w51sSfCa1+OGfepbfYHpV3nuchnbjmmKmPO6CPahI7jOc3veoup7VyVawHwx+dHc6yQf6s497SJ9c+KKn0z0CbfJcWygX4iPg2a8DsoMt4dUznWdfxOB+YD/843fFHuH/PH9250Hk/gxl4cfE68k0S+byhTpQ7luQNfmPU4fqeCZRvtQlawJwX/ldeEHNfGPim3z/yDn8zy2lFVWc5U9d0qvHfDuhP1IAN8BpvXHigD2vmdHLxH5JsfkD+ko99twi/9HvAD5aDDOL7Jcs3jk6hyf4PHg/U588mnV1n3dgRu6FZ+PiqheuAdy4G0b/eo8p3HeG8X1oV4tgs6K1XV+JPcs+RxgJyjX/KZqa5Ik/dyL9NnR1m3SZsgbYic/3zPtqqtqvrSZ+fZXrDth4/IssNjBXnlvXnoEt6jQ1/aqkqTfD8T6rNe8vGMxwY2gfcMQSuvsYHHnCnZpjReo7Muw957JvBJGfDN1VTgk3YTOO5Vha3E+4CwZh+q8nctIMPQp7AHA0pn+wP+cn357Cn3G3VYl0s74JNhnsMsk2xjpMyxj+wDlIcNzTxlpF5gP5Z1CWSDYw8sP0yz1COsw2KBF/UQ91lS5Rzhd/HyM8Bsc+DLsY1igB/G/hnbJdZD+IZMwBcEHUZX4/wZ+m3oelAVv3274mgy32dVaXsNjWvqaGwY59Igb4bOqcOP8RpQHnyVdVWeSYEOOKlKP4F1H+9/8rsNwB+OjZsy5gzftuvPGVXOeawlTR2OnSyp6pxnvwf+9qqja+T6tRZ9aOuO3eeUhkl00n427d1m1NWwHD0YnY1G0TTKoo5OWdcpJ6OW/t6MfhT95ejfj36qPwfR96JhtBS9r+//sr77UfSf2fTvRb8UfdGmL9NnxX1MjZH+nNTYVqJvRm390RTqEkvRP4m+HX1Z331J1/3N6Oejd6LPRa9FN6Nfjd7SaV+NfiF6M/ps9IGG69Ev6/sPorejX9T5WZRHSdTTmLrRhm4hjgaabpO6rK9TfZXp77a+72vIdUpqU2J9Hdu6LV2+ZdPNnclt27tE57csptSlx1FT37Vs6aatGduPSUlsamKvm/rK5GU2pWlLNG1Kaj+4NhiTWbnEtdi00JxhLz6mREY5LVs6nqWgXmvWVmOGozUrZ74bhKcVLbpSZe2Wuy8oL7gysiWLnmbRCdfT2HI0d73qW4oKPppP2+XktodtzeXUcm9gedp2HBi5Fjv2LrX4B46Ppt2uTSu4k1p+NV3LTcu/hm0jdm0XPCpGPCaexjbd8KLrxqplaTE4h1Y2EisFJrVjqU90WlPnjTQ1A329pP+2LcQO8yn9yfQcajnM+Wx8CwkwVJledWwrLS3xsRuzQrYMFT0nWy2Nf8nKrmnPXPd12wONfWSvR/bOgJkruaXY8CazFJkSy3ZumX50Lf96tv2+LjG06R39N7Wzz4zAhv7O7F1/lms+PX3d0/nmu2tn5sTOhlVbrudoKEqMLBWGzq5u29QY2Pxcl+5Zng1t6YHDZdqJ7d++TevZVjuWqoLiov6KrZVrMLwrUke2/NC1Yq6XrXZacp++zek7youe9Cwek5NYSvoWe+Z4m2odJD+lZijGKbNjFbu/qdMYmRvbdDae8Uw6W+6q+AvJNNQ0ZyV6Ts8U0tJz8hlb2YV8J7atluV9e6YXctdaw85PSBJoS3TJnh1x049iPrRtLwpNntlZmDmJbLtPx9GZzT6JpSR1vU/sPC562HQzKrHl0tlVYnuROV0Wz0olVsbzWZ3U5jdtibbtFz5ppQ5/MvqbupFBDq66tbUTO6/5rhyzgrOpuy9HMnYaJ3ZavMyLrZ2J3Xi0Zlq+5EjP4ix0YtvxvLjrWA2ZO/vSdD3JrDzlbmSyGY/aTtLM30KiE6vTjGVbsX2KK59E3Pk+bXGfRyWHjM7oWl3btzPvhNWCfe0V9LXn0LefVffdt2U7bsZ1rDybvvYsht7s2uS1Le7Uat01qz/NrDea25Rt69SulSojuZm1TF07W7pWU3ctbQWO3PK5az+ZlfKirYHN77iyqS3ZtZq3balsWf4bfp20uU3L767jZcfSk1ppTO0ote0I5c5Cn7XtGo4Prd5E/ztWnxiK1i3lXafPeq7nhjcNW7ZrtXrPzvu+zS8/XQc9W7bntG7LYsysL/PRPtlMQ9z9p/QyRk7yMsu52MlH22mTFaeVoNfadjZCcyRO12V2RFOrZQteNu2sSRzPu5bricWfOt8qnWmsbKYN4EUkLidxs8HISKJ907bFhnHLZtqs/GSzvgB/NpttDXef2tmFGVjqv56tGdu50JnNzb7LzUT5Pl1nduwK/yezdcvWBxVKMjdimZOf1P5NrHS3Z1zt2p53ZveGptLDKuZVPmul/ICCok7hjYGugq/m74g0Z6k7GjOd1rYSDNyxsy7QjC1nz4p+FO0mgg5YudRZqsRZlWxmKaQ8wpJmLr+woJmTt8RhSpxdBuWQkiwqrS9sRhLBNywpTSp5sbA/0KCtGU7OSZ0MwINkOxUfqV+sITLqm9TLJRcKz7RcT8RRaYuYUwOHp2V7ibVEZudZ6moMHKdbjhJ8xw6bqTeyehErEOTAp4jdrGvNJKDjqGi7mWXyh9b2w7rkDmMpUWes7RpE8Bj6WpP0nY9WeJNtm9a0nmlmPTRD99DpmMJrLTxjg2lkcY9cffwt1oBD6ycPbY3c+cxckj89+zemlMy2ZXC0nT9sMBb6CloSV8XKoS80aME19h7jmaRLO92q2HDwq7TJ4KFMOfqJRcnU+YalzGHcsxnl8BpbzjOBpwr5KeUYK+HEeqBFbzuzUqlb/aTW0sInRm5rhjd266YGcaHpVtPNmYSWn3TG9ZbDXM6IpuNpqzIqTSfhbbd6ja2NiWfr2dIraroaQ1eCOZm6uYC+Fmv+dKYDitV1Mc/y2fwuR7/h/PzmbF7BowY1payUmjJx0QRoSXAc2jObpZZc7zscTWuBBrZM22mXlp2TzYhXKJDDZlT4Ce2oWGlkdhySGY+KscucDEBfdAhPOypWloWP23Fr5tT+7bhZ27Y+UuFhwdPquJSu/S5KF5LTcaUKW9uyrWWzetmMj2w7YfPymU2OHTcyp53hlyClXamZWQmBJkdqXknB6OVO54NLpadeyir0P7hYWiBwtTOzHPDyS1uGFUQRNSmiUiyVPN9hyXJ316Ey2Uxe2MLJurhrzfAjPoPRKyhsR1j5tiPYhOKDKEjsVpj5bL7xTC36VOq51K0kWSPmUamp2rN5lM54FNv62SwHs6jEYNK7s2tDZ4NGovCDhq7Hbde/UtYxQwzPBlEZFSw9qdSt37LZ7MxnubHjGeYyON+M4NOmEVbp7Qi+EHifEWBceNx5rIqUZpQIfRlXrhK3KjWfhrP6sZvTaQVzaSvYVymktjOLgKaWt/DCkgh+H3RqoSHZ3oOvzKfYRRKxFofslt5eSZlcrcdEXaH9OzN+QQN3KnxrRbBCySwKWMQ9Y0tB3+lK83cpKryWzOHq6FINVwMRQ/O9aPXtQlTESRdt7dasVMtxJnHYmjOacxd1NW0tz2JnLRvfyu3KumvXjcWaMZ2tDDtuNV7EjeJZ3xHbbc7mQX3kpC4OkFSkLqOUql9ch6M50z4xlWo5Sw4/E1fNGUcbru6i48kpG7Nc0byc6u+hXTEW8TvEnhpO+5rai/qTWJluRrCNmZudhe7IZ1ogdXPVREpXbFy0iBIuu9jfuouojmxUY9let2feY99FCsvYbxF77VsMRSymwNOy3utIj+PQ5fUsrUXZIjbad3WL66GLIXR1adPHofOFEZ8c2HoDV7pvPeORSxm4SGbPRTcRh+252EPfzbTErm8LHQD/Cl5IczZqxla2rZ+waMeoGSGqVczttqWOfdPYYYfmx2xrRVU5wdqB7QD8iNJnS6OWs3OlR9yd3ZeajTVdSV/L2Z3YeQCFV1r62GnEXhlrptKCxM53gAy3ZnqLNTzrQWjSkiel5cV1e8aNVqWtO3/kWhi+Xl15WEDue6kPwKfESVXHjnYRM8hcHLJr/bSuk8rhbJ8htnJn9hp6dg9gZHfxipVVx5Ya2BnTtlqq8Nbi2XyEr1R+uo4rS/aqiAQt2XjIwFLecfquEyHCV0Sme7OIo9G+XTtvOjY6g5ye8yaNverbvrUthcgf2FqJK9uzWExe03o8/ahYkWbWm82sV5rOtEnb+bOprdt2cyx3XtrA9czcL83ieOks8lRwmK3qaOYDF1Sn9ruIyhSaq2PjUQ3Hz7blV8fKadt6+JjtiLOwrexEZaS7kKaqJU1mslqNZxRxU8xiRAzKVRdsPEaXV7AtS28xF7Fe6Dj/oLqiK6x06aO0nN0sPl03r8odSNQezmgo8tqVUs1ZSWiYYpek4VIHztLElsrU3q3NahV5RrKa7pPMrgo9V1yls6uMYmftSjSt4EDuNEDqxj+Otu14FRK6beeWkY6PRfdYDhiJWrG1B1YKlyPe1YBdLn171rHsRxXe3bJrv+AFVhdlDCi30cJib7rwqwdRWmmRW2bthZTESWlrtjLCqptrFRYnjzZnGikm7rJ/VmrQ0suDvqtSBC8V/nrX5bKMV/kGz68psLHtKrjYreRX2y/1+8mIY2n8yWYyiDy2U123Nh45rTWKEPFu29FDT0pZjl3sAdfNKHb9T6PSD8bIlDa1bBsap4gD5G5lnTsd1nbfuYtVF9qzG3Vc7DlzUtF3kttxa6iuvTK97Vg5LlbrPatjc1seO+eZTWtb3ZvZMSrmS+b0qKGs8PKKHRhEs4t9npbFjLh87vYiishij+LrxW5L4uIQidWmxa5x19K37CLr7ZluX3L1cocXkUtztRSlzhJlTkf3nLUpSuZur6vrctpul6DYhVqyPSz2j/o2N5txG7aj2BvMrKfZsxjh8bed5Wm79WnX1Sh2pwazKEuxH5466vq2vwWOxF7xnmpmNQJsQTqTmNj1OrH9GThJSa0Gwi7DcBal6EWIWGDvA3FlyHBa++nNSqXOfyq9Kfg1Sy4qIvcmY2dfj65uOrPSxdzvzb6HEeuyoZvX0vsrNCFr02ymEcpZn0elTsgqWP5FfIr4A2IhR7UXe6WFBi14Xe6xlzsCxRp2iagtRqdYPxXjXZ5jOOpl+j9DWzd19uVoDLqa0iQ9yZrWfLp2bEBB4QMMImjYkqaqXvuon4T+Fval7XKqO6KIKclPPsspT37xyqQdlTuhxczoR8XefLkShlUaVMaytFplnEOOQ3ltTtqUY4X9BOzPFDupxRkmc9d3K58iJlPMgvIEGmIgLbu+K7258qQYfJ04SpyVwbkwnA5jS1YdmcJmjWbeXpM8lXgWCeAZhegjojfwl2JHPb6L0SvjZCUnyh0KxowxLuUOp3CkJEkZQ0zIJ1GFFS093lJncf8Z191IbjviFpKobCuPsK4tPdwmebXFGGFvp2wV61U+HQO/Lz0yc3Fqpz5qVOpCnqOIjZvPyK4VoZUKDuWWstyt2lZd3cFMKvqOW003wsV8K1fUWGMjfg0fpHqVzfRfNpsRcQR9d/wHa5hSppIZF3ktUo2rxrO1zdG8anSiFWVu7Ir2+m53MIlidxVHOD/Ju2DFrB4doTSppEEPlKfMsIYpd7fKeWJmnznPtmY/qxZW9f0J9zHXqy6nKIUTums2HrZiU1bt9ZL7NrChU9dnJ4jHOm2s08wHOFc9p+qqn4KCot0TFuOKa2PV0lNEGlZdvGHoTk0mTrPiJEK5EijOQEC3Iuqeu3VXERdoO98ycav+4qpjzxqltlw36s72iQufy3C/OL1YnCYaOH9rYL0s41GuOS+y9IHKfbq7/VT1kl+Kj3oF+JSy14j4DHB54lh+CrsAa9CxczBzOaU3gjVkc6ZZUQLli93P1Fr24WxmlXG6NMKapmFHo+XOLPZmOg67IUU/8lmsBLucTSfJZRwsndFTPa+MFRL2bLm35RoK66pyhV+UyCPsVSNWUM7xo/od1026PrrmQ+vlyc6qTonF2JR0otaaO29VxgALz8lnq8p1YClF8DrYJpV+R0vkHC1RTUE/46gaZS1jBOXOIso36a6uvTK3lJs8wolv43NhB7g7sw7FGhQ+QObazqjHvEtbynPRktExXbdS7EZ5ZdTKmFDLnRArI0HluZlSAjCqPNuKHQoZD2hSfvWUPU7ylpYe8lGUalQ41Zy114jKnSDMgdJna9Ady3JLpDRnfW7MUsvoQ292DctdSnnBg3xWp+BLfybHOOlcnO8s92ul3JfeTo/6WJRqk1bjnS/wkKOAPP84vel4Uc3rupV1XsFdrQ3PFH2FFJQWHvfJjE/wrnnEoEM4sshyhTFuEMbUcbC0CaXFRzyNNQpOVhS7+KUPDJ+14C7TgL5C3pPZOEMWi3xE9Mo5bWZFJ1qIzJozi05HxYnbvpuNOAUGf7k5i5Amu1e/9xvf/fU/92t/9sNf/ZXv/PKf+aVvf+ub3/jFr3/tF776wVd+/svv/9zPfumLX3jv3XduvX3zxud/5nOffevNveuf+fS1N15/9ZVPffLll1584fnnPnH1nnE3ic+q22nyzPSZd5P7zka3k1RfpvedVQeNZw6aNvHgUzuTg91Xr2+++Nr1K8+ub27urU83D3YPFrauGLj5zv4tZOxpFLqWrqtRvPj69MVX37w+ubJ/w2bqlDcqd0X+5VmeuzqYe+aN6wdXd/Qd3X/C3s9unxPZzyN7OjmIXtnff+d2NL+l03fXbyt7sfjMb+3pnuxND97emW5Or7+ry97WzuPmGzee0VcZrtTkExrj5Mfd6G0Ntz4z/bFyV29eP5jceG/vOV06mts6sP9f/3F0cfqt4vrGweTWZHLQ2Jq+/cr1/c0DdWO67u5fu645pm6u729ONyd7ez8+/P0TpvR0U+Oai56+PVXff/X2rvr+629e/0k3iibff+P6D+fU3DM3nt67fVrnXf/JJIp2beqcSTWJ5mZibqIXlR6ZH861bPn1n+xG0Yc2d8Em2Ptbuhc2rYU0Fd368VyR1i0a2rYN7UZzOmehyNlF6QWd1irSPrRp9p/mg+b9brK429qNd7O5fE5z2yT9UKf8tHgY769nKlfrt3Wt12zyj9WHt+Pd9aLEh7rEbkHh96+VTV978/pf1+sjtW7/6oaeNv/uO3vl9twnd6alPL56XbP9ym31yZ0bVibnt65MtDQe7L5+3ZS8sa4l8tn7zhqJmFyfvrs+3bs9HO5/cEVjmN6+2di+sbNfCIYRh2n3US1M81vP35pevWFKaOHW/5/XSbc+Pblx8PaNHX056V7dv2rG7qYpHS3dnpvfuq0WttST0ZO6743sIJm++/RBOn16lvNU9FSR0zA5zenTB2qp4NyV6ZXJypf2b03f1nKy+8r1L6y/t3dT4z7Ynd48WJg+vX57IXpaS/WK0p24cjv65I7uzYtaUj6188pbeiqZnk/295+d3N5d2L5566a5f3ZTc2LfZU2ffXaPalyZ7B/s3rx1Q5e4smcL6/miE69Mb07e0SzV3dW8en2qL99809R5483r+9k703emmqG7u/s3dbfXJ7f21vf3blkG6/qatOi+s4ulDnEqZM7MzK1b7+k/P55Eb9+Yvl0kmDkk074gE97TpTht+oJpzn4r+73/wvTKO7qEgZvvHMxr4dqcvLNXyEf0ip3dtYUUFZroMbXI97uP4U65O32j/+8ffKF6+8XZ7VUDNzTX7i9k5WBh28ja9c2Dn10/eH9vZ1bk5sGHb0/2J93po1Pzx1b+hIEbB4v64sNbN40KaRjZ0wkv6ITJ9be19GqEV2/sQ+J0tYXtWUsHP79TQakVn3pDNz23Zbpz8OErkxt7kxs3dKqeKpvrk4NF/T1576YRLqMcXyn684rW0Prr5v7rum60pxtdP2hqPf3ezXenm1qn6rS9vYL7hsYFTV30+vWDaH1/f7p/oDSJW1d1YY1++6Cx/bz50v8/2JnefFcPomlvcvNdW/eqJtdyx2BbvzLd3NNF5rYsLzXjtDZ62/y5ta+l8eBzerYtbvX2+/uTR/av/zT6nFaLC9u3Pn1DK+9Jd3J1Yof6ppZkw4Tnzd2eRlQUjLdMQV3f/t8++PLO7c81t8oU+/8rO0XhlsWqKXvt+sErKNK0//XFV3cO5pYv60zTefWatgELdqAM8xa3ntfs3dVStW5qTw7m3rjuhsfWf95UXceAFdV0ilWdxnhtgt60oLdotGH/Z/Z/vHXQ2tIDfbCgaSiym6Y7pRDoa010UWfeklt0QF/rpiYux3bkhrtZ2HrX9qkwWhOjLbU5vzk1sP7jw7/5iraaN6YG9vZM8y3bkKlhUe8XiA27GibTxwrXUvE/Nf+ft13g5MT+b1qaTV7RpcUq4x33fnL4N6OCc5vun5EZ08vvuVnp5t276wdf3Nt5p6jVcBp8ojWq1ty3XrU+wVt6Nkw3m1qP6e7rWTU5eH1H2wzbt+8VXH2h0A5GKtXVaXRVy5C70E7aQTR9Tpk/kZ5a0+cO5vTt7Gr6w7lItaaXzVc8vXx7TjW1tjfKqJtnWtHv37rxTmFONZejy+uPGwemYQc6tmP7DaOa3ri+uL6wZ0Vm++CbO06Ki7/f2Jnlf9PMySY42TJ5+7PMRYvum4VsbLu/39hpeWvtt+6usZYbzYPY5hlttN06vqn5YoBeKIbrhbkC8wuFntCp27f2941qu/25tpmh2XZPp/c1aY9oIh9xVGre/LIm5RXTdMum2Fs93ZqGnGLYtlKd0dVlf78Q7VRndjU1v79elNL/f3J4GH1jB6ULJmi6k61Czl22q11I5zd39vTVVQM3dJGrBtxMSt0szYTWd+iLMY2rmdMZMmPopzOM5u62yrSnurC+qFvcnnQ1ux61/NzWpOr7/Udvq+a2K7BoCsxtPbq/n0L/G/X/E+0mRtYFjPb2ZcLBd/R46LHO/TktmZrbZDfK+ezbJLrpkDxzkD5j/Bdjm2IjAPfr8f3OHzidY90JYoxNMlORU1cM75tQCV/ZQV3w7T07pV1dkfrG9e/oVMOpPzCW5EDp78XtTQPrhnW2NSPjX9lxzup3zOj+mkX3azuTyZe0n/WM0t6WNpRfMqZqYkq3tq2S29cOz5du3rR6yC42VrQv9ZrxcLWfPu1O1OPR48WSZepWA9oGLGxdf3z9kT3t/f/48H85sVeoqjlt5DW8sT+ZdHs6a3/S18uBg+9a9rq8qU3TVryx7UqZHnxXT05TTg/L4WcvrI3furA7fvPC4XjvwcPx9fMfjj9zfnf86QcOx9ce2Bm/ce5w/Pp9k/Fr9++OX73/cPzK2cPxp87ujD/5sZ3xyx87HL907+H4xXu64xfu2Rk/f8/h+Lkzu+NPnDkcX90+HF/ZOhw/e/rD8TManp6ujT8+/XC8q+GpU7vjJ08djp/Q349vHo4fmxyOHx0fjh85eTi+vLE0fnhjZ3xp43B8cWN3/NCJw/H99304vm/nw/HZncl4a/VwfLq1vvrZaWtt9bOn9N3m0uF4kq0sfXa8nI9PLh+ON3TCiaV8vL6+Gr21srIUvbVmrpbN1Wj18tLlNzsjdThSg5f713af6x12r/X3unv5y9m1xZcXrmV7C3udD9vX0peTa82XG9dUN7rW3kv2GnvRXvxy69r8y3PXWntze5O5V/Sy5WDuj+YW53d3F9VP1O9Eb+y8+OPm4WsvHrReeetAff9g63XzVzu+B43vH0TX3nzr+m2lfnvvuz/4QbTx9IsHv/P69R/OR/pS+0Jzz7x6/fbC/G/vfS3aiXZ2diL32XHX+Ku+9nW1g49JNF9Kfxfg/tl6ChdHLsu7nZ2V6EeH/yz6a3qZZODrGqISDv8nrb1uR5G7NzF4c1K4bf827F3XxmraNkph4sXmNPSqiwKbGLx5w8dI145tva4954haxVOsJq6V2b9F/YGNaXQsluJJx9ye6lu216b+XFSc4Qr/wr/wL/wL/8K/8C/8C//Cv/Av/Av/wr/wL/wL/8I//PvG/zdA/e3/Z2HuNwIECBAgQIAAAQIECBAgQIAAAQIE+FcP5v98gAABAgT41wEWPggQIECAAAECBAgQIECAAAECBAgQIECAAAECBAgQIECAAAECBAgQIECAAAECBAgQIECAAAECBAgQIECAAAECBAgQIECAAAECBAgQIMC/LFjsBwgQIECAAAECBAgQIECAAAECBAgQIECAAAECBAgQIECAAAEC/P8LGr8bIECAAAECBAgQIECAAAECBAgQIECAAAECBAgQIECAAP/vQXM3QIAAAQLcFfxRgH+Z0PqTAAECBAgQIECAAAECBAgQIECAApJLAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIE+NcIVDQ9/D+jfxj9jehktLybRCdOzCXRSI3monPnvnqh/8i5Cw+cf/jCw8unGo3RcOnChUuXHr6wtLTcaE5PbV986NLD01PN6dezQfszJxa7v5wuqEW1mDXXvzfIlz/3Rp7+MB3c2EkWkvmlrbUTcz3VbyZn356PosUoOfx70T+J/k70UvRK9EZ0PfpsdHP3/sGb3TcXF88/t/rpl5Y+vbd3fvzMiWeuXTv/yddOvfb00+fveeTlR1599fz9D+08dPly63xLU2jou9C70Kv90t+41/0YLjcvTkdLze0zF5cuXbyoaT9zofp31Lz00Jlld6uvmiPd96n50ywqmyubdmZ04eIFDU0Hf0t1HlIrarLWPZen8Suf1H++cr/+86kLbaU6D17Vl19QK/GzndEXL7Q6LV36wVYvjtvDnT93of2Q+XdmsdvIV/qtdmtxQeX5fLw2H6/Mx6PGYnc4bIzm436WNrPOaBRnjWHabI2SvDFqD99c1/8eX1k5ubYWzWu+/t3oH2u+JtFGdF90726/OVA7nfX1weDUmZMnd3aWTi05vhUc6tmP5s3DS0ujYWN66sy27mGjabq41GieuXRJs+PSmQvbZ2wBm36q+am5Ydqam59feGk5jocXOqOfqGw8v9Kc673V/7feV4P5URpf6S79p3n6F+bzzuJimnWXsoV0tTM6/dh4/uRLk/j0Wm9pPs0Wmq3u0nzUiDItD/80+m90D5pRGnWi1Wg3en731NJC79ypJyZPrK2di/Ot/PHHz6nF1mKWndu5EF1YWNg4t3EnKSh6R4Nlvk1nGrazy3pYL12c8uBrEV9uWA6UY757qf3IdzR8fa49Uk21sNC4T3XVtbz1s5c6SnVfanbmh61Bdk+rG6v2Iy92l353U/87c0r/+9x8q9fW4/YX7s2b07W51jhrnLh8Ik7Hqa7TibPmE4NGOu4uRZoL48P/Nfq70X8ZtaN+tBltRQ9Fl6PHdteb3cXFyaWdnUna6UzOX7w4ma6sTE6eOnXf5D4MpgcenEl80S8ruRfPHE1qHk36H7V8dozctrovPLSqOq+bXr7S6n7p9cdV57zJOdfqfuL8C88ljaVBY3l3OUny+aeeev/8WqOTL07Oj2J7/7WHV5qjpcbqx5fipD331FNRNBelh38/+uPob0fj6GPRxm622lhenixEGxvtSXs2lo56I2zFQLTnmlYC9dhMjVSaCVpK7Jn0P++M/oxa+HjSTZJWr7OwodZ7cavxTO/VuTefytPPrMUtM2btv9gZDVaTTuPlE+lCN1toqdbOhc9sLVz45vyjSXthIU07bS1/Rjf973oOGVk8ET0VXYt+JvpS9Pnd+9be3fn8+M3o01evbS+urIw1ynEcReOzFy488MD4kTOXzuzsjJ869fip7e3uuOsVzF51lC486ET0wUJG7QAVY1BoqQcvFgPzcEUXFX+E9tI8Gg2tVn740sWHrIq79HBTy7nlEDHrg729vS+0P9PoNrWaXx/09trqvFpqfSzvPbeRdR+50O59Tyur5/v6z4Wx/tNcXphbmM/mF9JOP05XH58stOYW5hZ7yycWW2p+frFzbTBYXVm5J07S5uv9ZruxMNdce6DZ/+xnV1txs5cPRll/NR/Mx6tamc3HGz+zerq5sNhsxOniYrywoAXr0/OdQdzKB4/l2fxiGrf7xkLsHP6D6I+iP4iWo3UtK9PoTHRhd7mbb21Gm61WvrF6enUyyU+0V1YW8gUWHJ77hqtauB9+qCLeRtzPCI3wm3o6f9wI+Q+Sdqw6/8bH27sGXnhgpdccrD7UbW29cDpJ2o3nVzuN7s+d1/8evl//0zIy0HT+o+hvaX1rZuy53dHa9MSJfHzqVN5fWDh5Mu+kmtxIUwgCezxDlwuV87AdRz2oy4W8j4opedFR+KhSvZOJ2tWj8Z/kgw/y1vBq0m6p7vv639LaL6y2TmlzkQ9aaluTePNkvjjs/M7ly08+8YTmY3r4j62l1ZRaXj4ffWp368TpTK2OBoNopTkcnj5/+fLFi6efPPvY2QceOH3m2c2Pb+7sdE+TBB8V4QsXHtTJF2batTnTHYVkQuOeKayGUanNY8VXW5jtM39x8weq8ytxO26n3f/CyN80P/XsWrO1k88P4+X7s971h9Lup65kvb+mM2+c1X9evqT/PDk3N99+8sqVK0+NtEVtPpX25uMr5t/vpPlcs7ney9XJrL+R9iZZfz6eaBmcjxfjVkdzZ3D4P2vv5+/o0Xsi+nh0RXsjr++eeWnt6vzphzcffuyx5NIzZ84kTz39dHLfk08mSxsba2tafQwa8/Mnk5PVGV6d2sL+uAF+iKyoY4hOXr4k3A+2PNPh8hlohnIO/3ay+Cnd8ZfSuV6z8WDef7ATDy93+j/Sae+oK/rve+eMkv7ZVld7GueudPrvqSe1rLzdjbXZnpuPvz/Q87GttWo8v9BsD5O5tfZwPv4PN5P5eL2xmF/qaP3dOD1sxOv54ETyq8vLG6PR23GysJjEbS3M0f8NbMvTng0KZW5kc3RyZWFtDWVuZG9iag0yIDAgb2JqDTw8L0NvdW50IDEgL0tpZHMgWzYgMCBSXSAvVHlwZSAvUGFnZXM+Pg1lbmRvYmoNNCAwIG9iag08PC9OYW1lcyBbXT4+DWVuZG9iag01IDAgb2JqDTw8Pj4NZW5kb2JqDXhyZWYNCjAgMTUNCjAwMDAwMDAwMDAgNjU1MzUgZg0KMDAwMDAwMDAxNiAwMDAwMCBuDQowMDAwMDI3NzU1IDAwMDAwIG4NCjAwMDAwMDAxMDMgMDAwMDAgbg0KMDAwMDAyNzgxMCAwMDAwMCBuDQowMDAwMDI3ODM5IDAwMDAwIG4NCjAwMDAwMDA0NDIgMDAwMDAgbg0KMDAwMDAwMDU5NSAwMDAwMCBuDQowMDAwMDAxMDQyIDAwMDAwIG4NCjAwMDAwMDExNzkgMDAwMDAgbg0KMDAwMDAwMTYyOSAwMDAwMCBuDQowMDAwMDAxNzkyIDAwMDAwIG4NCjAwMDAwMDIxMDEgMDAwMDAgbg0KMDAwMDAwMDM3MCAwMDAwMCBuDQowMDAwMDAxNTU2IDAwMDAwIG4NCnRyYWlsZXI8PC9TaXplIDE1IC9Sb290IDEgMCBSIC9JbmZvIDMgMCBSIC9JRCBbPGIwMTVmZTJiYzg3YjQ2ZTBiMzYzNTYyMzJjZWZiYmE2Pjw5NGM0NjEyN2QyODc0ZTgxOThmMTAyYWM4MmVkOGE5Mj5dPj4Nc3RhcnR4cmVmDTI3ODU5DSUlRU9GDQ=='),
        );
        
        $documentFederationId = '';
        $signOrderly = true;
        
        $imageLabels = array(
            ImageLabel::buildData('品牌logo1', 'iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAIAAAD/gAIDAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAA7vSURBVHhe7VwJkBTVGe5rrp09Zi/YZS+WBRa5WRCIVAmCRNR4oHgkKloeYFCjJCEGNdEYNYdH4VWWpaIVFOVStKJCQMSoIAUoN+xyLu7FIsxesztHd7/8//96m2U5nMceSar6q66v//e6Z7rnva//97+jR2aMSQ7ig2LtHcQBp7AE4BSWAJzCEoBTWAJwCksATmEJwCksATiFJQCnsATgFJYAnMISwH+1I91SJh26FY3m3cimIRlUeUyVTBkNg+4N71DDvfc8TBbOkTMvQ0NWkbsRjrIE0O3KqvkDcu3fkZksySgZyWsgewzJHUPDviOdsyI1e2DPgn5MxhSJ0flaOpA8vhTtboGjLAF0l7JaNiIfHCOZJCU/XTSJK6eNlEzidsqCJM/nSVNizV40jicBsSiTek4DQxn+CmZ2JRxlCaCLlVX5S+S6VyWVaiXLOKEajrZJsHkSmEvJFhrPJ4cmgb/i+THeYkpmQyIajQlyz+thL494AZNdAEdZAugyZTWsRC6/EjndkPzUftka4XVkJznA5pIB8Hz60Il8nrSVZbWVVj6LyexIT7QU9GXKJaWSTNLrPHRNYVX/Var9Mxq9m5Hte4ZL8avxnHZXtgsFwA3Odn6rgz9Rapz5UXjEIy7Ys6MYUjAjpl7xAx3oNDiPoQA6W1k185CrHpHSo2gEyCeDjuyLnFZTHLaCwOAncO3YSVtZbYXWRlkYvqKBbFRnyHkzwVCGP4aZnQFHWQLoPGW1HEDeXoLct96qBaG6gBsRUhY/2lZZVjBBHWxTNqoz0XAhq1O+67i/d5QlgE5SlqlLGwJo9KPmT2VWLZxal6etXX4LwGdSFs+3uW0S5MYNONnyYnRtQzV54/hDCiYL71OHzkWjA3CUJYBOUtaWCVLLTjQGtIY2fGAuTi/Bb8FWEBg8Jx5ltfVZJylLYVEaMgxhr9ts9Gp5DWgEvcfd2OXOGI99IyE4yhJAR5XF9t8P3PTwh9Ev0EHYhd9WUnABmSofx+xohEYdjRpw9Wn23N8IhpbVgrkQmXFpnKqstklbWXamrSx+gk4XB31xZVHwZTYkSBr2tyuX+CqX40XH1JQDK6rA2LSjLAF0SFnw2arsfmD4XHE6p/bgF5dJUCwmqWPR0oqb3deHwXCfh14GFcclc1plgW0ftXwWZ1XSSVkUXoW3JtU8iMoKu80Qw8+nPPEocL877wCOE46yBNAhZW3o1btIRVfVRUXOqH+JyvKhOpShqBw1EFEGYpdTzcQ7V3vrltBMySjDm9G3oRsyqjzGRnKjNAQtu6Qo/dKQaXBlBX0+4PEH9uDh+HCOhbXtjruB1U9XZFNhWY8ToINdCuux7NiXnAE6fTkUWYOJD+qxSAR4bHmZKwnHv+KB8xgKQFhZ/Py1adnAOT5fOk0aJ7z0LA8WWh54EHfnJA0Wjvi/XAVG88RLJZEWPS4wPteIymqix/CYgQ910fuLeo67gI78OBxlCUC4sIxQCDa3qsKG+gFSZd911/qm4SYT8DwQ4Klbu3wbPBmLaXl5sJmG0f4EjlgMNhY9aeOZlB+VTBM3/lnYTNzk3F6wJa74kMWisMnQxzcZbNDZhy24dq315XHAUZYAhH3WkXXrgQ9PxV5ouubKmHQRGMn/eAOPSdLxPIxRJY/Lv2A+7FkzjtjEVq52/3QSGKHpM7yPPQSG2qc38PHrpydMngCG9y6MDMMr//VDLfbD8+bOUQM44NM461fA5sZvlXFjwQi8twD4LKjtkQ8cWPVPYPeQwZTX6kBlmRnoqiDFf/C6wgHACaNGjlj2LmX8OBxlCUBYWZtvvg2YrV4DnKlpuds2gaGmpeExSaq/4RbglEULYuBHoHF8+lng5Id+z69RN2pc6qavwdDBK4FwCopTK/bREcQmT9KoCHZxtw4dldWM3Z1IKAScPHZU4IMlYKy//Crgok1bXNPQcE0YD9x0z2z+ExRFcbndYLBC1Ffi88/IJCX3SBrpluXo5m/xKNzk1/hwVPwFV/Io48YNX7oQT4gDjrIEIKystcPPB06pOQKcpmkFFTRPAV5swwbg/NGjMSHL30zGxXnn9cQp4pS336ygo6lle/233AzG4dWfASfeNjONlMXvIJhblFaxH4zQtm3hKVeDIVO0lfDC096pmKzKzAP2uNzplaRHckbBvH72D2Ak2LRyXLEFotpx5bVgDPv0I2BD17dOmAxGyVefb5l5D57wEbo2o6Tk/I8/ACMeOMoSgLCyVrixJ5WVngqcrmh5lZay1k+7EfgnS98Dhu/8Pgvbu6wvUUHu/n233vcAGEMef0xJxWZu++w5wDkLF6UdOQxG7fYdwNqUq9IqUVmAxl27gKOTrwAO7P5OTU7GzGt/Dsy83uR33gQDxAIcIi8JkAcWR197CwzffhrgBqemoBRc1GGORSIxOj9WV3dgGLatuobC1CZNHPEOfioeCBfWZwnoy9NTsMjSTJZPv9ZkbF8qdoD619UANweDzQPRrWZUHwQGlGUXAvdvTR7I7QucMe3q5HnPgLHuGgxEijdsxpASPPp361xZ+G319KkNgwcG3Nhdl6lLVXDfrB5T8IE6tAr7RvuefREYkL1124Dv6fFs/UWqizr5BIMaHABkli1ZCkbwntnAJXt3uFJo+icOOI+hAISVtdqPyspMRmUFdKPgaAUY4YaGFpKSHQro1dXASlYWMjTblHRlZfHOUKyyEljr1YsndxYPBR6w6eumh3B5bsJvZ7sKCsDgIa6ckZ746ktg1P4aH96sj5erpIW1w7ExGffKiw233A6GFI6452E0oNHTB/Bdg80CR93iZd4eODXtnXDh0fXY2pRejkdHHyp10zMeDxxlCaBDPqvw0YdT7p4Bxq6ly7L44Mxr6EHcY8cGy/aCkfjvL4Fdd94eLCsDw79zt3sqxpPBUkxmFvXhnvtoXn9gc+H8VAogY/UNGy/F00qCdcCBPVt476ciBXWaW49uEVAaQL9WXFdd/ukKMJLuuvfgDAyYbYz84yPAoePHgXe9+PKQ36CT8iYmfvaL6Xj4fQwpJoXxEnHCUZYAhJXFQ4fsFFTEkOpyRaOJwDPgWE4RsNzqRLSfXZL4/HNgHCeflVFYuGU+BgEFjz4FfNJ9RHH4Pe0ITu2ZhrGyRy4YFz75J2D/3TOO7kXP6LpoCnCgYh+0xWAE58ytJV/Gf5EZDg9+6nEw9ixZBly/c49CV6h/+91c6kU1XDAGePSyRcBxwlGWAISVtabfIODkFpxD7rt5fWNtLWVDfWKIlN2/GFh1u6tLsc/ho6gS+iXqhTh0m7hg/poRGBCOGURfsvCtb3pR/KWeLE/DaJh+E+yr69GhJCvyoJdPrNY2DGNNPvq4kSTY+ptuqIqgDHssXprzJC7yS7iNXFJr1LqHwuNsn4//zpBp8gmLQurS+3NyKDsuOMoSgLCyNt+KQQ1buRq4p6r55ZOKG6OmNuCzwSCG1MMotI8nTblgP7qhQOlWPOrxNBTiW3FnvwMjMbG8BQcRZVJKaiQS8GIP5lQ0XIwjkXU0xxXU9axVn4PRM5Fej6JuBnAzM+upnzC4+hBwuxs+OxxlCUBYWYfewG5n9VwMtTNcGvSlKfusME3Pig9h728d6j28A3vOVRMv7e+h+eJuQYx+aaNhHC9CLzb6K9SdEBxlCUBYWTGag9iQj722DLe7R7uGzAa6l1MQhwq7DofDOPBQ+DtvyhyB9Q1tIVxYHGtz+wCnGUaOhsPesi7JReg1E25C56rlo01odaB0ERaWjCOoZaMGObZdMcpxLJRVtp6GX9bG6Qq531PBfxmx4TMTH8AKdE2Ypw2eCsbrr78OHI1GZ82ahWfEAecxFMA5Kqvsb08DN897KcuHj1b6c2GZf42JOznJUHJxnkZOpfWPkMc1wmRWj60+C9I0TJOHNdKaBn4UKo6eU71CNQ5ilr6FFg/VKqwKk1aUAuaZqti6BzJN5hqHwac2EdN4e2F0IL45R/HwOcFRlgDOUVkc63P6nP8CX3DG+AvP2iCr93OSuwH7tBfRZSlGymo9ajah4swjfinENUZ12e7jrDVl7awpZqbjK4do0XIZZkAOJbn/NCXv/QdhL58cRQvBUZYAOqSsWKhZ/gQHYSTFxf9rQRtTRUkkhK2v014E6pzn88qPKSxCgjJl7vt4kjV6WQP5uGirDK2vtXTEV14xQ+bxirUQy5AZ/8MRyIevjLb4H2xV/bnCUZYAOqQsAGuhxqX5mPEFTkGrg3H+Qk6IWZXfTlnAtsGZa4oDklwUusxaKP6iN5VQaKQOFqOqjan8PQDrJd+oYh0Fn0WG9YKCKbOwlQ/wXLdUzafZ8g7AUZYAOqqsEzCxM6EvwcE8dWSN7CGRtKsLqPO2UgKbX5xn2spqVZzVukU0S0RhEpqh8FaS0QtNIDer1TMU63xKgqDMEJ6gDsRxRM9lOHLdQTjKEkDnKYtgtuDqGnP5MCkBk9pwTGKN8Iu0SuYUKZEiIIDiGrHzeW8cdGRyKVFbCYKiJH+91wRHRn+2BY6MPgz3gHu9yuOdiZOpShJOoHUKHGUJoJOVxQFNpL58CBhK3yZgNTPUXlk8CbalLB5AySeUxf2OFZFD2EWVqtNpGIVxoVES4in+N266oteT1o6ha5P9ub5ZX2F+56FLCguhYxc6thhXy0gJpjYYp5GxUbdLDWAXFv+fKCgsHhzYz2OUF5bC2jx3VFhUlNYbq9DdQUNvUo0aPMFVgst53ZPxpa/OBV3PQXzoMmW1gb57vvnNw2glKK5i7HPIKikKBGL9BSLVmemyok3w6zwsiPB8+7njSet8HoLGyr3Wl7gCCbO3odFloMs7iA/doSwb4TcKZFojiy+xAGU3ahm47MCqM6byrjLGmdQO8E6P7aS4vsywapALt3ozkuK5cTEYWj6uDO5SOMoSQLcqC2AGcd1WbNW9wOzoTito0FBIst9Qk3EoEX2Tindl1tMQTVgxw1SpES40ncmoLPfFTwC7SrA30z1wlCWA7lbWacFiNK+htxhln8DePFYKDg0MOQXX5CjZw5Q0XOsie+NdVtxFcJQlgP8JZf2/wFGWAJzCEoBTWAJwCksATmEJwCksATiFJQCnsATgFFbckKT/AL3HXXq+Udm/AAAAAElFTkSuQmCC', 'logo.png'),
        );
        
        $response = $sdk->templatesSendContractsSyncV2($templateId, $contractName, $sender, $roles, $textLabels, $documents, $documentFederationId, $signOrderly, $imageLabels);
        
        $this->addToLog('TEST ' . __FUNCTION__ . ' response: ');
        $this->dump(isset($response['response_json']) ? $response['response_json'] : $response);
        $this->addToLog('');
    }
    
    public function test_usersBindingExistence()
    {
        $this->outputInfo();
        
        $this->addToLog('');
        $this->addToLog('TEST ' . __FUNCTION__ . '......');
        
        $sdk = $this->_sdk;
        $response = $sdk->usersBindingExistence('ssodemodevaccountid');
        
        $this->addToLog('TEST ' . __FUNCTION__ . ' response: ');
        $this->dump(isset($response['response_json']) ? $response['response_json'] : $response);
        $this->addToLog('');
    }
    
    
    
    protected function addToLog($message)
    {
        Logger::addToLog($message);
        echo print_r($message, true) . "\n";
    }
    
    protected function outputInfo()
    {
        if ($this->_is_output_info)
        {
            return;
        }
        $this->_is_output_info = true;
        $mid = $this->_sdk->getMid();
        $host = $this->_sdk->getHost();
        
        $message = 'Test mid: ' . $mid . '; host: ' . $host;
        Logger::addToLog($message);
        echo "{$message}\n";
    }
    
    protected function dump($value)
    {
        $output = print_r($value, true);
        Logger::addToLog($output);
        if (Logger::getDebugLevel() == Logger::DEBUG_LEVEL_INFO && strlen($output) > 1030)
        {
            $output = substr($output, 0, 1024) . "......";
        }
        echo "{$output}\n";
    }
    
    protected function dump2($value)
    {
        $is_large = false;
        if (strlen($value) > 256)
        {
            $value = substr($value, 0, 256);
            $is_large = true;
        }
        
        $j = 0;
        $line = '';
        for ($i = 0; $i < strlen($value); $i++)
        {
            $ch = substr($value, $i, 1);
            $ch = ord($ch);
            $hex = strtoupper(dechex($ch));
            if (strlen($hex) < 2)
            {
                $hex = "0{$hex}";
            }
            
            if (($j + 1) % 16 != 0)
            {
                $line .= "{$hex} ";
                $j++;
            }
            else
            {
                $line .= "{$hex}";
                $output = print_r($line, true);
                Logger::addToLog($line);
                if (Logger::getDebugLevel() != Logger::DEBUG_LEVEL_NONE)
                {
                    echo "{$line}\n";
                }
                $line = '';
                $j = 0;
            }
        }
        
        if ($is_large)
        {
            Logger::addToLog('......');
            if (Logger::getDebugLevel() != Logger::DEBUG_LEVEL_NONE)
            {
                echo "......\n";
            }
        }
    }
    
    private function _getSdk($config_name)
    {
        $server_config = $this->_getServerConfig($config_name);
        $mid = $server_config['mid'];
        $access_key = $server_config['access_key'];
        $pem = $server_config['pem'];
        $host = $server_config['host'];
        
        $sdk = SDK::getInstance($mid, $access_key, $pem, $host);
        $sdk->setDebugLevel(Logger::DEBUG_LEVEL_INFO);
        $sdk->setLogDir(__DIR__);
        return $sdk;
    }
    
    private function _getServerConfig($config_name)
    {
        require(__DIR__ . '/conf/config.php');
        if (!array_key_exists($config_name, $SERVERS_CONFIG))
        {
            die('ERROR: $SERVERS_CONFIG[' . $config_name . "] not exists\n");
        }
        return $SERVERS_CONFIG[$config_name];
    }
}

function testAll()
{
    testDemo();
}

function testDemo()
{
    $tester = Tester::getInstance('demo');
    $tester->test_contractsDetail();
    $tester->test_contractsDownloadFile();
    $tester->test_contractsRemind();
    $tester->test_contractsSign();
    $tester->test_entsBoxGetArchiveInfo();
    $tester->test_entsBoxRequestAuthorizationCollection();
    $tester->test_entsBoxEntProxyCollection();
    $tester->test_entsBoxGetEntCollectionList();
    $tester->test_entsBoxGetEntAuthorizationInfo();
    $tester->test_templatesOverview();
    $tester->test_templatesSendContractsSyncV2();
    $tester->test_templatesSendContractsSyncV2_2();
}

//****************************************************************************************************
// helper functions
//****************************************************************************************************
//随机身份证
function randomIDCard()
{
    $a = rand(110000, 650999);
    
    $yy = rand(1950, 2000);
    $mm = rand(3, 12);
    $dd = rand(1, 30);
    if (strlen($mm) != 2)
    {
        $mm = '0' . $mm;
    }
    if (strlen($dd) != 2)
    {
        $dd = '0' . $dd;
    }
    
    $b = rand(0, 999);
    if (strlen($b) == 1)
    {
        $b = '00' . $b;
    }
    else if (strlen($b) == 2)
    {
        $b = '0' . $b;
    }
    
    $s = $a . $yy . $mm . $dd . $b;
    //System.out.println(s);
    
    $nums = array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2);
    $m = 0;
    for ($i = 0; $i < strlen($s); $i++)
    {
        $c = substr($s, $i, 1);
        $n = (int)$c;
        $n2 = $nums[$i];
        $m += $n * $n2;
    }
    $m = $m % 11;
    
    $codes = array('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2');
    $code = $codes[$m];
    $s .= $code;
    return $s;
}

function getResource($file_name)
{
    $path = __DIR__ . '/resources/' . $file_name;
    return file_get_contents($path);   
}
