<?php
ini_set('display_errors', 'On');
error_reporting(E_ERROR | E_PARSE | E_CORE_ERROR | E_COMPILE_ERROR | E_USER_ERROR | E_RECOVERABLE_ERROR);

ini_set('memory_limit', '512M');
date_default_timezone_set('Asia/Chongqing');
setlocale(LC_ALL, 'zh_CN.UTF-8');
mb_internal_encoding('utf-8');
set_time_limit(60);

