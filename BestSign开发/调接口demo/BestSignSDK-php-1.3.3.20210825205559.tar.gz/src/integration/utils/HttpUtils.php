<?php
namespace BestSignSDK;

class HttpUtils
{
    const DEFAULT_CONNECT_TIMEOUT = 5; //默认连接超时
    const DEFAULT_READ_TIMEOUT = 60; //默认读取超时
    const MAX_REDIRECT_COUNT = 10;
    
    private static $_instances;
    
    private $_default_user_agent = '';
    private $_response_headers = '';
    
    public static function create()
    {   
        $class = __CLASS__;
        return new $class();
    }
    
    public function setDefaultUserAgent($user_agent) {
        $this->_default_user_agent = $user_agent;
        return $this;
    }
    
    public function get($request_url, array $request_headers = array(), $auto_redirect = true, $cookie_file = null) 
    {
        return $this->_request($request_url, "GET", null, null, $request_headers, $auto_redirect, $cookie_file);
    }
    
    public function post($request_url, $post_data = null, $post_files = null, array $request_headers = array(), $cookie_file = null)
    {
        return $this->_request($request_url, "POST", $post_data, $post_files, $request_headers, $cookie_file);
    }
    
    private function _headerCallback($ch, $data)
    {
        $this->_response_headers .= $data;
        return strlen($data);
    }
    
    private function _request($request_url, $request_method = "GET", $post_data = null, $post_files = null, array $request_headers = array(), $auto_redirect = true, $cookie_file = null)
    {
        //$url = 'http://localhost/ssq/test.php';
        if (strcasecmp($request_method, "POST") == 0) {
            $request_method = 'POST';
        }
        else {
            $request_method = 'GET';
        }
        
        if (Logger::isDebug()) {
            Logger::addToLog('');
            Logger::addToLog('********************************************************************************');
            Logger::addToLog('Start request: ');
            Logger::addToLog('********************************************************************************');
            Logger::addToLog($request_method . ': ' . $request_url);
        }
        
        if (!empty($post_files) && !is_array($post_files))
        {
            $post_files = array();
        }
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $request_url);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, self::DEFAULT_CONNECT_TIMEOUT);
        curl_setopt($ch, CURLOPT_TIMEOUT, self::DEFAULT_READ_TIMEOUT);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        //curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
        
        if (!empty($cookie_file))
        {
            curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie_file);
            curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie_file);     
        }
        
        // set location
        if ($auto_redirect)
        {
            curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_MAXREDIRS, self::MAX_REDIRECT_COUNT);
        }
        
        // set callback
        $this->_response_headers = '';
        curl_setopt($ch, CURLOPT_HEADERFUNCTION, array($this, '_headerCallback'));
        
        // set https
        if (0 == strcasecmp('https://', substr($request_url, 0, 8)))
        {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);    
        }
        
        // set headers
        Logger::addToLog("REQUEST HEADERS: $request_url");
        if (!is_array($request_headers))
        {
            $request_headers = array();
        }
        if (!empty($this->_default_user_agent))
        {
            $has_user_agent = false;
            foreach ($request_headers as $line)
            {
                $row = explode(':', $line);
                $name = trim($row[0]);
                if (strcasecmp($name, 'User-Agent') == 0)
                {
                    $has_user_agent = true;
                    break;
                }
            }
            if (!$has_user_agent)
            {
                $request_headers[] = "User-Agent: " . $this->_default_user_agent;
            }
        }
        
        if (!empty($request_headers)) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $request_headers);
            foreach ($request_headers as $line)
            {
                Logger::addToLog($line);
            }
        }
        Logger::addToLog("");
        
        // set post
        if ($request_method == 'POST')
        {
            Logger::addToLog("POST: ");
            
            curl_setopt($ch, CURLOPT_POST, 1);
            if (!empty($post_data) || !empty($post_files))
            {
                $post = array();
                if (!empty($post_files)) {
                    foreach ($post_files as $name => $file_path) {
                        if (is_file($file_path)) {
                            $post[$name] = "@{$file_path}";    
                        }
                    }
                    if (!is_array($post_data)) {
                        $tmp_post_data_list = implode('&', $post_data);
                        $post_data = array();
                        foreach ($tmp_post_data_list as $line) {
                            $item = explode('=', $line);
                            $name = $item[0];
                            $value = isset($item[1]) ? rawurldecode($item[1]) : '';
                            $post[$name] = $value;
                        }
                    }
                }
                else {
                    $post = $post_data;
                }
                
                if (!empty($post)) {
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
                    
                    if (Logger::isDebug()) {
                        $lines = print_r($post, true);
                        if (Logger::getDebugLevel() == Logger::DEBUG_LEVEL_INFO && strlen($post) >= 1030)
                        {
                            $lines = substr($lines, 0, 1024) . '......';
                        }
                        $tmp = $lines;
                        $lines = '';
                        for ($i = 0; $i < strlen($tmp); $i++) {
                            $c = substr($tmp, $i, 1);
                            $n = ord($c);
                            if ($n == 0 || $n > 127) {
                                $lines .= '?';
                            }
                            else {
                                $lines .= $c;
                            }
                        }
                        $lines = explode("\n", $lines);
                        foreach ($lines as $line) {
                            Logger::addToLog($line);
                        }
                    }
                }
            }
            
            Logger::addToLog('');
        }
        
        $response_body = curl_exec($ch);
        $info = curl_getinfo($ch);
        $http_code = $info['http_code'];
        $errno = 0;
        $errmsg = '';
        
        $errno = curl_errno($ch);
        $errmsg = curl_error($ch);
        
        if (false === $response_body) {
            $errno = curl_errno($ch);
            $errmsg = curl_error($ch);
        }
        curl_close($ch);
        
        Logger::addToLog("RESPONSE: {$request_url}");
        Logger::addToLog("RESPONSE CODE OF {$request_url}: {$http_code} ");
        if ($errno != 0) {
            Logger::addToLog("RESPONSE ERROR OF {$request_url}: {$errno} - {$errmsg}");
        }
        Logger::addToLog('');
        
        Logger::addToLog("RESPONSE INFO OF {$request_url}:");
        $lines = explode("\n", print_r($info, true));
        foreach ($lines as $line)
        {
            Logger::addToLog($line);
        }
        Logger::addToLog('');
        
        Logger::addToLog("RESPONSE HEADERS OF {$request_url}:");
        $lines = explode("\n", $this->_response_headers);
        foreach ($lines as $line)
        {
            Logger::addToLog(trim($line));
        }
        Logger::addToLog('');
        
        Logger::addToLog("RESPONSE BODY OF {$request_url} - {$http_code}: {$response_body}");
        //Logger::addToLog($response);
        Logger::addToLog('');
        
        Logger::flush();
        
        if ($errno != 0) {
            throw new \Exception("Http Request Wrong: {$errno} - {$errmsg}");
        }
        
        $response = array(
            //'errno' => $errno,
            //'errmsg' => $errmsg,
            'http_code' => $http_code,
            'response_headers' => empty($this->_response_headers) ? $this->_response_headers : str_replace("\r\n", "\n", $this->_response_headers),
            'response_body' => $response_body,
        );
        
        return $response;
    }
}