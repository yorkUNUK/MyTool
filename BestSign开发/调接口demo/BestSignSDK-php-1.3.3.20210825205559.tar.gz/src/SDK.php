<?php
namespace BestSignSDK;

require(__DIR__ . '/init.php');

class SDK
{
    private $_mid = '';
	private $_access_key = '';
    private $_pem = '';
	private $_pem_string = '';
    private $_host = '';
	private $_http_utils = null;
	
    private static $instance;
    
	private $_access_token = '';
	
    /** 
     * 初始化
     * @param string $mid 开发者编号 (clientId)
     * @param string $accessKey (clientSecret)
     * @param string $pem rsa证书文件或证书内容
     * @param string $host 服务器地址
     * @param string $pem_type 证书类型. 一般保持为空
     * @return
     */
    public static function getInstance($mid, $access_key, $pem, $host = Constants::DEFAULT_HOST, $pem_type = '')
    {
        $key = "{$mid}::{$access_key}::{$pem}::{$host}::{$pem_type}";
        if (isset(self::$instance[$key]))
        {
            return self::$instance[$key];
        }
        $class = __CLASS__;
        self::$instance[$key] = new $class($mid, $access_key, $pem, $host, $pem_type);
        return self::$instance[$key];    
    }
    
    private function __construct($mid, $access_key, $pem, $host, $pem_type)
    {
        $this->_pem = $this->_formatPem($pem, $pem_type);
		$this->_pem_string = $pem;
        $this->_mid = $mid;
		$this->_access_key = $access_key;
        $this->_host = $host;
		$this->_http_utils = HttpUtils::create();
		$this->_http_utils->setDefaultUserAgent(Constants::APP_NAME . "/" . Constants::VERSION);
    }
	
	function __destruct()
	{
		Logger::flush();
	}
	
	public function getMid()
	{
		return $this->_mid;
	}
	
	public function getHost()
	{
		return $this->_host;
	}
    
    /**
     * 设置日志目录
     * @param $path
     */
    public function setLogDir($path)
    {
        Logger::setLogDir($path);
    }
    
    /**
     * 设置调试等级
     * @param $debugLevel
     */
    public function setDebugLevel($debugLevel)
    {
        Logger::setDebugLevel($debugLevel);
    }
	
	
	/**
     * getAccessToken
     * @return
     */
	public function getAccessToken()
    {
        if (!empty($this->_access_token))
		{
			return $this->_access_token;
		}
		$response = $this->oa2ClientCredentialsToken();
		$this->_check_response_code($response);
		if (!isset($response['response_json']['data']['accessToken']))
		{
			throw new \Exception("no 'accessToken' field in response.response_json.data", -1);
		}
		$this->_access_token = $response['response_json']['data']['accessToken'];
        return $this->_access_token;
    }
	
    /**
     * 获取签名串
     * @param $request_time
     * @param $request_uri
     * @param $request_body_md5
     * @return
     */
	public function getRsaSign($request_time, $request_uri, $request_body_md5)
    {
		$pkeyid = openssl_pkey_get_private($this->_pem);
		
        if (!$pkeyid)
        {
            throw new \Exception("openssl_pkey_get_private wrong!", -1);
        }
		
		$sign_data  = "bestsign-client-id=". $this->_mid;
		$sign_data .= "bestsign-sign-timestamp={$request_time}";
		$sign_data .= "bestsign-signature-type=RSA256";
		$sign_data .= "request-body={$request_body_md5}";
		$sign_data .= "uri={$request_uri}";
		
		openssl_sign($sign_data, $sign, $this->_pem, OPENSSL_ALGO_SHA256);
		//openssl_sign($sign_data, $sign, $this->_pem);
        openssl_free_key($pkeyid);
        return base64_encode($sign);
    }
	
    //********************************************************************************
    // 接口
    //********************************************************************************
	/**
     * contractsAppendixFile
     * 
     * @param $contractId
     * @param $account
     * @param $enterpriseName
     * @return
     */
	public function contractsAppendixFile($contractId, $account, $enterpriseName)
	{
		$request_method = 'GET';
		$request_path = '/api/contracts/' . rawurlencode($contractId) . '/appendix-file';
		$request_uri = $request_path . '?account=' . rawurlencode($account) . '&enterpriseName=' . rawurlencode($enterpriseName);
		$request_body = '';
		
		$header_data = array();
		
		$response = $this->get_api_raw_response($request_method, $request_uri, $request_body, $header_data, true, true);
		return $response['response_body'];
	}
	
	/**
     * contractsDetail
     * 
     * @param $contractId
     * @return
     */
	public function contractsDetail($contractId)
	{
		$request_method = 'GET';
		$request_path = '/api/contracts/detail/' . rawurlencode($contractId);
		$request_uri = $request_path;
		$request_body = '';
		
		$header_data = array();
		
		$response = $this->get_api_response_data($request_method, $request_uri, $request_body, $header_data, true, true);
		return $response;
	}
	
	/**
     * contractsDownloadFile
     * 
     * @param $contractIds
     * @param $operator
     * @return
     */
	public function contractsDownloadFile(array $contractIds, $operator)
	{
		$request_method = 'POST';
		$request_path = '/api/contracts/download-file';
		$request_uri = $request_path;
		
		$post_data = array();
		$post_data['contractIds'] = $contractIds;
		$post_data['operator'] = $operator;
		$request_body = @json_encode($post_data);
		
		$header_data = array();
		
		$response = $this->get_api_raw_response($request_method, $request_uri, $request_body, $header_data, true, true);
		return $response['response_body'];
	}
	
	/**
     * contractsRemind
     * 
     * @param $contractId
     * @return
     */
	public function contractsRemind($contractId)
	{
		$request_method = 'POST';
		$request_path = '/api/contracts/remind';
		$request_uri = $request_path;
		
		$post_data = array();
		$post_data['contractId'] = $contractId;
		$request_body = @json_encode($post_data);
		
		$header_data = array();
		
		$response = $this->get_api_response_data($request_method, $request_uri, $request_body, $header_data, true, true);
		return $response;
	}
	
	/**
     * contractsSign
     * 
     * @param $contractIds
     * @param $signer
     * @param $sealName
     * @return
     */
	public function contractsSign(array $contractIds, $signer, $sealName)
	{
		$request_method = 'POST';
		$request_path = '/api/contracts/sign';
		$request_uri = $request_path;
		
		$post_data = array();
		$post_data['contractIds'] = $contractIds;
		$post_data['signer'] = $signer;
		$post_data['sealName'] = $sealName;
		$request_body = @json_encode($post_data);
		
		$header_data = array();
		
		$response = $this->get_api_response_data($request_method, $request_uri, $request_body, $header_data, true, true);
		return $response;
	}
	
	/**
     * entsBoxGetArchiveInfo
     * 
     * @param $archiveId
     * @return
     */
	public function entsBoxGetArchiveInfo($archiveId)
	{
		$request_method = 'POST';
		$request_path = '/api/ents/box/get-archive-info';
		$request_uri = $request_path;
		
		$post_data = array();
		$post_data['archiveId'] = $archiveId;
		$request_body = @json_encode($post_data);
		
		$header_data = array();
		
		$response = $this->get_api_response_data($request_method, $request_uri, $request_body, $header_data, true, true);
		return $response;
	}
	
	/**
     * entsBoxRequestAuthorizationCollection
     * 
     * @param $archiveId
     * @param $authorizeEntList
     * @return
     */
	public function entsBoxRequestAuthorizationCollection($archiveId, array $authorizeEntList)
	{
		$request_method = 'POST';
		$request_path = '/api/ents/box/request-authorization-collection';
		$request_uri = $request_path;
		
		$post_data = array();
		$post_data['archiveId'] = $archiveId;
		$post_data['authorizeEntList'] = $authorizeEntList;
		$request_body = @json_encode($post_data);
		
		$header_data = array();
		
		$response = $this->get_api_response_data($request_method, $request_uri, $request_body, $header_data, true, true);
		return $response;
	}
	
	/**
     * entsBoxEntProxyCollection
     *
     * @param $account
     * @param $archiveId
     * @param $entName
     * @param $collections
     * @return
     */
	public function entsBoxEntProxyCollection($account, $archiveId, $entName, array $collections)
	{
		$request_method = 'POST';
		$request_path = '/api/ents/box/ent-proxy-collection';
		$request_uri = $request_path;
		
		$post_data = array();
		$post_data['account'] = $account;
		$post_data['archiveId'] = $archiveId;
		$post_data['entName'] = $entName;
		$post_data['collections'] = $collections;
		$request_body = @json_encode($post_data);
		
		$header_data = array();
		
		$response = $this->get_api_response_data($request_method, $request_uri, $request_body, $header_data, true, true);
		return $response;
	}
	
	/**
     * entsBoxGetEntCollectionList
     *
     * @param $archiveId
     * @param $collectionStatus
     * @param $verifyStatus
     * @param $resourceAuthorizationStatus
     * @return
     */
	public function entsBoxGetEntCollectionList($archiveId, $collectionStatus, $verifyStatus, $resourceAuthorizationStatus)
	{
		$request_method = 'POST';
		$request_path = '/api/ents/box/get-ent-collection-list';
		$request_uri = $request_path;
		
		$post_data = array();
		$post_data['archiveId'] = $archiveId;
		$post_data['collectionStatus'] = $collectionStatus;
		$post_data['verifyStatus'] = $verifyStatus;
		$post_data['resourceAuthorizationStatus'] = $resourceAuthorizationStatus;
		$request_body = @json_encode($post_data);
		
		$header_data = array();
		
		$response = $this->get_api_response_data($request_method, $request_uri, $request_body, $header_data, true, true);
		return $response;
	}
	
	/**
     * entsBoxGetEntAuthorizationInfo
     *
     * @param $archiveId
     * @param $entName
     * @param $requires
     * @return
     */
	public function entsBoxGetEntAuthorizationInfo($archiveId, $entName, array $requires = array())
	{
		$request_method = 'POST';
		$request_path = '/api/ents/box/get-ent-authorization-info';
		$request_uri = $request_path;
		
		$post_data = array();
		$post_data['archiveId'] = $archiveId;
		$post_data['entName'] = $entName;
		$post_data['requires'] = $requires;
		$request_body = @json_encode($post_data);
		
		$header_data = array();
		
		$response = $this->get_api_response_data($request_method, $request_uri, $request_body, $header_data, true, true);
		return $response;
	}
	
	/**
     * oa2ClientCredentialsToken
     *
     * @return
     */
	public function oa2ClientCredentialsToken()
    {
		$request_method = 'POST';
		$request_path = '/api/oa2/client-credentials/token';
		$request_uri = $request_path;
		
		$post_data = array();
		$post_data['clientId'] = $this->_mid;
		$post_data['clientSecret'] = $this->_access_key;
		$request_body = @json_encode($post_data);
		
        $header_data = array();
		
		$response = $this->get_api_response_data($request_method, $request_uri, $request_body, $header_data, false, true);
		return $response;
    }
	
	/**
     * templatesOverview
     * 
     * @param $queryType
     * @param $id
     * @return
     */
	public function templatesOverview($id, $queryType)
	{
		$request_method = 'GET';
		$request_path = '/api/templates/overview';
		$request_uri = $request_path . '?queryType=' . rawurlencode($queryType) . '&id=' . rawurlencode($id);
		$request_body = '';
		
		$header_data = array();
	
		$response = $this->get_api_response_data($request_method, $request_uri, $request_body, $header_data, true, true);
		return $response;
	}
	
	/**
     * templatesSendContractsSyncV2
     * 
     * @param $templateId
     * @param $contractName
     * @param $sender
     * @param $roles
     * @param $textLabels
     * @param $documents
     * @param $documentFederationId
     * @param $signOrderly
     * @return
     */
	public function templatesSendContractsSyncV2($templateId, $contractName, $sender, array $roles, array $textLabels, array $documents, $documentFederationId = '', $signOrderly = true, array $imageLabels = array())
	{
		$request_method = 'POST';
		$request_path = '/api/templates/send-contracts-sync-v2';
		$request_uri = $request_path;
		
		$post_data = array();
		$post_data['templateId'] = $templateId;
		$post_data['contractName'] = $contractName;
		$post_data['sender'] = $sender;
		$post_data['roles'] = $roles;
		$post_data['textLabels'] = $textLabels;
		$post_data['documents'] = $documents;
		$post_data['documentFederationId'] = $documentFederationId;
		$post_data['signOrderly'] = $signOrderly;
		$post_data['imageLabels'] = $imageLabels;
		$request_body = @json_encode($post_data);
		
        $header_data = array();
		
		$response = $this->get_api_response_data($request_method, $request_uri, $request_body, $header_data, true, true);
		return $response;
	}
	
	/**
     * usersBindingExistence
     * 
     * @param $devAccountId
     * @return
     */
	public function usersBindingExistence($devAccountId)
	{
		$request_method = 'POST';
		$request_path = '/api/users/binding-existence';
		$request_uri = $request_path;
		
		$post_data = array();
		$post_data['devAccountId'] = $devAccountId;
		$request_body = @json_encode($post_data);
	
		$header_data = array();
		
		$response = $this->get_api_response_data($request_method, $request_uri, $request_body, $header_data, true, true);
		return $response;
	}
	
	
	//********************************************************************************
    // send request and get response
    //********************************************************************************
    public function get_api_response_data($request_method, $request_uri, $request_body, array $header_data = array(), $is_sign = true, $is_check_http_code = true)
	{
		$response = $this->get_api_response_json($request_method, $request_uri, $request_body, $header_data, $is_sign, $is_check_http_code);
		if (!isset($response['response_json']['data']))
		{
			$response['response_json']['data'] = null;
		}
		return $response;
	}
	
	public function get_api_response_json($request_method, $request_uri, $request_body, array $header_data = array(), $is_sign = true, $is_check_http_code = true)
	{
		$request_url = $this->_host . $request_uri;
		$request_body = is_null($request_body) ? '' : $request_body;
		
		if ($is_sign)
		{
			$request_body_md5 = md5($request_body);
			
			$request_time = time();
			$access_token = $this->getAccessToken();
			$sign = $this->getRsaSign($request_time, $request_uri, $request_body_md5);
			
			$header_data['bestsign-client-id'] = $this->_mid;
			$header_data['bestsign-sign-timestamp'] = $request_time;
			$header_data['bestsign-signature-type'] = 'RSA256';
			$header_data['bestsign-signature'] = rawurlencode($sign);
			$header_data['Authorization'] = "bearer " . $access_token;
		}
		
		$response = $this->get_response_json($request_method, $request_url, $request_body, $header_data);
		if ($is_check_http_code)
		{
			$this->_check_http_response_200($response);
		}
		//var_dump($response);
		if (!isset($response['response_json']))
		{
            throw new \Exception("get_api_response_json response format wrong: no 'response_json' field", -1);
        }
		
		return $response;
	}
	
	public function get_api_raw_response($request_method, $request_uri, $request_body, array $header_data = array(), $is_sign = true, $is_check_http_code = true)
	{
		$request_url = $this->_host . $request_uri;
		$request_body = is_null($request_body) ? '' : $request_body;
		
		if ($is_sign)
		{
			$request_body_md5 = md5($request_body);
			
			$request_time = time();
			$access_token = $this->getAccessToken();
			$sign = $this->getRsaSign($request_time, $request_uri, $request_body_md5);
			
			$header_data['bestsign-client-id'] = $this->_mid;
			$header_data['bestsign-sign-timestamp'] = $request_time;
			$header_data['bestsign-signature-type'] = 'RSA256';
			$header_data['bestsign-signature'] = rawurlencode($sign);
			$header_data['Authorization'] = "bearer " . $access_token;
		}
		
		$response = $this->get_raw_response($request_method, $request_url, $request_body, $header_data);
		if ($is_check_http_code)
		{
			$this->_check_http_response_200($response);
		}
		return $response;
	}
	
    public function get_response_json($request_method, $request_url, $request_data = null, array $header_data = array(), $auto_redirect = true, $cookie_file = null)
    {
        $response = $this->get_raw_response($request_method, $request_url, $request_data, $header_data, $auto_redirect, $cookie_file);
        $response_body = $response["response_body"];
		unset($response["response_body"]);
        $response_json = @json_decode($response_body, true);
        $response['response_json'] = $response_json;
        return $response;
    }
	
	public function get_raw_response($request_method, $request_url, $request_body = '', array $header_data = array(), $auto_redirect = true, $cookie_file = null)
    {	
        //headers
        $request_headers = array();
        $request_headers[] = 'Content-Type: application/json; charset=UTF-8';
        $request_headers[] = 'Cache-Control: no-cache';
        $request_headers[] = 'Pragma: no-cache';
        $request_headers[] = 'Connection: keep-alive';
		
		if (!empty($header_data))
		{
			foreach ($header_data as $name => $value)
			{
				$line = $name . ': ' . $value;
				$request_headers[] = $line;
			}
		}
        
        if (strcasecmp('POST', $request_method) == 0)
        {
            $response = $this->_http_utils->post($request_url, $request_body, null, $request_headers, $auto_redirect, $cookie_file);
        }
        else
        {   
			$response = $this->_http_utils->get($request_url, $request_headers, $auto_redirect, $cookie_file);
        }
        return $response;
    }
	
	private function _check_http_response_200(array $response)
	{
		if (!isset($response['http_code']))
		{
			throw new \Exception("wrong: no 'http_code' field", -1);
		}
		$http_code = $response['http_code'];
		if (!is_numeric($http_code))
		{
			throw new \Exception("wrong: bad 'http_code'", -1);
		}
		$http_code_num = intval($http_code);
		if (200 != $http_code_num)
		{
			throw new \Exception("wrong: 'http_code' is not 200", -1);
		}
	}
	
	public function _check_response_code(array $response)
	{
		$response_json = $response['response_json'];
		if (!isset($response_json['code']))
		{
			throw new \Exception("get_api_response_json response_json format wrong: no 'code' field", -1);
		}
		
		$code = $response_json['code'];
		$message = isset($response_json['message']) ? $response_json['message'] : '';
		
		if (is_numeric($code))
		{
			$code = intval($code);
		}
		else
		{
			$a = strrpos($code, '-');
			if ($a !== false)
			{	
				$code = substr($code, $a + 1);
			}
			
			if (!is_numeric($code))
			{
				throw new \Exception("get_api_response_json response_json format wrong: 'code' field is not a numeric", -1);
			}
			$code = intval($code);
		}
		
		if ($code != 0)
		{
			if (empty($message))
			{
				$message = "bad, the code is {$code}";
			}
			throw new \Exception($message, $code);
		}
	}
	
    private function _formatPem($rsa_pem, $pem_type = '')
    {
        //如果是文件, 返回内容
        if (is_file($rsa_pem))
        {
            return file_get_contents($rsa_pem);
        }
        
        //如果是完整的证书文件内容, 直接返回
        $rsa_pem = trim($rsa_pem);
        $lines = explode("\n", $rsa_pem);
        if (count($lines) > 1)
        {
            return $rsa_pem;
        }
        
        //只有证书内容, 需要格式化成证书格式
        $pem = '';
        for ($i = 0; $i < strlen($rsa_pem); $i++)
        {
            $ch = substr($rsa_pem, $i, 1);
            $pem .= $ch;
            if (($i + 1) % 64 == 0)
            {
                $pem .= "\n";
            }
        }
        $pem = trim($pem);
        if (0 == strcasecmp('RSA', $pem_type))
        {
            $pem = "-----BEGIN RSA PRIVATE KEY-----\n{$pem}\n-----END RSA PRIVATE KEY-----\n";
        }
        else
        {
            $pem = "-----BEGIN PRIVATE KEY-----\n{$pem}\n-----END PRIVATE KEY-----\n";
        }
        return $pem;
    }
	
	private function _getCookieFileName()
	{
		$tmpname = tempnam('/tmp/', 'bss_cookie_');
		@unlink($tmpname);
		return $tmpname;
	}
}