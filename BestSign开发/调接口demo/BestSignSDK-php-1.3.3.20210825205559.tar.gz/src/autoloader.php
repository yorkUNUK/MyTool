<?php
namespace BestSignSDK;

class AutoLoader
{
    public static $class_map = array(
//class_map
'BestSignSDK\Constants' => '/src/integration/Constants.php',
'BestSignSDK\Logger' => '/src/integration/Logger.php',
'BestSignSDK\HttpUtils' => '/src/integration/utils/HttpUtils.php',
'BestSignSDK\Utils' => '/src/integration/utils/Utils.php',
'BestSignSDK\AuthorizeEnt' => '/src/domain/vo/params/AuthorizeEnt.php',
'BestSignSDK\Collection' => '/src/domain/vo/params/Collection.php',
'BestSignSDK\ContractConfig' => '/src/domain/vo/params/ContractConfig.php',
'BestSignSDK\Document' => '/src/domain/vo/params/Document.php',
'BestSignSDK\ImageLabel' => '/src/domain/vo/params/ImageLabel.php',
'BestSignSDK\Operator' => '/src/domain/vo/params/Operator.php',
'BestSignSDK\Role' => '/src/domain/vo/params/Role.php',
'BestSignSDK\Sender' => '/src/domain/vo/params/Sender.php',
'BestSignSDK\Signer' => '/src/domain/vo/params/Signer.php',
'BestSignSDK\TextLabel' => '/src/domain/vo/params/TextLabel.php',
'BestSignSDK\UserInfo' => '/src/domain/vo/params/UserInfo.php',
//class_map
    );
    
    public static function registAutoload()
    {
        spl_autoload_register(__CLASS__ . '::autoload');
    }

    public static function autoload($class_name)
    {
        $root_dir = dirname(__DIR__);
        if (isset(self::$class_map[$class_name]))
        {
            $file = self::$class_map[$class_name];
            $filepath = $root_dir . '/' . $file;
            require($filepath);
            return;
        }
        /*
        if ('Buzz\\' == substr($class_name, 0, strlen('Buzz\\')))
        {
            $filepath = Constants::$API_DIR . 'libs/' . str_replace('\\', '/', $class_name) . '.php';
            require($filepath);
            //die($filepath);
        }
        else if ('Gitlab\\' == substr($class_name, 0, strlen('Gitlab\\')))
        {
            $filepath = Constants::$API_DIR . 'libs/' . str_replace('\\', '/', $class_name) . '.php';
            require($filepath);
            //die($filepath);
        }
        */
    }
}

