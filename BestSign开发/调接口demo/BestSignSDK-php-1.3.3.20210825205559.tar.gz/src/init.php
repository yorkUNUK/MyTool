<?php
namespace BestSignSDK;

require(__DIR__ . '/autoloader.php');
AutoLoader::registAutoload();

Constants::$ROOT_DIR = dirname(__DIR__) . '/';
