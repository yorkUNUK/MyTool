<?php
namespace BestSignSDK;

class Sender
{
    public static function buildData($account, $enterpriseName, $bizName = '')
    {
        $result = array();
		$result['account'] = $account;
		$result['enterpriseName'] = $enterpriseName;
		$result['bizName'] = $bizName;
        return $result;
    }
}