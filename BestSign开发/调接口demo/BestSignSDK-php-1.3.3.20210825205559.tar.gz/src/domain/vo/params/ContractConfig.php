<?php
namespace BestSignSDK;

class ContractConfig
{
    public static function buildData($contractTitle, $contractLifeEnd, $signExpireDays)
    {
        $result = array();
		$result['contractTitle'] = $contractTitle;
		$result['signExpireDays'] = $signExpireDays;
        $result['contractLifeEnd'] = $contractLifeEnd;
        return $result;
    }
}