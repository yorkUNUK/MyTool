<?php
namespace BestSignSDK;

class Collection
{
    public static function buildData($content, $proxyCollectionName)
    {
        $result = array();
		$result['content'] = $content;
		$result['proxyCollectionName'] = $proxyCollectionName;
        return $result;
    }
}