<?php
namespace BestSignSDK;

class Operator
{
    public static function buildData($account, $enterpriseName)
    {
        $result = array();
		$result['account'] = $account;
		$result['enterpriseName'] = $enterpriseName;
        return $result;
    }
}