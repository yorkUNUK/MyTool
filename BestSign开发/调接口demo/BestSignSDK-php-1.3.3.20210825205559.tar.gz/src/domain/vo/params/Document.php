<?php
namespace BestSignSDK;

class Document
{
    public static function buildData($documentId, array $contractConfig)
    {
        $result = array();
		$result['documentId'] = $documentId;
		$result['contractConfig'] = $contractConfig;
        return $result;
    }
	
	public static function buildData2($documentId, $fileName, $content)
    {
        $result = array();
		$result['documentId'] = $documentId;
		$result['content'] = $content;
		$result['fileName'] = $fileName;
        return $result;
    }
}