<?php
namespace BestSignSDK;

class Role
{
    public static function buildData($roleId, array $userInfo)
    {
        $result = array();
		$result['roleId'] = $roleId;
		$result['userInfo'] = $userInfo;
        return $result;
    }
}