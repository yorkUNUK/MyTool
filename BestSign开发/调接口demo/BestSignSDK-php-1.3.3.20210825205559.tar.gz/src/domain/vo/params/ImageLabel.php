<?php
namespace BestSignSDK;

class ImageLabel
{
    public static function buildData($name, $value, $fileName = '')
    {
        $result = array();
		$result['name'] = $name;
		$result['value'] = $value;
		$result['fileName'] = $fileName;
        return $result;
    }
}