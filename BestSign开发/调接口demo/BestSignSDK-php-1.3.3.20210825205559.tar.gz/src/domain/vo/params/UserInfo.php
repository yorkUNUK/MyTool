<?php
namespace BestSignSDK;

class UserInfo
{
    public static function buildData($userAccount, $enterpriseName)
    {
        $result = array();
		$result['enterpriseName'] = $enterpriseName;
		$result['userAccount'] = $userAccount;
        return $result;
    }
}