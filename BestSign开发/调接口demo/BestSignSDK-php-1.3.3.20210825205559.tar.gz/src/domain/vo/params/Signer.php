<?php
namespace BestSignSDK;

class Signer
{
    public static function buildData($account, $enterpriseName)
    {
        $result = array();
		$result['account'] = $account;
		$result['enterpriseName'] = $enterpriseName;
        return $result;
    }
}