<?php
namespace BestSignSDK;

class AuthorizeEnt
{
    public static function buildData($notification, $enterpriseName)
    {
        $result = array();
		$result['notification'] = $notification;
		$result['enterpriseName'] = $enterpriseName;
        return $result;
    }
}