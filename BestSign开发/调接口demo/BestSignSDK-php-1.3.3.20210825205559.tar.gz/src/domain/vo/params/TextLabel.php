<?php
namespace BestSignSDK;

class TextLabel
{
    public static function buildData($name, $value)
    {
        $result = array();
		$result['name'] = $name;
		$result['value'] = $value;
        return $result;
    }
}