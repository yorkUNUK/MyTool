package cn.bestsign.ultimate.delta.api.test;

import cn.bestsign.ultimate.delta.api.client.BestSignClient;

/**
 * @author whthomas
 * @date 2018/6/27
 */
public class BestSignClientTest {

    protected final BestSignClient bestSignClient;

    public BestSignClientTest() {

        String privateKey = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAIwgWQHTL0gtd1tna6Ul3BehmN5ttJhn99GQR4J6qkboTpeoBPDJdQUGj9z8FFmVxMTtdUdf40Qc6ZzXdNL0nkgGNzWWCQLeDboNgP4In7kqvjDfZXia996TTKmd2zHIAnH952divQ/PQSghzvLZF9Xy64Gh0KBSAJOpBrxtw2utAgMBAAECgYBAQuluu9HYMPmm0mP8ZcNslvBLOVZz+mIdGiShQu3p/MlmJWi2oDzpJBw/xN70QontodSB+gh4iSXdhrWNtR8MzITVweJG8ZKmdr90IcyKIskHq5izrQHo3BoTiHCA1hSHu5u6u4eRLIK504+MJ4p3l6g+4qMoca3yCJCfaul2QQJBAMzO/sGW2P6qHG4zTonEgKqGn+mHhfonu2cDCL8FrkJbPbXNY9q+HHHWvIj9VZJErT+rIT9Yk0fqRojerbAuYZECQQCvJo6oj/fxaoPGsKmVA4KToKU8Wz/lFgjwNnMZsO+zXVcVd+bVNNpw/7C/9oqFF7MuISMtZQnoASDwmuBmTVpdAkBaq9FRN00+AWWwy/obN+mWlR86rgr8Ypau1kMK/qLVMbuyPwnUD5JcO6sgIre9l7Xzl/mSJ86cafVsJtlSRFZhAkEAhjZqfJoNaW2wWpFG8UvGRC+GTnCxzm6LHN7sZhRiKTRuJaJCPMAKXypfG0nlLUVS5Rc5aHCTHbe3sQdMyreddQJAQWhBWmhSFMtipKttcHKB1CHRidAPzysCUHLKLq25adwgXjUZSGrGPk9tPQ5KhcvpWMXEBmED1gOm1IUPxjLzbg==";
        bestSignClient = new BestSignClient(
                "https://api.bestsign.info",
                "1588734760017281787",
                "cXyrvcYRlbxqgJQcxLmge6FpiDUF8HSx",
                privateKey
        );

    }
}
