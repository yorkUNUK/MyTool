package cn.bestsign.ultimate.delta.api.test;

import cn.bestsign.ultimate.delta.api.client.BestSignClient;
import cn.bestsign.ultimate.delta.api.domain.contract.create.*;
import cn.bestsign.ultimate.delta.api.domain.contract.newCreate.document.AppendingSignLabels;
import cn.bestsign.ultimate.delta.api.domain.contract.newCreate.document.ContractConfig;
import cn.bestsign.ultimate.delta.api.domain.contract.newCreate.NewRolesVO;
import cn.bestsign.ultimate.delta.api.domain.contract.newCreate.role.NoticeConfigVO;
import cn.bestsign.ultimate.delta.api.domain.contract.newCreate.role.UserInfoVO;
import cn.bestsign.ultimate.delta.api.domain.contract.sign.SignContractVO;
import cn.bestsign.ultimate.delta.api.domain.contract.sign.SignerVO;
import cn.bestsign.ultimate.delta.api.domain.contract.download.DownloadVO;
import cn.bestsign.ultimate.delta.api.domain.contract.newCreate.*;
import cn.bestsign.ultimate.delta.api.domain.notarization.NotarizationVO;
import cn.bestsign.ultimate.delta.api.domain.contract.revoke.RevokeVO;
import org.junit.Test;
import com.alibaba.fastjson.JSONObject;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.net.URLDecoder;
import java.net.URLEncoder;


public class ContractApiTest {
    final String privateKey = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAKxU/jmowdXypsKW991/g20t5MhQY2lyQkS7Q6jc4QrxPIazGAkubE+fxE852ljKRom/JEsYVUZ4SJeqimVp5U1prlXtrejxkpSA3FZ198ow8b++WV2OazFZmwwJxfdx3znoCM1ZliPauRITfYhDByOZ6VXAntMQcVeIuwSF8rWNAgMBAAECgYA4zEp99oDsYu1TdS58cmp+sYGWA+i/+EifHplOLn59fMTWIHDrlcFc/OtWsVqlqQVWoQj1Ny/j6gEC+9JhWmWYcpXxSg/YwcJQfQ79NHgPIOMtT/cVQ//Vih9qn0y3dQJEt282ttKA3HhHoYfZ8clN2w2yzefZp+5FJHpwxMmSgQJBAO3WcugeTz0cqx8pPbLK45lUtkmJZSyGSGz/edh1+1LrkHKNo+MaXM0h2UdvGPlPTc/6KjBV71tcFqByku3Z6gMCQQC5ffTYy31uWyWw+JG0gvMw/xjHcFW9C6u+2ST7LlcfZ8omW+Uf5zTcXkjMoaQUlVOmt0E7xfSWROKg/LglP5UvAkAHDDG/exZyAyV2+OvhHm38Hyx/pVigJyKCSFe9+FEINf7DxjqzAhb55SThHwOob5cosIsLf6BmHqZ0/rAn6CstAkBhA0Nfb232na0k1Zw+8I4IfiKTjGkLKmN0uVTiGeZvAnVzgnRfLykyaA1jGNcb/M13UDjJ7kpxnS16TTJyKML5AkEAoJ0AkfoFzzWDnVAb3922pvr2DQaqB87XUfiNKoV+FIGdXYnMHjKMMFNV84m+UMj7s2lKB2wS7id4HxqAVTFl6Q==";
    private final BestSignClient bestSignClient = new BestSignClient(
//            "https://api.bestsign.info",
            "https://api.bestsign.info",
            "1626074470012587260",
            "be6cc5dc30234774b21f8ed12d831b3d",
            privateKey
    );

    @Test
    public void testCreateContract() throws IOException {

        CreateContractVO createContractVO = new CreateContractVO();
        createContractVO.setContractDescription("测试api合同1");
        createContractVO.setContractTitle("测试api合同2");
        createContractVO.setSignDeadline(new Date(System.currentTimeMillis()+ 86400000));
        createContractVO.setSignOrdered(false);
        List<CreateDocumentVO> documents = new ArrayList<>();
        CreateDocumentVO documentVO = new CreateDocumentVO();
        documentVO.setFileName("Test.pdf");
        documentVO.setContent(getFileBase64Content("/Users/york/Downloads/DingGou.pdf"));
        documents.add(documentVO);
        documentVO.setOrder(0);
        createContractVO.setDocuments(documents);

        CreateReceiverVO receiverVO= new CreateReceiverVO();
        receiverVO.setUserAccount("15867397177");
        receiverVO.setUserName("徐宇超");
        receiverVO.setRequireIdentityAssurance(false);
        receiverVO.setForceHandWrite(true);
        receiverVO.setPrivateLetter("");
        receiverVO.setUserType(SignFlowConstants.UserType.PERSON);
        receiverVO.setReceiverType(SignFlowConstants.ReceiverType.SIGNER);
        List<CreateLabel> receiverLabels = new ArrayList<>();
        receiverLabels.add(getLable(SignFlowConstants.SignLabelType.SIGNATURE,0));
        receiverLabels.add(getLable(SignFlowConstants.SignLabelType.DATE,50));
        receiverVO.setLabels(receiverLabels);
        receiverVO.setNotification("");


        CreateReceiverVO sender = new CreateReceiverVO();
        sender.setUserAccount("19957257579");
        sender.setUserName("lxq");
        sender.setEnterpriseName("极氪汽车测试有限公司");
        sender.setUserType(SignFlowConstants.UserType.ENTERPRISE);
        sender.setSignSealFileName("");
        sender.setReceiverType(SignFlowConstants.ReceiverType.SIGNER);
        sender.setSignImmediately(true);
        List<CreateLabel> senderLabels = new ArrayList<>();
        senderLabels.add(getLable(SignFlowConstants.SignLabelType.SEAL,100));
        senderLabels.add(getLable(SignFlowConstants.SignLabelType.DATE,150));
        sender.setLabels(senderLabels);

        List<CreateReceiverVO> receivers = new ArrayList<>();
        receivers.add(receiverVO);
        receivers.add(sender);
        createContractVO.setReceivers(receivers);

        String string = bestSignClient.executeRequest("/api/contracts/","POST",createContractVO);

        System.out.println(string);
    }

    private CreateLabel getLable(SignFlowConstants.SignLabelType labelType, float shift){
        CreateLabel slabelVO1 = new CreateLabel();
        slabelVO1.setDocumentOrder(0);
        slabelVO1.setHeight(50f);
        slabelVO1.setWidth(50f);
        slabelVO1.setPageNumber(1);
        slabelVO1.setX(200f+shift);
        slabelVO1.setY(200f+shift);
        slabelVO1.setType(labelType);
        return slabelVO1;
    }

    private String getFileBase64Content(String filePath) throws IOException {
        FileInputStream fileInputStream = new FileInputStream(filePath);
        byte[] bytes = new byte[fileInputStream.available()];
        fileInputStream.read(bytes);
        return Base64.getEncoder().encodeToString(bytes);
    }

    @Test
    public void testSignContract(){
        SignContractVO signContractVO = new SignContractVO();
        SignerVO signer = new SignerVO();

        List<Long> contractIds = Arrays.asList(2941416050144575490L);
        signContractVO.setContractIds(contractIds);

        String account = "15867397177";
        String enterpriseName = "徐宇超市场经营管理有限公司";
        String bizName = "主线";
        signer.setAccount(account);
        signer.setEnterpriseName(enterpriseName);
        signer.setBizName(bizName);
        signContractVO.setContractIds(contractIds);
        signContractVO.setSigner(signer);
        String string = bestSignClient.executeRequest("/api/contracts/sign","POST",signContractVO);

        System.out.println(string);
    }


    /**
     * 合同下载接口，返回的是zip
     * @throws IOException
     */
    @Test
    public void contractsDownload() throws IOException {

        DownloadVO downloadVO = new DownloadVO();
        List<String> contractIds = Arrays.asList("2941237924588660730");
        Boolean encodeByBase64 = false;
        String fileType = "pdf";
        downloadVO.setContractIds(contractIds);
        downloadVO.setEncodeByBase64(encodeByBase64);
        downloadVO.setFileType(fileType);

        String base64 = bestSignClient.executeRequest("/api/contracts/download-file", "POST", downloadVO);
        try{
            byte[] bytes = Base64.getDecoder().decode(base64);
            Files.write(Paths.get("/Users/edianyun/Downloads/1124.pdf"),bytes);
        }catch (Exception e){
            System.out.println(base64);
            System.out.println(e);
        }
        /**  JSONObejct
         *String jsonStr = "{'contractIds':['2916022281350390787']}";
         *JSONObject jsonObject = JSONObject.parseObject(jsonStr);
         *String base64 = bestSignClient.executeRequest("/api/contracts/download-file", "POST", jsonObject);
         *byte[] bytes = Base64.getDecoder().decode(base64);
         *Files.write(Paths.get("/Users/edianyun/Downloads/1124.pdf"),bytes);
         */
    }

    /**
     * 合同附页下载接口，返回的是文件流
     * @throws IOException
     */
    @Test
    public void contractsFileDownload() throws IOException {
        String contractId = "2916022281350390787";
        String base64 = bestSignClient.executeRequest("/api/contracts/"+contractId+"/appendix-file", "GET", "");
        byte[] bytes = Base64.getDecoder().decode(base64);
        Files.write(Paths.get("/Users/edianyun/Downloads/1123.pdf"),bytes);
    }

    @Test
    public void testNewCreateContract() throws IOException {

        NewCreateContractVO newCreateContractVO = new NewCreateContractVO();
        newCreateContractVO.setTemplateId("2902275519070340097");
        newCreateContractVO.setContractName("测试新发送合同demo");
        newCreateContractVO.setSignOrderly(false);
        NewSenderVO sender = new NewSenderVO();
        String account = "15867397177";
        String enterpriseName = "徐宇超市场经营管理有限公司";
        String bizName = "主线";
        sender.setAccount(account);
        sender.setEnterpriseName(enterpriseName);
        sender.setBizName(bizName);
        newCreateContractVO.setSender(sender);

        /*
        设置签署人
         */
        List<NewRolesVO> roles = new ArrayList<>();
        // 1
        NewRolesVO role_1 = new NewRolesVO();
        role_1.setRoleId("2902275948424463362");
        role_1.setUserType("ENTERPRISE");
        role_1.setReceiverType("SIGNER");
        role_1.setRoleName("企业");
        UserInfoVO userInfoVO_1 = new UserInfoVO();
        userInfoVO_1.setUserAccount("15867397177");
        userInfoVO_1.setEnterpriseName("徐宇超市场经营管理有限公司");
        role_1.setUserInfo(userInfoVO_1);
        NoticeConfigVO noticeConfigVO = new NoticeConfigVO();
        noticeConfigVO.setNoticeInEnglish(true);
        role_1.setNoticeConfig(noticeConfigVO);
        // 2
        NewRolesVO role_2 = new NewRolesVO();
        role_2.setUserType("PERSON");
        role_2.setReceiverType("SIGNER");
        role_2.setRoleName("个人");
        UserInfoVO userInfoVO_2 = new UserInfoVO();
        userInfoVO_2.setUserAccount("15867397177");
        userInfoVO_2.setUserName("徐宇超");
        role_2.setUserInfo(userInfoVO_2);
        //
        roles.add(role_1);
        roles.add(role_2);
        newCreateContractVO.setRoles(roles);

        /*
        设置文档
         */
        List<NewDocumentsVO> documents = new ArrayList<>();
        NewDocumentsVO document = new NewDocumentsVO();
        document.setDocumentId("2902276315971322882");
        ContractConfig contractConfig = new ContractConfig();
        contractConfig.setContractTitle("合同title");
        contractConfig.setSignExpireDays(35);
        document.setContractConfig(contractConfig);
        List<AppendingSignLabels> appendingSignLabels = new ArrayList<>();
        AppendingSignLabels appendingSignLabel_1 = new AppendingSignLabels();
        appendingSignLabel_1.setX(0.1);
        appendingSignLabel_1.setY(0.1);
        appendingSignLabel_1.setRoleName("企业");
        appendingSignLabel_1.setType("SEAL");
        appendingSignLabel_1.setPageNumber(1);
        AppendingSignLabels appendingSignLabel_2 = new AppendingSignLabels();
        appendingSignLabel_2.setX(0.9);
        appendingSignLabel_2.setY(0.9);
        appendingSignLabel_2.setRoleName("个人");
        appendingSignLabel_2.setType("SIGNATURE");
        appendingSignLabel_2.setPageNumber(1);
        appendingSignLabels.add(appendingSignLabel_1);
        appendingSignLabels.add(appendingSignLabel_2);
        document.setAppendingSignLabels(appendingSignLabels);
        documents.add(document);
        newCreateContractVO.setDocuments(documents);

        /*
        设置字段
         */
        List<NewTextLabelVO> textLabels = new ArrayList<>();
        NewTextLabelVO textLabel = new NewTextLabelVO();
        textLabel.setName("工资数目");
        textLabel.setValue("2500");
        textLabels.add(textLabel);
        newCreateContractVO.setTextLabels(textLabels);

        String string = bestSignClient.executeRequest("/api/templates/send-contracts-sync-v2","POST",newCreateContractVO);

        System.out.println(string);
    }

    /**
     * 获取公证存证文档
     * @throws IOException
     */
    @Test
    public void notarizationDownload() throws IOException {
        NotarizationVO notarizationVO = new NotarizationVO();
        String account = "15867397177";
        String entName = "徐宇超市场经营管理有限公司";
        Integer fileType = 4;
        Long contractId = 2917359567233065984L;
        notarizationVO.setAccount(account);
        notarizationVO.setEntName(entName);
        notarizationVO.setFileType(fileType);
        notarizationVO.setContractId(contractId);
        String base64 = bestSignClient.executeRequest("/api/contracts/download/notarization", "POST", notarizationVO);
        byte[] bytes = Base64.getDecoder().decode(base64);
        Files.write(Paths.get("/Users/edianyun/Downloads/存证.zip"),bytes);
    }

    /**
     * 撤销合同
     * @throws IOException
     */
    @Test
    public void contractRevoke() throws IOException {
        RevokeVO revokeVO = new RevokeVO();
        String contractId = "2937544241171376134";
        String uriWithParam = String.format("/api/contracts/%s/revoke", contractId);
        String result = bestSignClient.executeRequest(uriWithParam, "POST", revokeVO);
    }

    /**
     * 查询模板列表
     * @throws IOException
     */
    @Test
    public void templateList() throws IOException {
        String currentPage = "1";
        String pageSize = "20";
        String account = "15867397177";
        String enterpriseName = "徐宇超市场经营管理有限公司";
        String bizName = "主线";
        String result = bestSignClient.executeRequest("/api/templates/v2?currentPage="+currentPage+"&pageSize="+pageSize+"&account="+account+"&enterpriseName="+URLEncoder.encode(enterpriseName, "utf-8")+"&bizName="+URLEncoder.encode(bizName, "utf-8"), "GET", "");
        System.out.println(result);
    }
}
