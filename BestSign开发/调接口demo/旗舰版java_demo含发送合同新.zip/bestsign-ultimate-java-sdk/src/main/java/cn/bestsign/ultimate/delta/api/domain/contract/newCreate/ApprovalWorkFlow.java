package cn.bestsign.ultimate.delta.api.domain.contract.newCreate;

import java.util.List;

public class ApprovalWorkFlow {
    private String workflowName;
    private List<WorkFlowSteps> workFlowSteps;

    public String getWorkflowName() {
        return workflowName;
    }
    public void setWorkflowName(String workflowName) {
        this.workflowName = workflowName;
    }

    public List<WorkFlowSteps> getWorkFlowSteps() {
        return workFlowSteps;
    }
    public void setWorkFlowSteps(List<WorkFlowSteps> workFlowSteps) {
        this.workFlowSteps = workFlowSteps;
    }
}
