package cn.bestsign.ultimate.delta.api.domain.contract.newCreate.role;

public class NoticeConfigVO {
    private Boolean needNotice;
    private Boolean noticeInEnglish;

    public Boolean getNeedNotice() {
        return needNotice;
    }
    public void setNeedNotice(Boolean needNotice) {
        this.needNotice = needNotice;
    }

    public Boolean getNoticeInEnglish() {
        return noticeInEnglish;
    }
    public void setNoticeInEnglish(Boolean noticeInEnglish) {
        this.noticeInEnglish = noticeInEnglish;
    }
}
