package cn.bestsign.ultimate.delta.api.domain.contract.newCreate.document;

import java.util.List;

public class Attachments {
    private String fileName;
    private String content;
    private int order;
    private List<AppendingSignLabels> appendingSignLabels;

    public String getFileName() {
        return fileName;
    }
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }

    public int getOrder() {
        return order;
    }
    public void setOrder(int order) {
        this.order = order;
    }

    /*
    附件签署位置
     */
    public List<AppendingSignLabels> getAppendingSignLabels() {
        return appendingSignLabels;
    }
    public void setAppendingSignLabels(List<AppendingSignLabels> appendingSignLabels) {
        this.appendingSignLabels = appendingSignLabels;
    }
}
