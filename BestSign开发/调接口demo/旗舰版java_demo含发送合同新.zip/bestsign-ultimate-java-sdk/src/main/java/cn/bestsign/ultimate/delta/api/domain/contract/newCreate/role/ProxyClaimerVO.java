package cn.bestsign.ultimate.delta.api.domain.contract.newCreate.role;

import java.util.List;

public class ProxyClaimerVO {
    private Boolean ifProxyClaimer;
    private List<String> contractIds;

    public Boolean getIfProxyClaimer() {
        return ifProxyClaimer;
    }
    public void setIfProxyClaimer(Boolean ifProxyClaimer) {
        this.ifProxyClaimer = ifProxyClaimer;
    }

    public List<String> getContractIds() {
        return contractIds;
    }
    public void setContractIds(List<String> contractIds) {
        this.contractIds = contractIds;
    }
}
