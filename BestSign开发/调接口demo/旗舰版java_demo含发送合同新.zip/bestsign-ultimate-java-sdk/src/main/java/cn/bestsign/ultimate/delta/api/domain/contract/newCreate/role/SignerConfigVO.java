package cn.bestsign.ultimate.delta.api.domain.contract.newCreate.role;

public class SignerConfigVO {
    private Boolean forceHandWrite;
    private Boolean handWriteNotAllowed;
    private Boolean faceVerify;
    private Boolean faceFirst;
    private Boolean handWritingRecognition;
    private Boolean mustReadBeforeSign;

    public Boolean getForceHandWrite() {
        return forceHandWrite;
    }
    public void setForceHandWrite(Boolean forceHandWrite) {
        this.forceHandWrite = forceHandWrite;
    }

    public Boolean getHandWriteNotAllowed() {
        return handWriteNotAllowed;
    }
    public void setHandWriteNotAllowed(Boolean handWriteNotAllowed) {
        this.handWriteNotAllowed = handWriteNotAllowed;
    }

    public Boolean getFaceVerify() {
        return faceVerify;
    }
    public void setFaceVerify(Boolean faceVerify) {
        this.faceVerify = faceVerify;
    }

    public Boolean getFaceFirst() {
        return faceFirst;
    }
    public void setFaceFirst(Boolean faceFirst) {
        this.faceFirst = faceFirst;
    }

    public Boolean getHandWritingRecognition() {
        return handWritingRecognition;
    }
    public void setHandWritingRecognition(Boolean handWritingRecognition) {
        this.handWritingRecognition = handWritingRecognition;
    }

    public Boolean getMustReadBeforeSign() {
        return mustReadBeforeSign;
    }
    public void setMustReadBeforeSign(Boolean mustReadBeforeSign) {
        this.mustReadBeforeSign = mustReadBeforeSign;
    }

}
