package cn.bestsign.ultimate.delta.api.domain.contract.download;

import java.util.List;

public class DownloadVO {
    private List<String> contractIds;
    private Boolean encodeByBase64;
    private String fileType;

    public List<String> getContractIds() {
        return contractIds;
    }
    public Boolean getEncodeByBase64() { return encodeByBase64;}
    public String getFileType() {return fileType;}

    public void setContractIds(List<String> contractIds) {
        this.contractIds = contractIds;
    }
    public void setEncodeByBase64(Boolean encodeByBase64) {
        this.encodeByBase64 = encodeByBase64;
    }
    public void setFileType(String fileType) {this.fileType = fileType;}
}
