package cn.bestsign.ultimate.delta.api.domain.contract.newCreate;

import cn.bestsign.ultimate.delta.api.domain.contract.newCreate.document.AppendingSignLabels;
import cn.bestsign.ultimate.delta.api.domain.contract.newCreate.document.Attachments;
import cn.bestsign.ultimate.delta.api.domain.contract.newCreate.document.ContractConfig;
import cn.bestsign.ultimate.delta.api.domain.contract.newCreate.document.DescriptionFields;

import java.util.List;

public class NewDocumentsVO {
    private String documentId;
    private String content;
    private String fileName;
    ContractConfig contractConfig;
    private List<AppendingSignLabels> appendingSignLabels;
    private List<DescriptionFields> descriptionFields;
    private List<Attachments> attachments;

    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    /*
    子合同的系统默认字段
     */
    public ContractConfig getContractConfig() {
        return contractConfig;
    }

    public void setContractConfig(ContractConfig contractConfig) {
        this.contractConfig = contractConfig;
    }

    /*
    签署位置
     */
    public List<AppendingSignLabels> getAppendingSignLabels() {
        return appendingSignLabels;
    }

    public void setAppendingSignLabels(List<AppendingSignLabels> appendingSignLabels) {
        this.appendingSignLabels = appendingSignLabels;
    }

    /*
    子合同的自定义描述字段
     */
    public List<DescriptionFields> getDescriptionFields() {
        return descriptionFields;
    }

    public void setDescriptionFields(List<DescriptionFields> descriptionFields) {
        this.descriptionFields = descriptionFields;
    }

    /*
    合同附件
     */
    public List<Attachments> getAttachments() {
        return attachments;
    }

    public void setAttachments(List<Attachments> attachments) {
        this.attachments = attachments;
    }


}
