﻿using System;

using System.Text;

using JsonWebToken;
using System.Security.Cryptography;
using JWT.Builder;
using JWT;
using JWT.Serializers;
using JWT.Algorithms;
using JWT.Exceptions;

using System.Security.Cryptography.X509Certificates;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Security;


namespace BestSignDemo.src {
    class JwtTest {


        static string base64_fromjava(string pubkey) {
            byte[] by = Encoding.UTF8.GetBytes(pubkey);
            sbyte[] sby = new sbyte[by.Length];
            for (int i = 0; i < by.Length; i++) {
                if (by[i] > 127)
                    sby[i] = (sbyte)(by[i] - 256);
                else
                    sby[i] = (sbyte)by[i];
            }
            byte[] newby = (byte[])(object)sby;
            return Convert.ToBase64String(newby);
        }


        public static string RSAPublicKeyJava2DotNet(string publicKey) {
            RsaKeyParameters publicKeyParam = (RsaKeyParameters)PublicKeyFactory.CreateKey(Convert.FromBase64String(publicKey));
            return string.Format("<RSAKeyValue><Modulus>{0}</Modulus><Exponent>{1}</Exponent></RSAKeyValue>",
            Convert.ToBase64String(publicKeyParam.Modulus.ToByteArrayUnsigned()),
            Convert.ToBase64String(publicKeyParam.Exponent.ToByteArrayUnsigned()));
        }
 
        public static string RSAPrivateKeyJava2DotNet(string privateKey) {
            RsaPrivateCrtKeyParameters privateKeyParam = (RsaPrivateCrtKeyParameters)PrivateKeyFactory.CreateKey(Convert.FromBase64String(privateKey));

            return string.Format("<RSAKeyValue><Modulus>{0}</Modulus><Exponent>{1}</Exponent><P>{2}</P><Q>{3}</Q><DP>{4}</DP><DQ>{5}</DQ><InverseQ>{6}</InverseQ><D>{7}</D></RSAKeyValue>",
            Convert.ToBase64String(privateKeyParam.Modulus.ToByteArrayUnsigned()),
            Convert.ToBase64String(privateKeyParam.PublicExponent.ToByteArrayUnsigned()),
            Convert.ToBase64String(privateKeyParam.P.ToByteArrayUnsigned()),
            Convert.ToBase64String(privateKeyParam.Q.ToByteArrayUnsigned()),
            Convert.ToBase64String(privateKeyParam.DP.ToByteArrayUnsigned()),
            Convert.ToBase64String(privateKeyParam.DQ.ToByteArrayUnsigned()),
            Convert.ToBase64String(privateKeyParam.QInv.ToByteArrayUnsigned()),
            Convert.ToBase64String(privateKeyParam.Exponent.ToByteArrayUnsigned()));

        }
       
               public static string RSAEncrypts(string content) {

                   RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
                   byte[] cipherbytes;
                   X509Certificate2 x509Certificate2 = new X509Certificate2("D:\\Config\\dsptest.cer");
                   //创建并返回当前算法对象的xml字符串表示形式
                   string publicKeyString = x509Certificate2.PublicKey.Key.ToXmlString(false);
                   rsa.FromXmlString(publicKeyString);
                   //rsa.FromXmlString(RSAPublicKeyJava2DotNet(publicKeyString));
                   cipherbytes = rsa.Encrypt(Encoding.UTF8.GetBytes(content), false);
                   return Convert.ToBase64String(cipherbytes);
               }
               public static string RSADecrypt(string content) {
                   byte[] rgb = Convert.FromBase64String(content);
                   RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
                   byte[] cipherbytes;
                   X509Certificate2 x509Certificate2 = new X509Certificate2("D:\\Config\\test.pfx", "cfca1234", X509KeyStorageFlags.Exportable);
                   //创建并返回当前算法对象的xml字符串表示形式
                   //rsa.FromXmlString(RSAPrivateKeyJava2DotNet(Const.privatekey));

                   rsa.FromXmlString(x509Certificate2.PrivateKey.ToXmlString(true));
                   cipherbytes = rsa.Decrypt(Convert.FromBase64String(content), false);
                   return Encoding.UTF8.GetString(cipherbytes);
               } 

        static void Main(string[] args) {
            const string token2 = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJjbGFpbTEiOjAsImNsYWltMiI6ImNsYWltMi12YWx1ZSJ9.8pwBI_HtXqI3UgQHQ_rDRnSQRxFL1SR8fbQoS-5kM5s";
            const string secret = "GQDstcKsx0NHjPOuXOYg5MbeJ1XT0uFiwDVvVBrk";

            try {
                IJsonSerializer serializer = new JsonNetSerializer();
                var provider = new UtcDateTimeProvider();
                IJwtValidator validator = new JwtValidator(serializer, provider);
                IBase64UrlEncoder urlEncoder = new JwtBase64UrlEncoder();
                IJwtAlgorithm algorithm = new HMACSHA256Algorithm(); // symmetric
                IJwtDecoder decoder = new JwtDecoder(serializer, validator, urlEncoder, algorithm);

                var json21 = decoder.Decode(token2, secret, verify: true);
                Console.WriteLine(json21);
            } catch (TokenExpiredException) {
                Console.WriteLine("Token has expired");
            } catch (SignatureVerificationException) {
                Console.WriteLine("Token has invalid signature");
            }




            Console.WriteLine("===============================================================");
            string token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJiZXN0c2lnbiIsIm5hbWUiOiJKb2UiLCJmcm9tIjoiWkoiLCJpYXQiOjE2MDgwMTU3NjN9.B601zveZvRJXWXzTnIzPEmE7YDIxvn7R_genzTIoXPGoVno3TPoDlIiBWZPKddZCjKEAVCHSKaAjQAUoTcHkwZn0FZkU1EM8Xkp7ixdMIiD4Od6H8aWZnUmeObmimF9S_y-S8cqQ-1hl0MpdkidTt3MyLu36JeE40w3lbMfAsj8";

            string pubkey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCjXTUcGpQOwwRs7Lppk3w4K2DDTlFKROerKy6hJ+eskk5zL9bCLv3FocZ6tvgx0t5xpgbH8qrclhhtQaSdJ6Ze+8E3XHLIrCgLWjhzTavb0ykNyWrLkd2znAWDn0jy6oieYdqJLVR/h1Rv+bxPGaEI2Iaja8mBcgfgEoKQVDUB3wIDAQAB";
            var json = new JwtBuilder()
               .WithAlgorithm(new HMACSHA256Algorithm()) // symmetric HMACSHA256
               .WithSecret(pubkey)
               // .MustVerifySignature()
               .Decode(token);
            Console.WriteLine(json);

            string pubkey2 = RSAPublicKeyJava2DotNet(pubkey);

            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
            rsa.FromXmlString(pubkey2);
            // rsa.ConvertToXmlPublicJavaKey
            var bytes = Encoding.UTF8.GetBytes(pubkey2);//base64_fromjavabase64_fromjava )Convert.FromBase64String(signedData);
                                                        //  var certificate = new X509Certificate2(rsa);

            //var key1 = SymmetricJwk.FromBase64Url(base64_fromjava(pubkey));

            var json2 = new JwtBuilder()
                            .WithAlgorithm(new RS256Algorithm(rsa))
                            .MustVerifySignature()
                            .Decode(token);
            Console.WriteLine(json2);
            //
            // RsaPkcs8Util rsa = new XC.RSAUtil.RsaPkcs8Util(Encoding.UTF8, pubkey2, null);
             var key = SymmetricJwk.FromBase64Url(base64_fromjava(pubkey2));
            var policy = new TokenValidationPolicyBuilder()
               .RequireSignature("bestsign", key, SignatureAlgorithm.RS256)
               // .RequireAudience("636C69656E745F6964") 
               .Build();

            if (Jwt.TryParse(token, policy, out Jwt jwt)) {
                Console.WriteLine("The token is " + jwt);
            } else {
                Console.WriteLine("Failed to read the token. Error: " + Environment.NewLine + jwt.Error);
            }
            jwt.Dispose();
        }
    }
}
            //*/
             

/* 

                       var json1 = new JwtBuilder()
                                 .WithAlgorithm(new HMACSHA256Algorithm()) 
                                 .WithSecret(pubkey)
                                  .MustVerifySignature()
                                 .Decode(token);
                         Console.WriteLine(json1);


 
                        var key = RsaJwk.FromBase64Url
                                   (
                                       e: "AQAB",
                                       n: "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCjXTUcGpQOwwRs7Lppk3w4K2DDTlFKROerKy6hJ+eskk5zL9bCLv3FocZ6tvgx0t5xpgbH8qrclhhtQaSdJ6Ze+8E3XHLIrCgLWjhzTavb0ykNyWrLkd2znAWDn0jy6oieYdqJLVR/h1Rv+bxPGaEI2Iaja8mBcgfgEoKQVDUB3wIDAQAB",
                                       alg: SignatureAlgorithm.RS256
                                   );









                      var policy1 = new TokenValidationPolicyBuilder()
                                       .RequireSignature("bestsign", key1, SignatureAlgorithm.RS256)
                                       // .RequireAudience("636C69656E745F6964") 
                                       .Build(); */

/*            if (Jwt.TryParse(token, policy1, out Jwt jwt1)) {
                Console.WriteLine("The token is " + jwt1);
            } else {
                Console.WriteLine("Failed to read the token. Error: " + Environment.NewLine + jwt.Error);
            }*/

/*      var policy11 = new TokenValidationPolicyBuilder()
                     .RequireSignature("bestsign", key, SignatureAlgorithm.RS256)
                     // .RequireAudience("636C69656E745F6964") 
                     .Build();

      if (Jwt.TryParse(token, policy11, out Jwt jwt11)) {
          Console.WriteLine("The token is " + jwt11);
      } else {
          Console.WriteLine("Failed to read the token. Error: " + Environment.NewLine + jwt11.Error);
      }*/




/*            if (Jwt.TryParse(token, policy, out Jwt jwt1)) {
               Console.WriteLine("The token is " + jwt1);
           } else {
               Console.WriteLine("Failed to read the token. Error: " + Environment.NewLine + jwt1.Error);
           }*/

//----------------------------------------
//RsaPkcs8Util rsa = new XC.RSAUtil.RsaPkcs8Util(Encoding.UTF8, pubkey, null);
/*            var key1 = SymmetricJwk.FromBase64Url(pubkey1);
            var policy1 = new TokenValidationPolicyBuilder()
                           .RequireSignature("bestsign", key1, SignatureAlgorithm.RS256)
                           // .RequireAudience("636C69656E745F6964")RS256
                           .Build();
            if (Jwt.TryParse(token, policy1, out Jwt jwt11)) {
                Console.WriteLine("The token is " + jwt11);
            } else {
                Console.WriteLine("Failed to read the token. Error: " + Environment.NewLine + jwt.Error);
            }


            if (Jwt.TryParse(token, policy, out Jwt jwt11111)) {
                Console.WriteLine("The token is " + jwt11111);
            } else {
                Console.WriteLine("Failed to read the token. Error: " + Environment.NewLine + jwt11111.Error);
            }*/

//when
// var test = Base64Url.Encode(new byte[] { 72, 101, 108, 108, 111, 32, 66, 97, 115, 101, 54, 52, 85, 114, 108, 32, 101, 110, 99, 111, 100, 105, 110, 103, 33 });

//then
// Assert.Equal(test, "SGVsbG8gQmFzZTY0VXJsIGVuY29kaW5nIQ");

// Initializes the shared secret as a symmetric key of 256 bits

// var key = RsaJwk.FromBase64Url(
//      n: pubkey,
//      e: "AQAB"
//    );//, KeyManagementAlgorithm.RsaOaep256

// RSAParameters ss= XC.RSAUtil.CreateRsapFromPublicKey(pubkey);


// string pubkey = "R9MyWaEoyiMYViVWo8Fk4TUGWiSoaW6U1nOqXri8_XU";
//  var key = SymmetricJwk.FromBase64Url(pubkey1);




// Defines the validation policy: 
// - Require the issuer "https://idp.example.com/", with the predefined key, with the signature algorithm HS256
// - Require the audience "636C69656E745F6964"









// Do not forget to dispose the Jwt, or you may suffer of GC impacts

