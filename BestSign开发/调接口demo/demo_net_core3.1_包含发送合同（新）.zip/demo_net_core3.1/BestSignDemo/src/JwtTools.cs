﻿using JWT;
using JWT.Algorithms;
using JWT.Builder;
using JWT.Exceptions;
using JWT.Serializers;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Security;
using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace BestSignDemo.src {
    class JwtTools {

        //把java格式的公钥转化为c#格式的公钥
        private static string RSAPublicKeyJava2DotNet(string publicKey) {
            RsaKeyParameters publicKeyParam = (RsaKeyParameters)PublicKeyFactory.CreateKey(Convert.FromBase64String(publicKey));
            return string.Format("<RSAKeyValue><Modulus>{0}</Modulus><Exponent>{1}</Exponent></RSAKeyValue>",
            Convert.ToBase64String(publicKeyParam.Modulus.ToByteArrayUnsigned()),
            Convert.ToBase64String(publicKeyParam.Exponent.ToByteArrayUnsigned()));
        }

        static void Main(string[] args) {

            //解释rsa加密的token
            Console.WriteLine("=== RS256(RSA-SHA256) ============================================================");
            //token
            string token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJiZXN0c2lnbiIsIm5hbWUiOiJKb2UiLCJmcm9tIjoiWkoiLCJpYXQiOjE2MDgwMTU3NjN9.B601zveZvRJXWXzTnIzPEmE7YDIxvn7R_genzTIoXPGoVno3TPoDlIiBWZPKddZCjKEAVCHSKaAjQAUoTcHkwZn0FZkU1EM8Xkp7ixdMIiD4Od6H8aWZnUmeObmimF9S_y-S8cqQ-1hl0MpdkidTt3MyLu36JeE40w3lbMfAsj8";
           //java生成的公钥
            string pubkey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCjXTUcGpQOwwRs7Lppk3w4K2DDTlFKROerKy6hJ+eskk5zL9bCLv3FocZ6tvgx0t5xpgbH8qrclhhtQaSdJ6Ze+8E3XHLIrCgLWjhzTavb0ykNyWrLkd2znAWDn0jy6oieYdqJLVR/h1Rv+bxPGaEI2Iaja8mBcgfgEoKQVDUB3wIDAQAB";
            
            //公钥转换
            string pubkey2 = RSAPublicKeyJava2DotNet(pubkey);
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
            rsa.FromXmlString(pubkey2);
            try {
                //解析token
                var json2 = new JwtBuilder()
                    .WithAlgorithm(new RS256Algorithm(rsa))  //验证类型
                    .MustVerifySignature()                   //必须验证签名
                    .Decode(token);                          //token信息
                Console.WriteLine(json2);
            } catch (TokenExpiredException) {
                Console.WriteLine("Token has expired");

            } catch (SignatureVerificationException) {
                Console.WriteLine("Token has invalid signature");

            }

            //解释HMAC加密格式token
            Console.WriteLine("=== HS256(HMAC-SHA256) ============================================================");
            //token
            const string token2 = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJjbGFpbTEiOjAsImNsYWltMiI6ImNsYWltMi12YWx1ZSJ9.8pwBI_HtXqI3UgQHQ_rDRnSQRxFL1SR8fbQoS-5kM5s";
            //共享的 secret_key
            const string secret_key = "GQDstcKsx0NHjPOuXOYg5MbeJ1XT0uFiwDVvVBrk";

            try {

                //构建解析器
                IJsonSerializer serializer = new JsonNetSerializer();       
                IJwtDecoder decoder = new JwtDecoder(serializer, new JwtValidator(serializer, new UtcDateTimeProvider()), new JwtBase64UrlEncoder(), new HMACSHA256Algorithm());

                //解析token
                var json21 = decoder.Decode(token2, secret_key, verify: true);

                Console.WriteLine(json21);

            } catch (TokenExpiredException) {
                Console.WriteLine("Token has expired");

            } catch (SignatureVerificationException) {
                Console.WriteLine("Token has invalid signature");

            }
        }
     }
}
