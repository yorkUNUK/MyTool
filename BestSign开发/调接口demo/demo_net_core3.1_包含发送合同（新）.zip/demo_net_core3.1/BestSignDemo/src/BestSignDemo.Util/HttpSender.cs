﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BestSignDemo.Util
{
    class HttpSender
    {
        const int DEFAULT_CONNECT_TIMEOUT = 5000; //默认连接超时
        const int DEFAULT_IO_TIMEOUT = 60000; //默认读写超时

        const string DEFAULT_CONTENTTYPE = "application/json;charset=utf-8"; //默认ContentType

        public static JObject SendRequest(string url, string method, Dictionary<string, object> postData, Dictionary<string, string> headers)
        {
            HttpWebRequest httpWebRequest = HttpWebRequest.CreateHttp(url);

            httpWebRequest.Timeout = DEFAULT_CONNECT_TIMEOUT;
            httpWebRequest.ReadWriteTimeout = DEFAULT_IO_TIMEOUT;
            httpWebRequest.ContentType = DEFAULT_CONTENTTYPE;

            httpWebRequest.Method = method;

            if (ParamChecker.CheckIsNotEmpty(headers))
            {
                foreach(string key in headers.Keys)
                {
                    string value = headers.GetValueOrDefault(key);
                    if (ParamChecker.CheckIsNotBlank(value))
                    {
                        httpWebRequest.Headers.Add(key, value);
                    }
                }
            }

            JObject request = new JObject
            {
                { "url", url },
                { "method", method }
            };

            if (method.Equals("POST"))
            {
                string requestBody = JsonConvert.SerializeObject(postData);
                request.Add("requestBody", JObject.Parse(requestBody));
                byte[] requestBodyBytes = Encoding.UTF8.GetBytes(requestBody);

                using (Stream requestStream = httpWebRequest.GetRequestStream())
                {
                    requestStream.Write(requestBodyBytes);
                }

                httpWebRequest.ContentLength = requestBodyBytes.Length;
            }

            Console.WriteLine("request:");
            Console.WriteLine(request);

            HttpWebResponse httpWebResponse = httpWebRequest.GetResponse() as HttpWebResponse;
            using (Stream responseStream = httpWebResponse.GetResponseStream())
            {
                using (StreamReader reader = new StreamReader(responseStream, Encoding.UTF8))
                {
                    JObject response = null;

                    bool isFileDownload = "success".Equals(httpWebResponse.Headers.Get("bestsign-file-download"), StringComparison.OrdinalIgnoreCase);
                    if (isFileDownload)
                    {
                        string fileType = httpWebResponse.Headers.Get("content-type").Contains("pdf") ? "pdf" : "zip";
                        //
                        MemoryStream ms = new MemoryStream();
                        using (ms) {
                            byte[] buffer = new byte[4096];
                            int bytesRead;
                            while ((bytesRead = responseStream.Read(buffer, 0, buffer.Length)) > 0) {
                                ms.Write(buffer, 0, bytesRead);
                            }
                        }
                        string bs64 = Convert.ToBase64String(ms.ToArray());

                        response = new JObject()
                        {
                            { "content-type", httpWebResponse.Headers.Get("content-type") },
                            { "fileType", fileType },
                            { "content", bs64 }
                        };
                    }
                    else
                    {
                        response = JObject.Parse(reader.ReadToEnd());
                    }

                    Console.WriteLine("response:");
                    Console.WriteLine(response);
                    return response;
                }
            }
        }
    }
}