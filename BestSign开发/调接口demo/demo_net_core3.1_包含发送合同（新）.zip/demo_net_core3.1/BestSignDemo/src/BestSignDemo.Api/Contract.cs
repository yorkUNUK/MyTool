﻿using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using BestSignDemo.Util;

namespace BestSignDemo.Api
{
    class Contract
    {
        // 查询集团成员信息
        public static JObject GroupMembers(string account ) {
            string uri = $"/api/ents/role/group-members"; 
            string method = "POST";
            Dictionary<string, object> postData = new Dictionary<string, object>()
            {
                { "account", account } 
            };
            return BestSignHttpClient.Instance.Request(uri, method, postData, null);
        }
        // 下载附页
        public static JObject DownloadContractAppendix(string contractId, string account, string enterpriseName)
        {
            string uri = $"/api/contracts/{contractId}/appendix-file";
            string method = "GET";

            Dictionary<string, object> urlParams = new Dictionary<string, object>()
            {
                { "account", account },
                { "enterpriseName", enterpriseName }
            };

            return BestSignHttpClient.Instance.Request(uri, method, null, urlParams);
        }

        // 下载合同
        public static JObject DownloadContract(string account, string enterpriseName,  string  contractId, string fileType) {
            string uri = "/api/contracts/download-file";
            string method = "POST";
            //
            var contractIds = new JArray();
            contractIds.Add(contractId);
            Dictionary<string, object> urlParams = new Dictionary<string, object>()
            {
                { "account", account },
                { "enterpriseName", enterpriseName }
            };

            Dictionary<string, object> postData = new Dictionary<string, object>()
            {
                { "contractIds", contractIds },
                { "fileType", fileType },
            };

            return BestSignHttpClient.Instance.Request(uri, method, postData, urlParams);
        }

        // 查询模板详情
        public static JObject QueryTemplateDetail(string templateId)
        {
            string uri = $"/api/templates/overview";
            string method = "GET";

            Dictionary<string, object> urlParams = new Dictionary<string, object>()
            {
                { "queryType", "template-detail" },
                { "id", templateId }
            };

            return BestSignHttpClient.Instance.Request(uri, method, null, urlParams);
        }

        
        // 发送合同（新）
        public static JObject CreateContractNew(string templateId, string bizNo, JArray documents, JArray roles) {
            string uri = "/api/templates/send-contracts-sync-v2";
            string method = "POST";

            Dictionary<string, object> postData = new Dictionary<string, object>()
            {
                { "documents", documents },
                { "roles", roles },
                { "templateId", templateId },
                { "bizNo", bizNo },
            };

            return BestSignHttpClient.Instance.Request(uri, method, postData, null);
        }
        
    }
}
