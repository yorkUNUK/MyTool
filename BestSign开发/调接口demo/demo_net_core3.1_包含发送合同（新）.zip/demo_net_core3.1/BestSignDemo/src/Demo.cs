﻿using System;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using BestSignDemo.Api;
using BestSignDemo.Util;
using System.IO;
using System.Collections.Generic;

namespace BestSignDemo
{
    class Demo
    {
        static void Main(string[] args)
        {
            BestSignHttpClient.Init();
            //ContractDemo();
            CreateContractDemo();
        }


        //--------------------- Demo ---------------------//
        // Demo
        static void ContractDemo()
        {
            Console.WriteLine("===============================================================");
            Console.WriteLine("查询绑定状态：");
            string devAccountId = "ssodemodevaccountid";
            JObject resultData = SSO.QueryBindingStatus(devAccountId);
            Console.WriteLine(resultData);
 
            string contractId = "2283941012978008072";
            string account = "xi_zheng@bestsign.cn";
            string enterpriseName = "奥观海科技有限公司";

            JObject groupMembers = Contract.GroupMembers(account );
             Console.WriteLine(groupMembers);
            // 下载合同附页
            Console.WriteLine("===============================================================");
            Console.WriteLine("下载附页：");
            JObject downloadContractAppendix = Contract.DownloadContractAppendix(contractId, account, enterpriseName);
            Console.WriteLine(downloadContractAppendix);
            var baseStr = downloadContractAppendix["content"];
            byte[] contracBytes = Convert.FromBase64String(baseStr.Value<string>());

            string filename = (DateTime.UtcNow.Ticks - 621355968000000000).ToString() + "-fu.pdf" ;
            FileStream fs = new FileStream(filename, FileMode.CreateNew);
            fs.Write(contracBytes, 0, contracBytes.Length);
            fs.Close();

            // 下载合同 
            Console.WriteLine("===============================================================");
            Console.WriteLine("下载合同：");
            string fileType = "zip";
            JObject downloadContract = Contract.DownloadContract(account, enterpriseName, contractId, fileType);
            Console.WriteLine(downloadContract);
              baseStr = downloadContract["content"];
             contracBytes = Convert.FromBase64String(baseStr.Value<string>());

              filename = (DateTime.UtcNow.Ticks - 621355968000000000).ToString()+"."+ fileType;
              fs = new FileStream(filename, FileMode.CreateNew);
            fs.Write(contracBytes, 0, contracBytes.Length);
            fs.Close();

            fileType = "pdf";
            downloadContract = Contract.DownloadContract(account, enterpriseName, contractId, fileType);
            Console.WriteLine(downloadContract);
            baseStr = downloadContract["content"];
            contracBytes = Convert.FromBase64String(baseStr.Value<string>());

            filename = (DateTime.UtcNow.Ticks - 621355968000000000).ToString() + "." + fileType;
            fs = new FileStream(filename, FileMode.CreateNew);
            fs.Write(contracBytes, 0, contracBytes.Length);
            fs.Close();
        }

        static void CreateContractDemo()
        {
            String templateId = "3048638357174222853";
            JObject result = Contract.QueryTemplateDetail(templateId);
            String documentId = result["documents"][0].Value<string>("documentId");
            String roleId = result["roles"][0].Value<string>("roleId");
            String bizNo = "C#发送合同测试";

            // 设置新增签约人的签署位置
            FileStream filestream = new FileStream("/Users/edianyun/Downloads/york.pdf", FileMode.Open);
            Dictionary<string, object> appendingSignLabel = new Dictionary<string, object>()
            {
                { "x", 0.5 },
                { "y", 0.5 },
                { "roleName", "个人" },
                { "type", "SIGNATURE" },
                { "pageNumber", 1 },
            };
            var appendingSignLabels = new JArray();
            appendingSignLabels.Add((JObject)JToken.FromObject(appendingSignLabel));

            // 读取文件base64
            byte[] bt = new byte[filestream.Length];
            filestream.Read(bt, 0, bt.Length);
            String base64Str = Convert.ToBase64String(bt);
            Dictionary<string, object> document = new Dictionary<string, object>()
            {
                { "documentId", documentId },
                { "fileName", "测试.pdf" },
                { "content", base64Str },
                { "appendingSignLabels", appendingSignLabels },
            };
            var documents = new JArray();
            documents.Add((JObject)JToken.FromObject(document));

            //设置签署人信息
            Dictionary<string, object> userInfo_1 = new Dictionary<string, object>()
            {
                { "userAccount", "18236922636" },
                { "enterpriseName", "上上签签签公司" },
            };
            Dictionary<string, object> role_1 = new Dictionary<string, object>()
            {
                { "roleId", roleId },
                { "userInfo", (JObject)JToken.FromObject(userInfo_1) },
            };

            Dictionary<string, object> userInfo_2 = new Dictionary<string, object>()
            {
                { "userAccount", "15867397177" },
                { "userName", "徐宇超" },
            };
            Dictionary<string, object> role_2 = new Dictionary<string, object>()
            {
                { "userInfo", (JObject)JToken.FromObject(userInfo_2) },
                { "roleName", "个人" },
                { "receiverType", "SIGNER" },
                { "userType", "PERSON" },
                { "disabled", false },
            };
            var roles = new JArray();
            roles.Add((JObject)JToken.FromObject(role_1));
            roles.Add((JObject)JToken.FromObject(role_2));
            JObject createContractResult = Contract.CreateContractNew(templateId, bizNo, documents, roles);
            Console.WriteLine(createContractResult);
        }
    }
}
