package cn.bestsign.ultimate.delta.api.domain.contract.newCreate;

public class WorkFlowSteps {
    private int flowOrderNum;
    private String userAccount;

    public int getFlowOrderNum() {
        return flowOrderNum;
    }
    public void setFlowOrderNum(int flowOrderNum) {
        this.flowOrderNum = flowOrderNum;
    }

    public String getUserAccount() {
        return userAccount;
    }
    public void setUserAccount(String userAccount) {
        this.userAccount = userAccount;
    }
}
