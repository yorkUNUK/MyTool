package cn.bestsign.ultimate.delta.api.domain.contract.newCreate.document;

public class ContractConfig {
    private String contractTitle;
    private String contractType;
    private String customContractId;
    private int signExpireDays;
    private Long contractLifeEnd;

    public String getContractTitle() {
        return contractTitle;
    }
    public void setContractTitle(String contractTitle) {
        this.contractTitle = contractTitle;
    }

    public String getContractType() {
        return contractType;
    }
    public void setContractType(String contractType) {
        this.contractType = contractType;
    }

    public String getCustomContractId() {
        return customContractId;
    }
    public void setCustomContractId(String customContractId) {
        this.customContractId = customContractId;
    }

    public int getSignExpireDays() {
        return signExpireDays;
    }
    public void setSignExpireDays(int signExpireDays) {
        this.signExpireDays = signExpireDays;
    }

    public Long getContractLifeEnd() {
        return contractLifeEnd;
    }
    public void setContractLifeEnd(Long contractLifeEnd) {
        this.contractLifeEnd = contractLifeEnd;
    }
}
