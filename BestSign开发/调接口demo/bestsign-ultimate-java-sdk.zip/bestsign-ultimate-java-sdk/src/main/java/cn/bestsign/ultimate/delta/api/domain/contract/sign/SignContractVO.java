package cn.bestsign.ultimate.delta.api.domain.contract.sign;

import java.util.List;

public class SignContractVO {
    private String sealName;
    private List<Long> contractIds;
    SignerVO signer;

    public String getSealName() {
        return sealName;
    }

    public void setSealName(String sealName) {
        this.sealName = sealName;
    }

    public List<Long> getContractIds() {
        return contractIds;
    }

    public void setContractIds(List<Long> contractIds) {
        this.contractIds = contractIds;
    }

    public SignerVO getSigner() {
        return signer;
    }

    public void setSigner(SignerVO signer) {
        this.signer = signer;
    }
}
