package cn.bestsign.ultimate.delta.api.domain.contract.newCreate;

import java.util.List;

public class NewCreateContractVO {
    private String templateId;
    private String contractName;
    NewSenderVO sender;
    private List<NewRolesVO> roles;
    private Boolean signOrderly;
    private List<NewDocumentsVO> documents;
    private Long documentFederationId;
    private List<NewTextLabelVO> textLabels;
    private List<NewImageLabelVO> imageLabels;
    private String sendAction;
    private String returnUrl;
    private String pushUrl;
    private String bizNo;
    ApprovalWorkFlow approvalWorkFlow;

    /*
    模板ID
     */
    public String getTemplateId() {
        return templateId;
    }
    public void setTemplateId(String templateId) {
        this.templateId = templateId;
    }

    /*
    合同名称
     */
    public String getContractName() {
        return contractName;
    }
    public void setContractName(String contractName) {
        this.contractName = contractName;
    }

    /*
    是否顺序签
     */
    public Boolean getSignOrderly() {
        return signOrderly;
    }
    public void setSignOrderly(Boolean signOrderly) {
        this.signOrderly = signOrderly;
    }

    /*
    发件方
     */
    public NewSenderVO getSender() {
        return sender;
    }

    public void setSender(NewSenderVO sender) {
        this.sender = sender;
    }

    /*
    收件方
     */
    public List<NewRolesVO> getRoles() {
        return roles;
    }

    public void setRoles(List<NewRolesVO> roles) {
        this.roles = roles;
    }

    /*
    合同文件
     */
    public List<NewDocumentsVO> getDocuments() {
        return documents;
    }

    public void setDocuments(List<NewDocumentsVO> documents) {
        this.documents = documents;
    }

    /*
    模板文档组合ID
     */
    public Long getDocumentFederationId() {
        return documentFederationId;
    }
    public void setDocumentFederationId(Long documentFederationId) {
        this.documentFederationId = documentFederationId;
    }

    /*
    合同字段
     */
    public List<NewTextLabelVO> getTextLabels() {
        return textLabels;
    }

    public void setTextLabels(List<NewTextLabelVO> textLabels) {
        this.textLabels = textLabels;
    }

    public List<NewImageLabelVO> getImageLabels() {
        return imageLabels;
    }

    public void setImageLabels(List<NewImageLabelVO> imageLabels) {
        this.imageLabels = imageLabels;
    }

    /*
    合同发送状态
     */
    public String getSendAction() {
        return sendAction;
    }
    public void setSendAction(String sendAction) {
        this.sendAction = sendAction;
    }

    /*
    客户自定义的跳转地址
     */
    public String getReturnUrl() {
        return returnUrl;
    }
    public void setReturnUrl(String returnUrl) {
        this.returnUrl = returnUrl;
    }

    /*
    客户自定义的异步通知地址
     */
    public String getPushUrl() {
        return pushUrl;
    }
    public void setPushUrl(String pushUrl) {
        this.pushUrl = pushUrl;
    }

    /*
    客户自定义字段
     */
    public String getBizNo() {
        return bizNo;
    }
    public void setBizNo(String bizNo) {
        this.bizNo = bizNo;
    }

    /*
    审批配置
     */
    public ApprovalWorkFlow getApprovalWorkFlow() {
        return approvalWorkFlow;
    }
    public void setApprovalWorkFlow(ApprovalWorkFlow approvalWorkFlow) {
        this.approvalWorkFlow = approvalWorkFlow;
    }
}
