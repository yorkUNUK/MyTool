package cn.bestsign.ultimate.delta.api.domain.contract.newCreate.role;

public class RealNameAuthenticationVO {
    private String idNumber;
    private Boolean requireIdentityAssurance;
    private Boolean requireEnterIdentityAssurance;

    public String getIdNumber() {
        return idNumber;
    }
    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    public Boolean getRequireIdentityAssurance() {
        return requireIdentityAssurance;
    }
    public void setRequireIdentityAssurance(Boolean requireIdentityAssurance) {
        this.requireIdentityAssurance = requireIdentityAssurance;
    }

    public Boolean getRequireEnterIdentityAssurance() {
        return requireEnterIdentityAssurance;
    }
    public void setRequireEnterIdentityAssurance(Boolean requireEnterIdentityAssurance) {
        this.requireEnterIdentityAssurance = requireEnterIdentityAssurance;
    }
}
