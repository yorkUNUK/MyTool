package cn.bestsign.ultimate.delta.api.domain.notarization;

public class NotarizationVO {
    private Integer fileType;
    private String account;
    private String entName;
    private Long contractId;

    public Integer getFileType() {
        return fileType;
    }
    public Long getContractId() { return contractId;}
    public String getAccount() {return account;}
    public String getEntName() {return entName;}

    public void setFileType(Integer fileType) {
        this.fileType = fileType;
    }
    public void setContractId(Long contractId) {
        this.contractId = contractId;
    }
    public void setAccount(String account) {this.account = account;}
    public void setEntName(String entName) {this.entName = entName;}
}
