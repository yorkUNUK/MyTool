package cn.bestsign.ultimate.delta.api.domain.contract.newCreate.role;

public class UserInfoVO {
    private String UserAccount;
    private String enterpriseName;
    private String userName;

    public String getUserAccount() {
        return UserAccount;
    }
    public void setUserAccount(String UserAccount) {
        this.UserAccount = UserAccount;
    }

    public String getEnterpriseName() {
        return enterpriseName;
    }
    public void setEnterpriseName(String enterpriseName) {
        this.enterpriseName = enterpriseName;
    }

    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
}
