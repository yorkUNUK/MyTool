package cn.bestsign.ultimate.delta.api.domain.contract.newCreate.document;

public class AppendingSignLabels {
    private Number x;
    private Number y;
    private String roleName;
    private String type;
    private int pageNumber;

    public Number getX() {
        return x;
    }
    public void setX(Number x) {
        this.x = x;
    }

    public Number getY() {
        return y;
    }
    public void setY(Number y) {
        this.y = y;
    }

    public String getRoleName() {
        return roleName;
    }
    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }

    public int getPageNumber() {
        return pageNumber;
    }
    public void setPageNumber(int pageNumber) {
        this.pageNumber = pageNumber;
    }

}