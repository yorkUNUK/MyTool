package cn.bestsign.ultimate.delta.api.domain.contract.newCreate;

import cn.bestsign.ultimate.delta.api.domain.contract.newCreate.role.*;

public class NewRolesVO {
    private String roleId;
    private String roleName;
    private String receiverType;
    private String userType;
    private String ridingSealY;
    private Boolean disabled;
    ProxyClaimerVO proxyClaimer;
    UserInfoVO userInfo;
    RealNameAuthenticationVO realNameAuthentication;
    SignerConfigVO signerConfig;
    NoticeConfigVO noticeConfig;

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getReceiverType() {
        return receiverType;
    }

    public void setReceiverType(String receiverType) {
        this.receiverType = receiverType;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getRidingSealY() {
        return ridingSealY;
    }

    public void setRidingSealY(String ridingSealY) {
        this.ridingSealY = ridingSealY;
    }

    public Boolean getDisabled() {
        return disabled;
    }

    public void setDisabled(Boolean disabled) {
        this.disabled = disabled;
    }

    /*
    前台代收
     */
    public ProxyClaimerVO getProxyClaimer() {
        return proxyClaimer;
    }

    public void setProxyClaimer(ProxyClaimerVO proxyClaimer) {
        this.proxyClaimer = proxyClaimer;
    }

    /*
    接收方账号信息
     */
    public UserInfoVO getUserInfo() {
        return userInfo;
    }

    public void setUserInfo(UserInfoVO userInfo) {
        this.userInfo = userInfo;
    }

    /*
    实名要求
     */
    public RealNameAuthenticationVO getRealNameAuthentication() {
        return realNameAuthentication;
    }

    public void setRealNameAuthentication(RealNameAuthenticationVO realNameAuthentication) {
        this.realNameAuthentication = realNameAuthentication;
    }

    /*
    签署要求
     */
    public SignerConfigVO getSignerConfig() {
        return signerConfig;
    }

    public void setSignerConfig(SignerConfigVO signerConfig) {
        this.signerConfig = signerConfig;
    }

    /*
    通知规则
     */
    public NoticeConfigVO getNoticeConfig() {
        return noticeConfig;
    }

    public void setNoticeConfig(NoticeConfigVO noticeConfig) {
        this.noticeConfig = noticeConfig;
    }
}
