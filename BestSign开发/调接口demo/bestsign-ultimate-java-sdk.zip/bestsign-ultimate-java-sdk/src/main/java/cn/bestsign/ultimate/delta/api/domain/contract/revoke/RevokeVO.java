package cn.bestsign.ultimate.delta.api.domain.contract.revoke;

import cn.bestsign.ultimate.delta.api.domain.contract.newCreate.NewSenderVO;

public class RevokeVO {
    private String revokeReason;
    NewSenderVO newSenderVO;

    public String getRevokeReason() {
        return revokeReason;
    }
    public void setRevokeReason(String revokeReason) {
        this.revokeReason = revokeReason;
    }

    /*
    撤销原因
     */
    public NewSenderVO getNewSenderVO() {
        return newSenderVO;
    }
    public void setNewSenderVO(NewSenderVO newSenderVO) {
        this.newSenderVO = newSenderVO;
    }
}
