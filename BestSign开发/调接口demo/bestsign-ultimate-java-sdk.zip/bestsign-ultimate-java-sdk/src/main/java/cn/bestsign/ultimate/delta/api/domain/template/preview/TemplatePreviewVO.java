package cn.bestsign.ultimate.delta.api.domain.template.preview;

public class TemplatePreviewVO {
    private String templateId;

    public String getTemplateId() {return templateId;}
    public void setTemplateId(String templateId) {this.templateId = templateId;}
}
