package cn.bestsign.ultimate.delta.api.test;

import cn.bestsign.ultimate.delta.api.client.*;
import com.alibaba.fastjson.JSONArray;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.junit.Test;
import com.alibaba.fastjson.JSONObject;
import okhttp3.*;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.net.URLEncoder;
import java.util.concurrent.TimeUnit;


public class ContractApiTest {
    /**
     * 公有云
     */
    final String privateKey_info = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAKxU/jmowdXypsKW991/g20t5MhQY2lyQkS7Q6jc4QrxPIazGAkubE+fxE852ljKRom/JEsYVUZ4SJeqimVp5U1prlXtrejxkpSA3FZ198ow8b++WV2OazFZmwwJxfdx3znoCM1ZliPauRITfYhDByOZ6VXAntMQcVeIuwSF8rWNAgMBAAECgYA4zEp99oDsYu1TdS58cmp+sYGWA+i/+EifHplOLn59fMTWIHDrlcFc/OtWsVqlqQVWoQj1Ny/j6gEC+9JhWmWYcpXxSg/YwcJQfQ79NHgPIOMtT/cVQ//Vih9qn0y3dQJEt282ttKA3HhHoYfZ8clN2w2yzefZp+5FJHpwxMmSgQJBAO3WcugeTz0cqx8pPbLK45lUtkmJZSyGSGz/edh1+1LrkHKNo+MaXM0h2UdvGPlPTc/6KjBV71tcFqByku3Z6gMCQQC5ffTYy31uWyWw+JG0gvMw/xjHcFW9C6u+2ST7LlcfZ8omW+Uf5zTcXkjMoaQUlVOmt0E7xfSWROKg/LglP5UvAkAHDDG/exZyAyV2+OvhHm38Hyx/pVigJyKCSFe9+FEINf7DxjqzAhb55SThHwOob5cosIsLf6BmHqZ0/rAn6CstAkBhA0Nfb232na0k1Zw+8I4IfiKTjGkLKmN0uVTiGeZvAnVzgnRfLykyaA1jGNcb/M13UDjJ7kpxnS16TTJyKML5AkEAoJ0AkfoFzzWDnVAb3922pvr2DQaqB87XUfiNKoV+FIGdXYnMHjKMMFNV84m+UMj7s2lKB2wS7id4HxqAVTFl6Q==";
    private final BestSign_SSQ_Client bestSignClient_info = new BestSign_SSQ_Client(
            "https://api.bestsign.info",
            "1626074470012587260",
            "be6cc5dc30234774b21f8ed12d831b3d",
            privateKey_info
    );
    /**
     * 混2
     */
    final String privateKey_2 = "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCncb+52llGMliQYmXJ+1XaqBbtzH/jyzu9w9AdfWNw3e940VZIli1op7sPflyGAp7ZnOnHnF0gaTbnOIP1MjcuvChgFV6t1spnLzfx5rMaWo3ZZjSHyhP+Au/YNHHSQcO93tAduKLjAwEJ1gXqKKPTWKg/LhTwbQUJnyfQyp1sJUdx+los3VR7KtFWOPs9UbT0FVSEMWmGC+MiY3FUCxcCQm2K94m8miYFLJ9j/gc9TbNNcZayDyyT78IVBfiGj+OMNYyALYpltiN76P4NspV7q6S/WZZCvWG/q8T44f4TCLJ28HmZwa44KbcRpyozDS5fs/D9VO59kRJtXzG0H5qlAgMBAAECggEAeTrw3gWJZzpiRr8HBVLUGQhj+W17Fpj5Ou4/impTCc+VZvrhJpKcc84ksBYDtP7GtbVWyS+beTDUEFopp+fgbhTKgq5WKzR8vHJCZgBqoeT4GHNYCwwyp1DHB9kIo3r71kcwlKQuQn/VS6LKC3u7CPSCc6PQgzXbVNkHQbLAgR/Z9bF+mTiS7p30gWPL2JFw1ZNf8mXQ9910FrZjJLoEHz4THZNPIitIuZ6v+PIXaMyFlGUUT45VUnVNXHc8bC3Rvz97fsdsZ+tMdyPEFpkxfbjXt/sSWuchltskF6g1VznNrDhIEPdBIUgRhyFtWuHf5YaryN3aFedfCYi/wH7LAQKBgQDsyhRcN5eIv7qIhXav/y+BF9w9zR95frKSQVvpdqFkO9K5v7kXfDS24ttI5RC4K1RY4w//llEVkayDsAvfVizw6IDBUr8cScjUeERqFYDMKmVsoZ5LLHcgQ2hSITx0ADuMSBUKje0Zp44Wx3dHjaxKKnpwyqmY3TUG0PyJPTJ2wQKBgQC1B24QgM86h0GWdlfsyoycetI1fxAmWZeRF7PVsOVLPnVYBbctgKKqYqjRpQ4T6scdpixjni+RtYiA9QQ8mI02+FyzfaduG3QsC452KgHoh5CnwudHc2OC/UmOay23RGpbYrjb/zQoLo8Et1mHXgI3bB5OlIUQ7KVqeJE+oTNg5QKBgH5cFGNlszLhhcxm1IB1AEe2kOxV8y7loquTv1Wl3dhcaEaBfmd++66A/x42RybQ0JEikp4E/D4zX8lif+Nt3Euu906zNpME+OwRRgkKcpIBKeC/mnZpQyTvc9MoM1d/7EcfDEN2m4luNdAIH6oKe1+UrYRVUg3mNe7uRWWDR9PBAoGBAJKaa8YtqqUJeFIzkM0Q04K97JKqThfgomA8Q8UgtvCSqlEYf9n3vMQjlfgBpT73+TzHoFckef2Ud/GHe2DfYi1MQTaS4g7HaPNqgHqtVlJLxxg1PTud9M7V9MXDgohSfZd4gaCYMlMAMY5uNbDsrvrXMkwM9x5XpzZsYaPIxGUJAoGBANd3OyB+m4Zo4NMhdh219lvdqWFJc+9TzixFAWuLo0xhxgu4EQ91uyLAgXSne1Rl7gEofQDZObDbLz9dnhIUjlCFDaluyNRUafGATD/sb4LDIcplLL3o80/9buHo0+DrYYSmovWXV3UU3/iGocd8i67hfGDa7ved797DUuCkAOkE";
    private final BestSign_SSQ_Client bestSignClient_2 = new BestSign_SSQ_Client(
            "https://york.itdocker.cn",
            "1640145415014482760",
            "2806596f762b4d9bae813b1e5d2453fe",
            privateKey_2
    );
    /**
     * 混3
     */
    final String privateKey_3 = "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQC7/BIowkX4PGJqOv5EFMxJZa7UKBeXm3VQBKowKTDFMbU8fJkOa+b9pkGW5l8mZuYUOvDnQUzbeiErRy9b3x05Fx9/7o9S1wqz/jXKDqudyK7faK/l2MD12PbImJ44SsdB4pmpbpLOeEb7N2otCRZKeTmAvh8F91CHDN8j6y+mwEOSGs4MVk+MA3sx9bb0BVyEI0GJ8AcxIekpO9Ej5v7SR0uqLbQDKgR4R8Jaq/5nktfqq3WW7sAhn6EqQYmyvXFgoqJ0jtkOu4xKYG2hvJurRMteLZw6OL0wDPBzCZ7gS4oBYooWfWfxzlSOnlnqXML6n1yS+cxIV0PY2drV51jtAgMBAAECggEBALcbBSUmdrkhOEt5QwpVp9cmcHC+zJwkFNTodk2LEbJChOJyCzP87nbLZr/xjWT+fcXe06Ct/osaHwzkvcCjRvfBCjG20WxDgm1ohERYndmHDK8YbZ1Y0DuoJlmmLxdt30DR1BMxXVY32gwBIi7T1x6bjeNVTSqmh43Ef+WgxD2LBCgCdwxWjFMD59muMCoPqNJj3KbcOYtDHnojzUlETt5SkwuY6Nou7I+jEQ+q8nQq9shhHFDHVElLBKFAXwmHVmgt4AC+9k4fAEhv0CcifPJKC6G+avhOVZTeHTKgv3oVBVzeCieSp7MRX50BdX3eP+cWjF0NUrpiYgHNGoPvzAECgYEA8C2WVKGyD0aLcHxDAGBaSxwoGxm20Hem+7nnpiYPxapJ1lRShchxb3pnQtsCQocF3OJaHXYey1NsWHo+UDyhUl+CXH6T0ukt+ZOzC2PLnprMIJ6MUulcMdJvq1GjTHzMaBoi2+aqzYfG7ocgm+TRgEqYv3CTlGDzHGCj7/k1q8ECgYEAyF5Ic8Zf0SoV+JfOKwzgIu5OeLPI/RMp0RG0KQOkJdkkaqzlOHOB5yTbuyUDw5zNrbeNHFHBUpAwLieMAXyAL4+NzRzaMRF/FA4mJ6XkpxCajdv/nwtuLIzGwpXBCrjAynjCkE/SSQfee6SkPzgrtms3OHZFftKhLEf6hBUiKC0CgYA0+HjtVXQl9lMOjflg/d8sLZuSzosJUzpazleOx1o3KCV8xcAljV2nToGztwW6knjyjGF/meuUwGNm6B8SJy0VM8dWivwjShY/sxmL64ifBFj84LrmFl2lB1plmG3BksyqMQl7IlaNWeK//MFuYHrsJoelwThrQy6bFZ1Scc4qgQKBgGctxfl4adb36SB+a7hXhQP324jka9eGir4Sc8e7DEhBLTORnOgY8wfoPw573RhaIsAWCSBQKVEu1uCtlLcfOZNERS0ecm1aKSpWrucz0i8FqdDrPRLVfAKM671ACIxQ31ZkISzXLd5VowfgnIPBlSD2zRTSMq9AH6cB2csyZshxAoGBANNAAlZ22lShNHzH5NK/dQVrp7gBBbZ3DA0aRXfDb60SABJzVFVcMBbIHV7hBUleybAY5WqiUbADrjWhn0Cw030gocH1o3va4pUSMm2nrBMkgU2umzD72aeWv+PWrrpzne+aibp3zJluN6byznMqsvLmD3JJYX9Uat/jsyBi1pJd";
    private final BestSign_SSQ_Client bestSignClient_3 = new BestSign_SSQ_Client(
            "https://www.xycserver.club",
            "1632398629017010601",
            "90431553f96048109064ddd5133f151f",
            privateKey_3
    );
    /**
     * 自定义
     */
    final String privateKey_gaodun = "MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCd6nDcTJvMHYb2ZfD4bEQzENn0ZV1wjLMkdPCPovOCNIQa7t7Eg3FM20WSoCRk3tRN3uwRR2M8NbfLbiKSJBRDpBJURyPKwiL0kN3wBYMPZA0jLRnS2y7/y9gDZfRzYQg1LPlgj57nI5ftx80r+x8OYjzeKKSCT8lyTeFvQoos3gDDyhfm23OBIojQQJmWHk9bT1mjS6IeDrQpg+iUNNZXa8zUs/j8yE6JhvtanEBO3s+HQDy7IoUxDXqdvtmXq7EEnvjg9HwoORltP/wac1VLb/oEPfKSuoyFwJx5xLsyFCzFubA1NzRN7tmpd6OUPt49ToBwJF0NyQXZRZPsGUHlAgMBAAECggEAdPykRZ//X1SUkl9tCCz0zTvzq6mYcnPZlu2G9XILoe8T2vwRTlXuDrj2rqwyqgOmFlZKXnabXpSRJ4Tc2ZUe6glXhtX4/xGZYcMcl98Ne85sKR4VXm8AP4Ic8k+KrBs7QGGkEVP0rVliCUaWibmNBVPjsdU8IknHfAWUN598y8UwQ0jM7IXMECdD4I9BabUw41VLq8dHqDTWP4X5jnkZ9PWNnF7x2+fJyGC2J2blo3KGwQd30gie8YVo4ydXqtl8BdHIQfjY01k8fTYQTcjQsmcQJ4geMfFQDYKPQl+0NrWS7iL5Rj/aZ7a8uPrimUFxp8aOxyS0e02sdISUglsx4QKBgQDzXMBO1mNUZFgbG64vgD6MGU01Rm/TWjJ+NoWxs5an4o4bmMjTeMc5Iu2HDQEu5SmkUyaMEFkd2wJwNuWoUhsDpCyNUgOBwcZZnp4UWHGcuYv/i6JsphxyWvb1OiZ7RyTYPNvuvu85oOoSfLJzRpu2E0UA9nudhtjO1DGZ0oWD2QKBgQCmHcRYwy033lkzPHORkYNOY3wEhRXKWWOb1W64RQup6z+S3PPO/VwWrmLV9c7Xa7iVoHyqr2SRDx89FLvZqb4M6GhDqmVx5ut57J8KGbVrwoB2OIKFXBpl6XRUefI18y7Dk4CCXdCOp3c0xuQkbEL11Yizk9Ck6PFzNTlNkZqC7QKBgHzLeFY1PBR/rGqiRC1ZnzlqlBwYtal1HGV6gg6BIGWRGPxv2bQPwGG9Vn6lnZC1tSft99tlWr2jnFl83UH2cKHqY2pIv0Gf4537Z+bY/9G1mGP/79e1SusdWHyiSC95aRx2APYp9TThHodCaKQSdjDlKsJ2oydBihZt282clhjpAoGAZWKflskwzPtxF7takcrtCCfh5mRPo1uhVtgSJndFoiSJfZpLV9b8oH84pXvMDWCanQABdq9rwrknCMGh0TwvWXNzR3E1TypwJ88KVkDQoH9qpjzhNIG9PtwYewKemNzeetGIyoh1pMuDDvwg/DXzPFVihK+/1RazXuxqF/S5CBUCgYAnzrj//MxSbjDURLsZYJMj9j0FIBQgYdgW+tptHBeGSuO+8oxfMIwGwA3Fdy0l7bSsEFMGJcfnWOYRUL4gkgwtJHFOpvpCnBZv8WtIJQe67XHQlWq516gcORu1wI0DiqGbgmXSGXQzezGCbkBkJIEdMX8MpXFitEjesjE3YsaFCA==";
    private final BestSign_SSQ_Client bestSignClient_gaodun = new BestSign_SSQ_Client(
            "https://api.bestsign.info",
            "1655114412015463177",
            "1e557751a9b54c4ab6463f62ebb0dbf2",
            privateKey_gaodun
    );
    /**
     * 自定义
     */
    final String privateKey_zeekr = "MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCON5L0pzRDHny/bryxRVxxSuw83T9ugMZTamnOq3B/isTaCWpDwQjma1BMPQ5lStWX8/SdaXGBSD2NhC800/gcxNOlmvpCKLUhOjHkA0lYFx3ibDE5iC9pw76XV+hRP46AkyYYfJ+BwiXXUkYPOzkuaQn5w4Bn8eTZq9rALnDOzvvzczyeM4yvxKofgfVAHwc/NLTJkOuA3BEws2IZDpowlInEkSwJAkAquOxaEW7yiCAy7Q/qcVZ+to0C0akvokGqqYqqb3MWUZUiPCeXwfPJCy4kaGckLZ/4gu6v5lglGt6JCCFlsVQe/voacYrXXkBfaxy67uykWb61a8mWJFSjAgMBAAECggEABCJHakcl9MGBHMtqPrjmbACih05jFqI1oZ0ZQEGpfnuZJ0FYzmlhCdmatuyba4RWWxljReQXwYtJBsEN4jo7HxL1l/2+QogOY83eP2N9EUtyue8tKx/zSN7AvoN2pE31pXUhiVquBEaRdQXWNYEiM2AoQxNUuzDD1zPwot92tfww6U8TbAfCTIW21cyhhIgbcrrmjZOHP3X+uXszqX5Bvkgshx98PjMv1nmsI8Ay+3wyyPWnn/s2p97uji5iHeeqIQ0BOl3zhv1x614Fpf/UShgI81f/7t1+hDb0XfKlcIme0ipd4qE8cCdhCmzJGvUn0N/IY6KSSBgK5RP6vRXFuQKBgQDtPGrn+xZTY6H1W0KUTcBdI/3AFfddX4NRFw9Jl3jr9KpIqG2mhVKUdBkBpHYhQsph0eyOlK1xMKtYstzNUtgE5wN9R+K64/rmdNZp/OUvBkVeza+modaS3qlnScusrzOWZux2sE7ZO5fgc8zBLUtdVFOqTDEBKPErLupOKp5eFwKBgQCZdzPFxgeLO70y4icDQoM4K9TRbdgRJ8OxyqIx8hMHQfkySbFhisAx34sBOpm6CrG/TGHav65PDZhiQZXxumrSGixl5L4vzjoSJWjUUBTEgJzRK1KVY+l6Ql7CRZToCu0lfbtxDwCBa7Eeg9yesjxxFRcCKp1pCnupArFY3/cBVQKBgB4RFDOGfRPggrxH7q5BFGo5j4Vyw0EQQ+JZG9Tl36t3/MTso8kBCLBL7odowpgAkQnIw0Rmz3yTAIRjVtym7T3h0W1lWPT6w+fFUw9nv9wv3Ubgpqxlwn4mvi2bCrc+FTmwnbOFMNkTVnJZ+s9Y4D5Z26ivs15ERByG+6cge6XNAoGAFwolVKjRUx7p3azELKIcrx8teS+jg5fTsmp4hUURhEJsVhdoMPuytQoZhVq1349hdhXSjxO96JJi8UVlbIAPL3HMfpOj1euBHl5NaaqII6QnZuO5J0Jzt+4k6cemflu9lKZWsLeO3N89HRaw1YZuuo9u/91D+pQfUpVb6LrfC20CgYBrKWkxzOGQNiy5cu7P6o/XG1sTrzQ1sklicAZgRJIXxcngz/Zu8k7R/m2pj5nLe1mOl5NG5dFoujI+ESrMzoT7hZcpjZYP/jZaAqqrpVsoKcD/h3A9YU5cmV6CwR2lC8P4/9PmFFDNM977s5Y3n6kB/UHrdCVUomVW02Umi0bfzA==";
    private final BestSign_SSQ_Client bestSignClient_zeekr = new BestSign_SSQ_Client(
            "https://sign-test.zeekrlife.com",
            "1628076010014126638",
            "97c13dfeb88e4d16bfd2f88ff90c3b83",
            privateKey_zeekr
    );
    /**
     * 自定义
     */
    final String privateKey_temp_1 = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCk33ynAIBo3O3mORlRsJvDFxE9jWn6KR8Whaz2ybxb1bZ5U8023ZYjRBzL4Po3MplXguaStEZVsX9dyiX8p4jYcVMORGFo5+KG5htbJ7Gx4nj71RYNFGPDgzHbbr/3a/rsd2BK+hrCewN1EvC80+8E+o3BW8fKqB5etp5yHCuB13WwOddsCDdw2NTN71QO1ZyutNDNqkSJxM/do5t/i3ikHV1/oTfm7nKxDeAq3YoiepAwCFwActfVU5RwAjtA5NE62xkEoClM1oVGwRsot61aGf6iQejG/y877c85Ck6mef35FmIaKfIJOLOFAu2Qphp2Y+gSkt4eTadtw9zABIevAgMBAAECggEAKGuOANdTo+G+BTosZeWZWkvWczOvLqBUOc5N6DbvEcikMryDzBapDz5MnQMr9MpX46d45bCCqdGZOyIrC/T6zK2DwjSreO+Yjp/tRvzFSKoQJRVJka1VBAKu/2/4ai0z2DMwDVGhq9pCr7oUAQcoSx0uEaBxq9Jpl6jH0Yvscqk9YcWyIUISab1Jbq+A/6Z/BA2OyQy9+wfoLToRmfB5g0iEmjVl5FjfyhrfK944fWMHSXVo66UnihhchWGSj+zzzqAjLAJwA7VNy0LHh/gwTVOTexXLg8YCgHihH4XU6eNtN5ZVCPnn/2yiThxdd7/xdqHcIhCdqsv/4j1EBmpGsQKBgQDp01RGFZN1Qkr1fSh2xF8dQ9UnoKO2zwjdN2dE3gBh3DlOUC9bvFCMQDdxbMMj8hkdGW+91QKUw/bEsI3BVLTtx+VIVrPVgYw64zfLPMG143S+Cr1QlWRao/Dq4bt6rB8+Jy0GE6/G5MxQ07r/jICwxNAdAZYLD1IfaTqUK32BhwKBgQC0giviAjawDYNq1/zV4SLSSyxZrNFqaLIMyzJuPngOtN20KbFeVFmLUZT5agBDTSXdQodvjEu1RgofuJoozGBEI5DJE63mfU7ChEk7WxmSvbGmxwK6jYP6TNQX4f3thgEXTzO99lZ2Y8/UVS0KhN1Tystnc+Ozsfw8yvud1AxymQKBgFeKXwq+GS7VWur9qKCOdG2ob60eXyyZ5l+r1mXaF5qLsIi5TIGzxxQ7FobIiWZzxSM32rXfgc/gbgrFbszqwbIkHJswmrNchPunBcR5QqyuM47Sxn3c8G1e41uMl3wd5LSIRjr4M97q2fOI0YHLQILtrFyvs1UAr2ZDJ0NB5QMRAoGAIqCGAokiLIurFifw3Kafo2/ARkOcuKj03vdr6TIandecYB9PYyUTOGKiDWaEPmTiSpukl4V2UIPrFUK4b/Mk1G1uLOSVi42mOjJeSgCj2z6AgdnTcC4Nj0qFtT8pExONygbrihljZLqo97aPOWFbg+N3OZVFrQcLuC3ILvKqoKECgYEAhx5JUWqO81L2vV4iz58Bzs1OgvUuMrHlsjlWCV0nNDMHVNRcWDHjufkja5KgwNi2Nua5bYQLjf6EaJ2eGU/vnJ7J8Vxp6swlGXoPNPHXSCeFC9edVz0OLclKGPRtwryktDvh42GhvqhqW13ZjAgv4KvXiFlGOY9l3tEPktFuG40=";
    private final BestSignClient bestSignClient_temp_1 = new BestSignClient(
            "https://api.bestsign.info",
            "1658813906016846798",
            "46ef4b91f9dd44c18b7d23625484d8ff",
            privateKey_temp_1
    );
    /**
     * 修改以下参数
     */
    // json复制进来应该直接会带上转义符
    String requestBody = readJsonFile("/Users/edianyun/Downloads/test.json");
    //String requestBody = "";
    final String api = "/api/templates/send-contracts-sync-v2";
    final String method = "POST";
    //private final BestSign_SSQ_Client bestSignClient = bestSignClient_3;
    private final BestSignClient bestSignClient = bestSignClient_temp_1;

    /**
     * 全局，无需修改，直接运行即可
     * @throws IOException
     */
    @Test
    public void request() throws IOException {
        /**
         *   POST 请求
         */
        if(method.equals("POST")) {
            System.out.println("A POST request");
            JSONObject jsonObject = JSONObject.parseObject(requestBody);
            String result = bestSignClient.executeRequest(api, method, jsonObject);
            if (api.endsWith("download-file") || api.endsWith("appendix-file") || api.endsWith("download/notarization") || api.endsWith("templates/preview")) {
                try {
                    byte bytes[] = Base64.getDecoder().decode(result);
                    Files.write(Paths.get("/Users/edianyun/Downloads/0728.pdf"), bytes);
                } catch (IOException e) {
                    System.out.println(result);
                    e.printStackTrace();
                }
            } else if (api.endsWith("downloadByOrder") || api.endsWith("download-subcontract")) {
                try {
                    System.out.println(result);
                    JSONObject jsonObj = JSONObject.parseObject(result);
                    String base64 = jsonObj.getJSONObject("data").getString("base64FileData");
                    byte[] bytes = Base64.getDecoder().decode(base64);
                    Files.write(Paths.get("/Users/edianyun/Downloads/0728子合同下载.pdf"), bytes);
                } catch (IOException e) {
                    System.out.println(result);
                    e.printStackTrace();
                }
            } else {
                /*
                正常输出json
                 */
                if(!api.equals("/api/ents/box/get-person-collection")) {
                    System.out.println("返回：" + "\n" + result);
                }
                /**
                 *
                 * 下载个人资料
                 * 处理fileContents
                 * 各个base64图片分别输出
                 *
                 */
                else {
                    JSONObject resultObj = JSONObject.parseObject(result);
                    JSONArray temp = resultObj.getJSONObject("data").getJSONArray("collectionInfo");
                    int index;
                    for (int i = 0; i < temp.size(); i++) {
                        if (temp.getJSONObject(i).getString("collectionName").equals("必填图片")) {
                            index = i;
                            JSONArray fileContents = temp.getJSONObject(index).getJSONArray("fileContents");
                            for (int j = 0; j < fileContents.size(); j++) {
                                String base64 = fileContents.getString(j);
                                try {
                                    byte[] bytes = Base64.getDecoder().decode(base64);
                                    Files.write(Paths.get(String.format("/Users/edianyun/Downloads/档案柜个人图片资料-%d.jpg", j)), bytes);
                                } catch (IOException e) {
                                    System.out.println(result);
                                    e.printStackTrace();
                                }
                            }
                            break;
                        } else {
                            System.out.println("Not the one");
                        }
                    }
                }
                /**
                 *
                 */
            }
        }
        /**
         *   GET 请求
         */
        else{
            System.out.println("A GET request");
            String encodeApi = urlEncodeURL(api);
            System.out.println("encodeApi: " + encodeApi);
            String result = bestSignClient.executeRequest(encodeApi, method, requestBody);
            System.out.println(api.substring(15,34));
            if((api.substring(15,34).matches("^\\d{19}$") && api.startsWith("/api/contracts/")) || api.contains("wechart-image")) {
                System.out.println(result);
                try {
                    byte[] bytes = Base64.getDecoder().decode(result);
                    Files.write(Paths.get("/Users/edianyun/Downloads/5-30.jpg"), bytes);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            else{
                System.out.println("返回：" + "\n" + result);
            }
        }
    }

    public static String urlEncodeURL(String str) {
        try {
            String result = URLEncoder.encode(str, "UTF-8");
            result = result.replaceAll("%3A", ":").replaceAll("%2F", "/").replaceAll("\\+", "%20").replaceAll("%3F", "?").replaceAll("%3D", "=").replaceAll("%26", "&");//+实际上是 空格 url encode而来
            return result;
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String readJsonFile(String fileName){
        try {
            byte[] bytes = Files.readAllBytes(Paths.get(fileName));
            String content = new String(bytes, StandardCharsets.UTF_8);
            return content;
        }catch (IOException e) {
            e.printStackTrace();
            System.out.println(e);
        }
        return null;
    }

    @Test
    public void testRequest() throws IOException{
        File inputFile = new File("/Users/edianyun/Downloads/劳动合同.pdf");
        PDDocument document = PDDocument.load(inputFile);
        PDFRenderer pdfRenderer = new PDFRenderer(document);

        for (int page = 0; page < document.getNumberOfPages(); ++page) {
            BufferedImage bim = pdfRenderer.renderImageWithDPI(
                    page,
                    300,
                    ImageType.RGB
            );

            try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
                //dpi是指每英寸的像素，也就是扫描精度。这里是50
                //转换出来的最后一张图片是有字体问题的。
                ImageIO.write(bim, "png", baos);

                //将BufferedImage转换成byte[]数组
                byte[] imageInByte = baos.toByteArray();
                Files.write(Paths.get(String.format("/Users/edianyun/Downloads/page-%d.jpg", page)), imageInByte);
            } catch (IOException e) {
                throw e;
            }
        }
        document.close();
    }

}
