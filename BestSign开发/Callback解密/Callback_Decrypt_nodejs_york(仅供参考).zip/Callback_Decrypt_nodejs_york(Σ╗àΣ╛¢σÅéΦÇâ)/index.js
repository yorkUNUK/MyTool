'use strict';

(function(root, factory, undef) {
  if (typeof exports === 'object') {
    // CommonJS
    module.exports = exports = factory(require('./CallBackEncryptor'));
  }
}(this, function(CallBackEncryptor) {
  return CallBackEncryptor;
}));

// 兼容
exports.CallBackEncryptor = require("./CallBackEncryptor");
// 导出异常
exports.CallBackEncryptException = require('./CallBackEncryptException');

// 导出工具函数
const Utils = require("./Utils");
exports.getRandomEncodingAesKey = Utils.getRandomEncodingAesKey;
exports.getRandomStr = Utils.getRandomStr;