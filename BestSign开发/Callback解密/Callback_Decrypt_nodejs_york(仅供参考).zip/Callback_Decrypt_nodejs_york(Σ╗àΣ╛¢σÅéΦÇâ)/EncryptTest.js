'use strict';

const CallBackEncryptor = require('./CallBackEncryptor');
const utils = require('./Utils');

/** 加解密需要，可以随机填写。如 "12345" */
const TOKEN = 'Q5WYPc';
/** 加密密钥，用于回调数据的加密，固定为43个字符，从[a-z, A-Z, 0-9]共62个字符中随机生成*/
const ENCODING_AES_KEY = 'shR2GFpZHWCnyps2WsHBsQK2Gm5DS2r7SBd3byPPEi4';
/** 企业ClientId） */
const ClientId = '1626074470012587260';
/** 实例化加密类 */
console.log('# Encryption and Decryption Test:');
const encryptor = new CallBackEncryptor(TOKEN, ENCODING_AES_KEY, ClientId);


console.log('\n# DingTalk test:');
/** 填充接收到的异步通知的加密内容 */
/** getDecryptMsg(msgSignature, timestamp, nonce, encryptMsg, type) */
const decryptRes = encryptor.getDecryptMsg('6a3d8de520c8328108f24665ae16829584dafa94', '1656929204242', 'IuLBSQrN', 'JYCzpnhOjicSfwlESMs5ezC7Abbq/aqU7+cEOMZa1IZHTLdtiby1Qh6KkT8CT76d1+r+XleECm9mRvtsm2TEdqnKCShhEH3X1bCaDlaO9Q0jx+Bq18mYpz4+3Sq6tpeHkHQyTPd5eVfw6Gp3ZjdgdGR1xjHW7rlpMmL0LoJ3nUUBtSv+V8v04WUsqzaghTMuETWhW8OXjDgM9+HG00JqYBERmGFS63E0EpBbwTkAu+65B7kEuHU+o0j49D7HRksa/w9Lqg+B791rnfn4nEyhDfFiEDgMGMVtt2fWrnc2yhkNW9zIt/epF6xfl/t4PzBsgibglFx0lAxpu3uCDp4Y9f85FDmdJaVFb3aMBFXjEAsFoENpBY/QPbFIobllEh9i', 'CONTRACT_SEND_RESULT');
console.log('decrypt: ', JSON.parse(decryptRes));

