/*
* @Author: York
* @Date:   2022/6/24 12:00 PM
 */
package main

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/sha1"
	"encoding/base64"
	"encoding/binary"
	"errors"
	"fmt"
	"log"
	r "math/rand"
	"sort"
	"strings"
	"time"
)

type CallBackCrypto struct {
	Token          string
	EncodingAESKey string
	clientId       string
	BKey           []byte
	Block          cipher.Block
}

func NewCallBackCrypto(token, encodingAESKey, clientId string) *CallBackCrypto {
	if len(encodingAESKey) != 43 {
		log.Fatal("encodingAESKey不合法")
	}
	bkey, err := base64.StdEncoding.DecodeString(encodingAESKey + "=")
	if err != nil {
		log.Fatal(err)
	}
	block, err := aes.NewCipher(bkey)
	if err != nil {
		log.Fatal(err)
	}
	c := &CallBackCrypto{
		Token:          token,
		EncodingAESKey: encodingAESKey,
		clientId:       clientId,
		BKey:           bkey,
		Block:          block,
	}
	return c
}

func (c *CallBackCrypto) GetDecryptMsg(signature, timestamp, nonce, secretMsg, msgType string) (string, error) {
	if !c.VerificationSignature(c.Token, timestamp, nonce, secretMsg, signature, msgType) {
		return "", errors.New("ERROR: 签名不匹配")
	}
	decode, err := base64.StdEncoding.DecodeString(secretMsg)
	if err != nil {
		return "", err
	}
	if len(decode) < aes.BlockSize {
		return "", errors.New("ERROR: 密文太短")
	}
	blockMode := cipher.NewCBCDecrypter(c.Block, c.BKey[:c.Block.BlockSize()])
	plantText := make([]byte, len(decode))
	blockMode.CryptBlocks(plantText, decode)
	plantText = pkCS7UnPadding(plantText)
	size := binary.BigEndian.Uint32(plantText[16:20])
	plantText = plantText[20:]
	corpID := plantText[size:]
	if string(corpID) != c.clientId {
		return "", errors.New("ERROR: CorpID匹配不正确")
	}
	return string(plantText[:size]), nil
}

func (c *CallBackCrypto) GetEncryptMsg(msg, nonce, msgType string) (map[string]string, error) {
	var timestamp = time.Now().Second()
	str, sign, err := c.GetEncryptMsgDetail(msg, fmt.Sprint(timestamp), nonce, msgType)

	return map[string]string{"nonce": nonce, "timeStamp": fmt.Sprint(timestamp), "encrypt": str, "msg_signature": sign}, err
}
func (c *CallBackCrypto) GetEncryptMsgDetail(msg, timestamp, nonce, msgType string) (string, string, error) {
	size := make([]byte, 4)
	binary.BigEndian.PutUint32(size, uint32(len(msg)))
	msg = randomString(16) + string(size) + msg + c.clientId
	plantText := pkCS7Padding([]byte(msg), c.Block.BlockSize())
	if len(plantText)%aes.BlockSize != 0 {
		return "", "", errors.New("ERROR: 消息体size不为16的倍数")
	}
	blockMode := cipher.NewCBCEncrypter(c.Block, c.BKey[:c.Block.BlockSize()])
	cipherText := make([]byte, len(plantText))
	blockMode.CryptBlocks(cipherText, plantText)
	outMsg := base64.StdEncoding.EncodeToString(cipherText)
	signature := c.CreateSignature(c.Token, timestamp, nonce, outMsg, msgType)
	return outMsg, signature, nil
}

func sha1Sign(s string) string {
	// The pattern for generating a hash is `sha1.New()`,
	// `sha1.Write(bytes)`, then `sha1.Sum([]byte{})`.
	// Here we start with a new hash.
	h := sha1.New()

	// `Write` expects bytes. If you have a string `s`,
	// use `[]byte(s)` to coerce it to bytes.
	h.Write([]byte(s))

	// This gets the finalized hash result as a byte
	// slice. The argument to `Sum` can be used to append
	// to an existing byte slice: it usually isn't needed.
	bs := h.Sum(nil)

	// SHA1 values are often printed in hex, for example
	// in git commits. Use the `%x` format verb to convert
	// a hash results to a hex string.
	return fmt.Sprintf("%x", bs)
}

// 数据签名
func (c *CallBackCrypto) CreateSignature(token, timestamp, nonce, msg, msgType string) string {
	params := make([]string, 0)
	params = append(params, token)
	params = append(params, timestamp)
	params = append(params, msgType)
	params = append(params, msg)
	params = append(params, nonce)
	sort.Strings(params)
	signString := params[:4]
	sign := sha1Sign(strings.Join(signString, ""))
	return sign
}

// 验证数据签名
func (c *CallBackCrypto) VerificationSignature(token, timestamp, nonce, msg, signature, msgType string) bool {
	return c.CreateSignature(token, timestamp, nonce, msg, msgType) == signature
}

// 解密补位
func pkCS7UnPadding(plantText []byte) []byte {
	length := len(plantText)
	unpadding := int(plantText[length-1])
	return plantText[:(length - unpadding)]
}

// 加密补位
func pkCS7Padding(ciphertext []byte, blockSize int) []byte {
	padding := blockSize - len(ciphertext)%blockSize
	padText := bytes.Repeat([]byte{byte(padding)}, padding)
	return append(ciphertext, padText...)
}

// 随机字符串
func randomString(n int, alphabets ...byte) string {
	const alphaNum = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
	var bytes = make([]byte, n)
	var randBy bool
	if num, err := rand.Read(bytes); num != n || err != nil {
		r.Seed(time.Now().UnixNano())
		randBy = true
	}
	for i, b := range bytes {
		if len(alphabets) == 0 {
			if randBy {
				bytes[i] = alphaNum[r.Intn(len(alphaNum))]
			} else {
				bytes[i] = alphaNum[b%byte(len(alphaNum))]
			}
		} else {
			if randBy {
				bytes[i] = alphabets[r.Intn(len(alphabets))]
			} else {
				bytes[i] = alphabets[b%byte(len(alphabets))]
			}
		}
	}
	return string(bytes)
}

func main() {

	var temp = NewCallBackCrypto("Q5WYPc", "shR2GFpZHWCnyps2WsHBsQK2Gm5DS2r7SBd3byPPEi4", "1626074470012587260")

	success, _ := temp.GetDecryptMsg("464af99ea84e3dd5cdc4eb865029885a45609b00", "1656270526591", "wfbwHAdZ", "pQOmmCfbkyl5XgNjzCb0fY9Mno7e4Feu1w759n5sSJY64UMm9YhQtfIAdJrb/yaHzpop6v8bpQKgLjcAQrLWJeuFdNwD2hzMoJESIeRZjrRxuT9Ytd80iKKiw0STqml5v+Ok+/At4k4zk70V2NTsvIfykOhmmtJmjIvwsYKwdQ35Uh1f/pIkBwaerH5OP3xk8CdmCHhD/DiPcYdcXskx5dDdARKkW2edHyTu37kRyB1ZXRvLQC6xwBwrLJJXWQ4JL5klKSbfU012fkKsR1vkTi8DdkpbNceUcEOKnNcvPTo=", "CONTRACT_OVERDUE")
	fmt.Println(success)
}
