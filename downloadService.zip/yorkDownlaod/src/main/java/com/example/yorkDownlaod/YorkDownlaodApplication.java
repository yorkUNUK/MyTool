package com.example.yorkDownlaod;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YorkDownlaodApplication {

	public static void main(String[] args) {
		SpringApplication.run(YorkDownlaodApplication.class, args);
	}

}
